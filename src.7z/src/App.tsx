import { HashRouter, Route, Routes } from 'react-router-dom'

import AuthProvider from 'Components/Providers/AuthProvider'
import ClientConfigProvider from 'Components/Providers/ClientConfigProvider'

import DataProviders from 'Components/Providers/SubjectsManifestProvider'
import RequireAuth from 'Components/RequireAuth'
import StillnessOutLets from 'Components/StillnessOutLets'

import Navigation from './Navigation'
import Settings from 'Pages/Settings'
import QuarterMarks from 'Pages/Marks/QuarterMarks'
import YearMarks from 'Pages/Marks/YearMarks'
import Rating from 'Pages/Marks/Rating'
import Login from 'Pages/Login'

const App = () => {
    return (
        <AuthProvider>
            <HashRouter>
                <ClientConfigProvider>
                    <Routes>
                        <Route
                            path="/"
                            element={
                                <RequireAuth>
                                    <Navigation />
                                    <DataProviders>
                                            <StillnessOutLets />
                                    </DataProviders>
                                </RequireAuth>
                            }
                        >
                            <Route path='/' element={<QuarterMarks/>}/>
                            <Route path='final_grades' element={<YearMarks/>}/>
                            <Route path='/settings/*' element={<Settings/>}/>
                            <Route path='/rating' element={<Rating/>}/>
                            <Route path="*" element="404" />
                        </Route>
                        <Route
                            path="/login/*"
                            element={
                                <Login />
                            }
                        />
                    </Routes>
                </ClientConfigProvider>
            </HashRouter>
        </AuthProvider>
    )
}

export default App
