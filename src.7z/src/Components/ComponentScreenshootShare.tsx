import { CSSProperties, ReactNode, useEffect, useRef, useState } from 'react'

import { css } from '@linaria/core'

import { toBlob } from 'html-to-image'

import Button from './Button'
import LoadingSpinner from './LoadingSpinner'
import SheetView from './SheetView'
import VerticalLayout from './VerticalLayout'

const styles = css`
    .wrapper {
        position: fixed;
        top: -9999px;
    }

    .preview-container {
        width: 100%;
        height: 350px;
        display: grid;
        place-items: center;
        background: var(--bg3);
        border-radius: 9px;
        mask-image: linear-gradient(rgba(0, 0, 0, 100%) 74%, transparent);
    }

    .image-preview {
        width: 100%;
        height: 350px;
        align-self: center;
        object-fit: cover;
        object-position: 0% 0%;
        border-radius: 9px;
    }
`

export interface Props {
    children?: ReactNode
    componentToShare: ReactNode
    handleClose: () => void
    canvasWidth?: CSSProperties['width']
    canvasHeight?: CSSProperties['height']
    canvasScale?: number
}

const ComponentScreenshootShare = ({
    children,
    componentToShare,
    handleClose,
    canvasWidth = '100%',
}: Props) => {
    const canvasRef = useRef<HTMLDivElement>(null)
    const [blob, setBlob] = useState<Blob>()
    const [dataURL, setDataURL] = useState<string>()

    const share = async () => {
        if (!canvasRef.current || !blob) return

        const file = new File([blob], 'Расписание.png', { type: 'image/png' })

        if (navigator.share) {
            navigator.share({
                title: 'Расписание',
                files: [file],
            })
        }
    }

    useEffect(() => {
        setBlob(undefined)
        setDataURL(undefined)

        const generatePreview = async () => {
            if (!canvasRef.current) return

            const b = await toBlob(canvasRef.current, {
                width: canvasWidth,
                canvasWidth,
            })

            if (!b) return

            setBlob(b)
            setDataURL(URL.createObjectURL(b))
        }

        setTimeout(generatePreview, 350)
    }, [children, canvasWidth])

    return (
        <SheetView
            handleClose={handleClose}
            headerTitle="Поделиться расписанием"
        >
            <div className={styles}>
                <VerticalLayout noPadding={false}>
                    <div className="preview-container">
                        {dataURL ? (
                            <img
                                src={dataURL}
                                width="100%"
                                className="image-preview"
                            />
                        ) : (
                            <LoadingSpinner size={32} />
                        )}
                    </div>

                    <div className="wrapper">
                        <div
                            className="canvas"
                            ref={canvasRef}
                            style={{
                                width: canvasWidth,
                            }}
                        >
                            {componentToShare}
                        </div>
                    </div>
                    <div className="custom-share-options">{children}</div>
                    <Button onClick={share} appearance="primary">
                        Поделиться
                    </Button>
                </VerticalLayout>
            </div>
        </SheetView>
    )
}

export default ComponentScreenshootShare
