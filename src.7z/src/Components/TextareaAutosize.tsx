import { forwardRef, useState, useLayoutEffect } from 'react'

import ReactTextareaAutosize, {
    TextareaAutosizeProps,
} from 'react-textarea-autosize'

const TextareaAutosize = forwardRef<HTMLTextAreaElement, TextareaAutosizeProps>(
    (props, ref) => {
        const [, setIsRerendered] = useState(false)
        useLayoutEffect(() => setIsRerendered(true), [])
        return <ReactTextareaAutosize {...props} ref={ref} />
    }
)

export default TextareaAutosize
