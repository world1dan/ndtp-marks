import { useRef } from 'react'
import { css, cx } from '@linaria/core'

import { Icon16PenOutline } from '@vkontakte/icons'

import VisuallyHiddenInput from 'Components/VisuallyHiddenInput'
import LoadingSpinner from 'Components/LoadingSpinner'

const styles = css`
    background: var(--bg4);
    padding: 12px;
    border-radius: 50%;
    display: grid;
    place-items: center;
    border: 1px var(--lvl4-borders) solid;
    transition: all 200ms;

    &:active {
        transform: scale(0.9);
        filter: brightness(1.6);
    }
`

export interface Props {
    handleEdit: (photo: File) => void
    className: string
    isPending?: boolean
}

const EditButton = ({ handleEdit, className, isPending }: Props) => {
    const inputRef = useRef<HTMLInputElement>(null)

    const handleEditButtonClick = () => {
        inputRef?.current?.click()
    }

    return (
        <button
            onClick={handleEditButtonClick}
            className={cx(className, styles)}
        >
            {!isPending ? (
                <Icon16PenOutline width={18} height={18} />
            ) : (
                <LoadingSpinner width={18} height={18} />
            )}
            <VisuallyHiddenInput
                ref={inputRef}
                type="file"
                accept="image/x-png,image/gif,image/jpeg"
                onChange={(event) =>
                    event.target.files && handleEdit(event.target.files[0])
                }
            />
        </button>
    )
}

export default EditButton
