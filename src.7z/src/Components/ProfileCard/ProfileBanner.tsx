import { useRef } from 'react'

import { css } from '@linaria/core'

import useImgAverageColor from 'Hooks/useImgAverageColor'

const styles = css`
    display: block;
    border-radius: 9px;
    object-fit: cover;
    height: 100%;

    &:not([src]) {
        display: none;
    }
`

export interface Props {
    URL: string | undefined
    handleClick: () => void
}

const ProfileBanner = ({ URL, handleClick }: Props) => {
    const bannerRef = useRef<HTMLImageElement>(null)
    const averageBannerColor = useImgAverageColor(bannerRef)

    return (
        <img
            className={styles}
            ref={bannerRef}
            crossOrigin="anonymous"
            src={URL}
            width="100%"
            onClick={handleClick}
            style={{
                boxShadow: `0 0 20px 4px ${averageBannerColor}`,
            }}
        />
    )
}

export default ProfileBanner
