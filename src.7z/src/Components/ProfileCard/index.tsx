import { useState } from 'react'

import { css } from '@linaria/core'

import instagramLogoIcon from 'Assets/icons/instagram-logo.svg'
import telegramLogoIcon from 'Assets/icons/telegram-logo.svg'
import { TaskState } from 'firebase/storage'

import MediaViewer, { IMedia } from 'Components/MediaViewer'
import SvgIcon from 'Components/SvgIcon'

import { IUserProfile } from 'Types/userProfile'

import EditButton from './EditButton'
import ProfileBanner from './ProfileBanner'

const styles = css`
    border-radius: 9px;
    margin-top: 14px;
    position: relative;
    height: 190px;
    background: var(--bg3);
    margin-bottom: 54px;
    border: 1.5px var(--lvl4-borders) solid;

    .card-content {
        pointer-events: none;

        > * {
            pointer-events: auto;
        }

        position: absolute;
        padding: 8px;
        top: 0;
        left: 0;
        bottom: 0;
        right: 0;
    }

    .avatar-container {
        border: 1.5px var(--lvl4-borders) solid;
        background-color: var(--bg3);
        position: relative;
        width: 150px;
        height: 150px;
        margin: 0 auto;
        box-shadow: 0 0 20px 2px #00000086;
        border-radius: 50%;
        overflow: hidden;
        margin-top: 50px;
    }

    .avatar {
        width: 150px;
        height: 150px;
        object-fit: cover;
        display: block;

        &:not([src]) {
            display: none;
        }
    }

    .name {
        background: var(--bg4);
        width: fit-content;
        padding: 8px 14px;
        position: absolute;
        top: -15px;
        left: 0;
        right: 0;
        margin: 0 auto;
        border-radius: 7px;
        font-size: 15px;
        font-weight: 600;
        text-overflow: ellipsis;
        max-width: 60%;
        overflow: hidden;
    }

    .edit-banner-btn {
        position: absolute;
        top: 10px;
        left: 10px;
    }

    .edit-avatar-btn {
        position: absolute;
        bottom: 10px;
        margin: 0 auto;
        width: fit-content;
        left: 0;
        right: 0;
    }

    .social-media-links {
        display: flex;
        gap: 10px;
        position: absolute;
        bottom: -52px;
        right: 0;

        .social-media-link {
            width: 38px;
            height: 38px;
            border-radius: 9px;
            background-color: var(--bg3);
            display: grid;
            place-items: center;
        }
    }
`

export interface Props {
    userProfile: IUserProfile | undefined
    editProfileAvatar?: (avatarPhoto: File) => void
    editProfileBanner?: (bannerPhoto: File) => void
    avatarUploadState?: TaskState
    bannerUploadState?: TaskState
}

const ProfileCard = ({
    userProfile,
    editProfileAvatar,
    editProfileBanner,
    avatarUploadState,
    bannerUploadState,
}: Props) => {
    const [activeMediaViewer, setActiveMediaViewer] = useState<
        undefined | 'avatar' | 'banner'
    >()

    const mediaViewerItems: IMedia[] = []

    if (userProfile?.avatarURL) {
        mediaViewerItems.push({
            type: 'image',
            url: userProfile.avatarURL,
            caption: `${userProfile.firstName} ${userProfile.lastName}`,
        })
    }

    if (userProfile?.bannerURL) {
        mediaViewerItems.push({
            type: 'image',
            url: userProfile.bannerURL,
            caption: `${userProfile.firstName} ${userProfile.lastName}`,
        })
    }

    return (
        <>
            <div className={styles}>
                <ProfileBanner
                    URL={userProfile?.bannerURL}
                    handleClick={() => setActiveMediaViewer('banner')}
                />

                <div className="card-content">
                    <div className="avatar-container">
                        <img
                            className="avatar"
                            src={userProfile?.avatarURL}
                            onClick={() => setActiveMediaViewer('avatar')}
                        />
                        {editProfileAvatar && (
                            <EditButton
                                className="edit-avatar-btn"
                                handleEdit={editProfileAvatar}
                                isPending={avatarUploadState == 'running'}
                            />
                        )}
                    </div>
                    {(userProfile?.firstName || userProfile?.lastName) && (
                        <div className="name">
                            {userProfile.firstName +
                                ' ' +
                                (userProfile.lastName ?? '')}
                        </div>
                    )}
                    {editProfileBanner && (
                        <EditButton
                            className="edit-banner-btn"
                            handleEdit={editProfileBanner}
                            isPending={bannerUploadState == 'running'}
                        />
                    )}
                    <div className="social-media-links">
                        {userProfile?.telegramUsername && (
                            <a
                                className="social-media-link"
                                href={`https://t.me/${userProfile?.telegramUsername}`}
                                target="_blank"
                                rel="noreferrer"
                            >
                                <SvgIcon
                                    icon={telegramLogoIcon}
                                    width={26}
                                    height={26}
                                />
                            </a>
                        )}
                        {userProfile?.instagramUsername && (
                            <a
                                className="social-media-link"
                                href={`https://instagram.com/${userProfile?.instagramUsername}`}
                                rel="noreferrer"
                                target="_blank"
                            >
                                <SvgIcon
                                    icon={instagramLogoIcon}
                                    width={27}
                                    height={27}
                                />
                            </a>
                        )}
                    </div>
                </div>
            </div>

            {activeMediaViewer && (
                <MediaViewer
                    startIndex={activeMediaViewer === 'avatar' ? 0 : 1}
                    medias={mediaViewerItems}
                    handleClose={() => setActiveMediaViewer(undefined)}
                />
            )}
        </>
    )
}

export default ProfileCard
