import { ReactNode, HTMLAttributes } from 'react'
import { css, cx } from '@linaria/core'

const styles = css`
    &.opacity {
        transition: opacity 230ms;
        transition-delay: 80ms;

        &:active {
            opacity: 0.4;
            transition: opacity 100ms;
        }
    }

    &.highlight {
        transition: filter 200ms;
        transition-delay: 80ms;

        &:active {
            filter: brightness(1.4);
            transition: filter 100ms;
        }
    }
`

export interface Props extends HTMLAttributes<HTMLButtonElement> {
    effect?: 'opacity' | 'highlight' | null
    className?: string
    children?: ReactNode
    disabled?: boolean
}

const TouchableWithEffect = ({
    effect = 'opacity',
    className,
    children,
    disabled,
    ...restProps
}: Props) => {
    return (
        <button
            className={cx(styles, effect, className)}
            disabled={disabled}
            {...restProps}
        >
            {children}
        </button>
    )
}

export default TouchableWithEffect
