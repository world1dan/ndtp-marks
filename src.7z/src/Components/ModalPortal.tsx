import { ReactNode, useLayoutEffect, useMemo } from 'react'
import { createPortal } from 'react-dom'

export interface Props {
    children: ReactNode
}

const ModalPortal = ({ children }: Props) => {
    const element = useMemo(() => document.createElement('div'), [])

    useLayoutEffect(() => {
        document.body.appendChild(element)

        return () => {
            document.body.removeChild(element)
        }
    }, [element])

    return createPortal(children, element)
}

export default ModalPortal
