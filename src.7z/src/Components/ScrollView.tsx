import { ReactNode } from 'react'

import { css, cx } from '@linaria/core'

export interface Props {
    children: ReactNode
    className?: string
    withoutPaddings?: boolean
    fullHeight?: boolean
}

const styles = css`
    overflow-y: overlay;
    height: var(--safe-height);
    overscroll-behavior: contain;
    padding: 14px max(env(safe-area-inset-right), 10px) 14px
        max(env(safe-area-inset-left), 10px);

    @media (max-width: 360px) {
        padding: 14px 0;
    }

    &.full-height {
        height: 100vh;

        @supports (height: 100dvh) {
            height: 100dvh;
        }
    }

    &.without-paddings {
        padding: 0;
        padding-left: env(safe-area-inset-left);
        padding-right: env(safe-area-inset-right);
        padding-bottom: 14px;
    }

    &::-webkit-scrollbar {
        width: 0;
    }
`

const ScrollView = ({
    children,
    className,
    withoutPaddings,
    fullHeight,
}: Props) => {
    return (
        <div
            className={cx(
                styles,
                className,
                fullHeight && 'full-height',
                withoutPaddings && 'without-paddings'
            )}
        >
            {children}
        </div>
    )
}

export default ScrollView
