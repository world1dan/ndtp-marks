import { createContext } from 'react'

export interface IBottomSheetContext {
    close: () => void
}

export const BottonSheetContext = createContext({} as IBottomSheetContext)
