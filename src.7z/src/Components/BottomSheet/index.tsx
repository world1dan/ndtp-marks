import { ReactNode, useState } from 'react'
import { css } from '@linaria/core'

import { AnimatePresence, motion } from 'framer-motion'
import { Icon24Dismiss } from '@vkontakte/icons'

import { BottonSheetContext } from './BottomSheetContext'

import Backdrop from '../Backdrop'
import ModalPortal from '../ModalPortal'
import Button from 'Components/Button'

const swipeConfidenceThreshold = 10000

const styles = css`
    background-color: var(--bg2);
    border-radius: 18px;
    bottom: calc(env(safe-area-inset-bottom) + 10px);
    left: 10px;
    margin: 0 auto;
    max-width: 500px;
    min-height: 300px;
    position: fixed;
    right: 10px;
    z-index: 999;

    .top-close-btn {
        color: var(--text-secondary-color);
        position: absolute;
        right: 12px;
        top: 12px;
    }
`

export interface Props {
    children: ReactNode | ((close: () => void) => ReactNode)
    handleClose: () => void
    bottomCloseBtn?: boolean
}

const BottomSheet = ({ handleClose, children, bottomCloseBtn }: Props) => {
    const [isVisible, setIsVisible] = useState(true)

    const closeSheet = () => setIsVisible(false)

    return (
        <AnimatePresence onExitComplete={handleClose}>
            {isVisible && (
                <ModalPortal>
                    <Backdrop onClick={closeSheet}>
                        <motion.div
                            className={styles}
                            drag="y"
                            dragConstraints={{ top: 0, bottom: 0 }}
                            dragSnapToOrigin
                            dragElastic={{ top: 0.14, bottom: 0.4 }}
                            exit={{
                                y: 'calc(100% + 50px)',
                                transitionEnd: {
                                    display: 'none',
                                },
                                transition: {
                                    type: 'tween',
                                    duration: 0.26,
                                },
                            }}
                            initial={{ y: 200 }}
                            animate={{ y: 0 }}
                            transition={{
                                type: 'tween',
                                ease: [0.38, 0.7, 0.125, 1],
                                duration: 0.34,
                            }}
                            onDragEnd={(_e, { offset, velocity }) => {
                                const swipe = Math.abs(offset.y) * velocity.y

                                if (swipe > swipeConfidenceThreshold) {
                                    closeSheet()
                                }
                            }}
                        >
                            <BottonSheetContext.Provider
                                value={{ close: closeSheet }}
                            >
                                {typeof children == 'function'
                                    ? children(closeSheet)
                                    : children}
                            </BottonSheetContext.Provider>
                            {bottomCloseBtn ? (
                                <div
                                    style={{
                                        padding: 12,
                                    }}
                                >
                                    <Button
                                        className="ActionSheetCloseBtn"
                                        onClick={closeSheet}
                                        size="large"
                                    >
                                        Закрыть
                                    </Button>
                                </div>
                            ) : (
                                <button
                                    className="top-close-btn"
                                    onClick={closeSheet}
                                >
                                    <Icon24Dismiss width={28} height={28} />
                                </button>
                            )}
                        </motion.div>
                    </Backdrop>
                </ModalPortal>
            )}
        </AnimatePresence>
    )
}

export default BottomSheet
