import { CSSProperties, forwardRef } from 'react'

import { css, cx } from '@linaria/core'

import VisuallyHiddenInput from './VisuallyHiddenInput'

const styles = css`
    position: relative;
    display: block;
    cursor: pointer;

    &.disabled {
        cursor: not-allowed;
    }

    .pseudo {
        width: 51px;
        height: 31px;
        border: 2px solid transparent;
        background: var(--switch-background-color);
        border-radius: 15px;
        position: relative;
        display: block;
        transition: background-color 0.15s ease, border-color 0.2s ease;
    }

    .pseudo::before {
        content: '';
        transition: transform 0.15s ease;
        border-radius: 50%;
        top: 0;
        left: 0;
        position: absolute;
        width: 27px;
        height: 27px;
        background: var(--switch-indicator-background-color);

        /* prettier-ignore */
        box-shadow: 0 3px 8px rgb(0 0 0 / 15%), 0 3px 1px rgb(0 0 0 / 6%), inset 0 0 0 0.5px rgb(0 0 0 / 4%);
    }

    input:checked + .pseudo {
        background: var(--green);

        &::before {
            transform: translateX(20px);
        }
    }
`

export interface Props extends React.InputHTMLAttributes<HTMLInputElement> {
    className?: string
    style?: CSSProperties
}

const Switch = forwardRef<HTMLInputElement, Props>(
    ({ className, style, ...restProps }, ref) => {
        return (
            <label
                style={style}
                role="presentation"
                className={cx(
                    styles,
                    className,
                    restProps.disabled && 'disabled'
                )}
            >
                <VisuallyHiddenInput type="checkbox" ref={ref} {...restProps} />

                <span role="presentation" className="pseudo" />
            </label>
        )
    }
)

export default Switch
