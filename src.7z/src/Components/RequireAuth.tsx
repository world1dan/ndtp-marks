import { ReactNode } from 'react'

import { Navigate } from 'react-router-dom'

import useUser from 'Hooks/useUser'

export interface Props {
    children?: ReactNode
}

const RequireAuth = ({ children }: Props) => {
    const { user, isLoading } = useUser()

    if (isLoading) {
        return null
    }

    if (!user) {
        return <Navigate to="/login" replace />
    }

    return children as JSX.Element
}

export default RequireAuth
