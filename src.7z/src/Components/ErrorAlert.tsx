import { css } from '@linaria/core'

const styles = css`
    color: var(--error-color);
    padding: 10px;
    font-weight: 600;
    font-size: 14px;
`

export interface Props {
    errorMessage: string
}

const ErrorAlert = ({ errorMessage }: Props) => {
    return <p className={styles}>{errorMessage}</p>
}

export default ErrorAlert
