import { ReactNode, useEffect } from 'react'

import LogRocket from 'logrocket'
import { useAuthState } from 'react-firebase-hooks/auth'

import { AuthContext, IAuthContext } from 'Contexts/AuthContext'

import useUserProfile from 'Hooks/useUserProfile'

import isStandalone from 'Utils/isStandalone'

import { auth } from '../../Firebase'

export interface Props {
    children: ReactNode
}

const AuthProvider = ({ children }: Props) => {
    const [user, loading, error] = useAuthState(auth)
    const { userProfile, userProfileDoc } = useUserProfile(user?.uid)

    useEffect(() => {
        if (
            process.env.NODE_ENV !== 'development' &&
            userProfile &&
            user?.uid
        ) {
            LogRocket.identify(user?.uid, {
                email: user.email ?? '',
                firstName: userProfile.firstName ?? '',
                isStandalone: isStandalone(),
                buildNumber: process.env.BUILD_NUMBER as string,
            })
        }
    }, [userProfile, user])

    return (
        <AuthContext.Provider
            value={
                {
                    user,
                    userProfile,
                    userProfileDoc,
                    isLoading: loading,
                    error,
                } as IAuthContext
            }
        >
            {children}
        </AuthContext.Provider>
    )
}

export default AuthProvider
