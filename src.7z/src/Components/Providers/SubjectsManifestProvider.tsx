import { ReactNode, useMemo } from 'react'

import { doc } from 'firebase/firestore'
import { useDocumentData } from 'react-firebase-hooks/firestore'

import SubjectsManifestContext from 'Contexts/SubjectsManifestContext'

import { firestore } from '../../Firebase'

export interface Props {
    children: ReactNode
}

const SubjectsManifestProvider = ({ children }: Props) => {
    const subjectsManifestDoc = useMemo(
        () => doc(firestore, 'subjectsManifests', '10A'),
        []
    )

    const [subjectsManifest] = useDocumentData(subjectsManifestDoc)

    const subjectsManifestContextValue = useMemo(
        () => ({ subjectsManifest, subjectsManifestDoc }),
        [subjectsManifest, subjectsManifestDoc]
    )

    return (
        <SubjectsManifestContext.Provider value={subjectsManifestContextValue}>
            {children}
        </SubjectsManifestContext.Provider>
    )
}

export default SubjectsManifestProvider
