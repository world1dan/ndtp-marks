import { ReactNode } from 'react'

import ClientConfigContext from 'Contexts/ClientConfigContext'

import useLocalStorage from 'Hooks/useLocalStorage'

import { IClientConfig } from 'Types/clientConfig'

export interface Props {
    children: ReactNode
}

const ClientConfigProvider = ({ children }: Props) => {
    const [config, setConfig] = useLocalStorage<IClientConfig>(
        'CLIENT_CONFIG',
        {
            colorThemeId: 'dark-gray',
            reduceEffect: false,
        }
    )

    const modifyConfig = (changes: Partial<IClientConfig>) =>
        setConfig((prevConfig) => ({ ...prevConfig, ...changes }))

    return (
        <ClientConfigContext.Provider
            value={{
                clientConfig: config,
                modifyClientConfig: modifyConfig,
            }}
        >
            {children}
        </ClientConfigContext.Provider>
    )
}

export default ClientConfigProvider
