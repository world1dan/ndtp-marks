import { CSSProperties } from 'react'
import { css, cx } from '@linaria/core'

import { Icon24Spinner } from '@vkontakte/icons'

const styles = css`
    display: flex;
    align-items: center;
    justify-content: center;

    .spinner {
        animation: spin 0.6s infinite linear;

        @keyframes spin {
            from {
                transform: rotate(0deg);
            }
            to {
                transform: rotate(360deg);
            }
        }
    }
`

export interface Props {
    size?: number
    className?: string
    height?: CSSProperties['height']
    width?: CSSProperties['width']
}

const LoadingSpinner = ({ size, height, width, className }: Props) => {
    return (
        <div className={cx(styles, className)} style={{ height, width }}>
            <Icon24Spinner width={size} height={size} className="spinner" />
        </div>
    )
}

export default LoadingSpinner
