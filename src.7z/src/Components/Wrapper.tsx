import { ReactNode } from 'react'

import { css, cx } from '@linaria/core'

const styles = css`
    display: flex;
    flex-direction: column;
    height: var(--safe-height);
    padding-bottom: 4px;
`

export interface Props {
    children: ReactNode
    className?: string
}

const Wrapper = ({ children, className }: Props) => {
    return <div className={cx(styles, className)}>{children}</div>
}

export default Wrapper
