import { memo, useEffect, useRef } from 'react'

export interface Props {
    handler: () => void
}

const LazyLoadingTrigger = ({ handler }: Props) => {
    const trigger = useRef<HTMLDivElement>(null)

    useEffect(() => {
        const observer = new IntersectionObserver((entries) => {
            if (entries[0].isIntersecting) {
                handler()
            }
        })
        trigger.current && observer.observe(trigger.current)
        return () => observer.disconnect()
    }, [handler])

    return <div ref={trigger} />
}

export default memo(LazyLoadingTrigger)
