import { IBellSchedule } from 'Types/bellSchedule'

export const bellSchedule: IBellSchedule = {
    periodName: 'Урок',
    schedule: {
        '1': {
            '1': {
                start: '8:00',
                end: '8:45',
            },
            '2': {
                start: '8:55',
                end: '9:40',
            },
            '3': {
                start: '9:55',
                end: '10:40',
            },
            '4': {
                start: '10:55',
                end: '11:40',
            },
            '5': {
                start: '11:55',
                end: '12:40',
            },
            '6': {
                start: '12:50',
                end: '13:35',
            },
        },
        '2': {
            '1': {
                start: '13:55',
                end: '14:40',
            },
            '2': {
                start: '14:55',
                end: '15:40',
            },
            '3': {
                start: '15:55',
                end: '16:40',
            },
            '4': {
                start: '16:55',
                end: '17:40',
            },
            '5': {
                start: '17:50',
                end: '18:35',
            },
            '6': {
                start: '18:45',
                end: '19:30',
            },
        },
    },
}
