import { useState } from 'react'

import { css } from '@linaria/core'

import { isPast, isWithinInterval } from 'date-fns'

import useInterval from 'Hooks/useInterval'

import Period from './Period'
import { bellSchedule as bellScheduleData } from './bellScheduleData'

const styles = css`
    display: flex;
    gap: 2px;

    .shift-title {
        font-size: 14px;
        font-weight: 600;
        text-align: center;
        padding: 6px;
    }

    .shift-periods {
        display: flex;
        flex-direction: column;
        padding: 4px;
        gap: 3px;
    }

    .period-num {
        display: flex;
        height: 34px;
        align-items: center;
        font-size: 15px;
        justify-content: center;
    }
`

const BellSchedule = () => {
    const [now, setNow] = useState(() => new Date())

    useInterval(() => setNow(new Date()), 1000, false)

    return (
        <div className={styles}>
            {Object.entries(bellScheduleData.schedule).map(
                ([shiftNum, shift]) => {
                    return (
                        <div key={shiftNum}>
                            <h5 className="shift-title">{shiftNum} Смена</h5>
                            <div className="shift-periods">
                                {Object.entries(shift).map(
                                    ([periodNum, period]) => {
                                        const start = period.start.split(':')
                                        const end = period.end.split(':')

                                        const interval = {
                                            start: new Date().setHours(
                                                parseInt(start[0]),
                                                parseInt(start[1]),
                                                0,
                                                0
                                            ),
                                            end: new Date().setHours(
                                                parseInt(end[0]),
                                                parseInt(end[1]),
                                                0,
                                                0
                                            ),
                                        }

                                        return (
                                            <Period
                                                key={periodNum}
                                                period={period}
                                                isEnded={isPast(interval.end)}
                                                isCurrent={isWithinInterval(
                                                    now,
                                                    interval
                                                )}
                                            />
                                        )
                                    }
                                )}
                            </div>
                        </div>
                    )
                }
            )}
        </div>
    )
}

export default BellSchedule
