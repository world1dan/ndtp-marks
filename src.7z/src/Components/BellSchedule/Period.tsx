import { memo } from 'react'

import { css, cx } from '@linaria/core'

import { ITimePeriod } from 'Types/bellSchedule'

const styles = css`
    padding: 8px 18px;
    font-size: 15px;
    position: relative;
    background-color: var(--bg4);
    text-align: center;

    &.ended {
        opacity: 0.7;
        color: var(--text-secondary-color);
    }

    &:first-of-type {
        border-radius: 5px 5px 0 0;
    }

    &:last-of-type {
        border-radius: 0 0 5px 5px;
    }

    .current-period-indicator {
        width: 4px;
        height: 20px;
        background-color: var(--green);
        position: absolute;
        left: 7px;
        top: calc(50% - 10px);
        border-radius: 3px;
        animation: indicator-animation 1200ms linear infinite;

        @keyframes indicator-animation {
            0% {
                opacity: 1;
            }

            50% {
                opacity: 0.2;
            }

            100% {
                opacity: 1;
            }
        }
    }
`

export interface Props {
    period: ITimePeriod
    isCurrent: boolean
    isEnded: boolean
}

const Period = ({ period, isCurrent, isEnded }: Props) => {
    return (
        <div className={cx(styles, isEnded && 'ended')}>
            {isCurrent && <div className="current-period-indicator"></div>}
            {`${period.start} - ${period.end}`}
        </div>
    )
}

export default memo(Period)
