import { useContext } from 'react'

import { css } from '@linaria/core'

import { Icon24CheckCircleOff, Icon24CheckCircleOn } from '@vkontakte/icons'

import RadioGroupContext from './RadioGroup/RadioGroupContext'

const styles = css`
    display: flex;
    gap: 8px;
    align-items: center;
    font-weight: 600;
    font-size: 15px;
    padding: 8px 12px;
    padding-left: 8px;
    background-color: var(--bg3);
    border-radius: 9px;
    width: 100%;
`

export interface Props {
    id: string
    label?: string
}

const RadioButton = ({ id, label }: Props) => {
    const { selectedId, handleSelect } = useContext(RadioGroupContext)

    const isSelected = selectedId === id

    return (
        <button className={styles} onClick={() => handleSelect(id)}>
            {isSelected ? <Icon24CheckCircleOn /> : <Icon24CheckCircleOff />}
            {label}
        </button>
    )
}

export default RadioButton
