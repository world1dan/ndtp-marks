import { IAudioAttachment } from 'Types/lesson'

export interface Props {
    audioAttachment: IAudioAttachment
}

const AttachmentInfo = ({ audioAttachment }: Props) => {
    const 
    return <div>

    </div>
}

export default AttachmentInfo
