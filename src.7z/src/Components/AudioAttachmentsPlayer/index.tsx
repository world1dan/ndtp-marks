import AudioPlayer from 'Components/AudioPlayer'
import SheetView from 'Components/SheetView'
import Stack from 'Components/Stack'

import { IAudioAttachment } from 'Types/lesson'

export interface Props {
    audioAttachments?: IAudioAttachment[]
    handleClose: () => void
}

const AudioAttachmentsPlayer = ({
    audioAttachments = [
        {
            URL: 'http://127.0.0.1:9199/v0/b/wd-school.appspot.com/o/lessons-attachments%2Finstasamka_-_za_den_gi_da_muzati.net.mp3?alt=media&token=718f1ef1-8cac-4315-9481-b4ca930b9c2d',
            attachedAt: new Date().toUTCString(),
            attachedBy: 'GoQSfb3VwkH0jJY3APfLDknzVmZ9',
        },
    ],
    handleClose,
}: Props) => {
    return (
        <SheetView
            handleClose={handleClose}
            headerTitle="Даник.Музыка"
            height="half-screen"
        >
            <Stack>
                <AudioPlayer file={audioAttachments[0].URL} />
            </Stack>
        </SheetView>
    )
}

export default AudioAttachmentsPlayer
