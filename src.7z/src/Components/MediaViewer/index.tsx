import { lazy, Suspense, useRef } from 'react'
import { css } from '@linaria/core'

import ModalPortal from '../ModalPortal'
import CloseButton from './CloseButton'
import usePageThemeColor from 'Hooks/usePageThemeColor'

const MediaGallery = lazy(() => import('./MediaGallery'))

const styles = css`
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;

    .swiper-pagination-bullet {
        background: var(--blue);
    }

    .swiper-pagination-bullets {
        padding-bottom: calc(env(safe-area-inset-bottom) - 14px);
        pointer-events: none;
    }

    .swiper-button-prev,
    .swiper-button-next {
        color: var(--text-secondary-color);
    }

    .swiper-button-prev {
        left: max(30px, calc(env(safe-area-inset-left) + 30px));
    }

    .swiper-button-next {
        right: max(30px, calc(env(safe-area-inset-right) + 30px));
    }

    background: var(--bg1);
    touch-action: none;
    z-index: 999;
    width: 100vw;
    height: 100vh;

    @keyframes enter {
        from {
            opacity: 0;
            transform: scale(0.94);
        }
        to {
            opacity: 1;
            transform: scale(1);
        }
    }

    @keyframes exit {
        from {
            opacity: 1;
            transform: scale(1);
        }
        to {
            opacity: 0;
            transform: scale(0.94);
        }
    }

    animation: 0.2s enter;

    &.exit {
        animation: 0.15s exit forwards;
        transform-origin: bottom;
    }
`

export interface IMedia {
    caption: string
    url: string
    handleRemove?: () => void
    type: 'image' | 'video'
    thumbnailDataURL?: string
}

export interface Props {
    medias: IMedia[]
    handleClose: () => void
    startIndex?: number
}

const MediaViewer = ({ medias, handleClose, startIndex = 0 }: Props) => {
    usePageThemeColor('var(--bg1)')
    const modalRef = useRef<HTMLDivElement>(null)

    const closeModal = () => {
        if (modalRef.current) {
            modalRef.current.classList.add('exit')

            modalRef.current.addEventListener('animationend', handleClose, {
                once: true,
            })
        }
    }

    return (
        <ModalPortal>
            <div className={styles} ref={modalRef}>
                <CloseButton onClick={closeModal} />
                <Suspense>
                    <MediaGallery medias={medias} startIndex={startIndex} />
                </Suspense>
            </div>
        </ModalPortal>
    )
}

export default MediaViewer
