import { Zoom, Pagination, Navigation } from 'swiper'
import { Swiper, SwiperSlide } from 'swiper/react'

import 'swiper/css'
import 'swiper/css/zoom'
import 'swiper/css/pagination'
import 'swiper/css/navigation'

import useMediaQuery from 'Hooks/useMediaQuery'

import Media from './Media'

export interface IMedia {
    caption: string
    url: string
    handleRemove?: () => void
    type: 'image' | 'video'
}

export interface Props {
    medias: IMedia[]
    startIndex?: number
}

const MediaGallery = ({ medias, startIndex = 0 }: Props) => {
    const isLargeScreen = useMediaQuery('(min-width: 768px)')

    return (
        <Swiper
            modules={[Zoom, Pagination, Navigation]}
            pagination
            spaceBetween={14}
            navigation={isLargeScreen}
            initialSlide={startIndex}
            zoom
        >
            {medias.map((media) => (
                <SwiperSlide key={media.url}>
                    <Media media={media} />
                </SwiperSlide>
            ))}
        </Swiper>
    )
}

export default MediaGallery
