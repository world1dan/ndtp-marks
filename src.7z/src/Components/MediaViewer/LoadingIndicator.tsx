import { css } from '@linaria/core'

import { Icon32ErrorCircleOutline } from '@vkontakte/icons'
import { motion } from 'framer-motion'

import LoadingSpinner from 'Components/LoadingSpinner'

const styles = css`
    position: absolute;
    width: 100%;
    height: 100%;
    overflow: hidden;
    z-index: 3;
    display: grid;
    place-items: center;

    .thumbnail {
        max-width: 100%;
        max-height: 100%;
        width: 100%;
        filter: blur(7px);
        object-fit: contain;
        display: block;
        overflow: hidden;
    }

    .loading-state-indicator {
        background-color: var(--bg4-translucent);
        backdrop-filter: blur(20px) saturate(160%);
        padding: 8px;
        border-radius: 50%;
    }

    .thumbnail-wrapper {
        display: grid;
        place-items: center;
        width: 100%;
        max-height: 100%;
        max-width: 100%;
        overflow: hidden;
    }

    .loading-spinner-container {
        position: absolute;
        width: 100%;
        top: 0;
        left: 0;
        right: 0;
        height: 100%;
        display: grid;
        place-items: center;
        z-index: 1;
    }
`

export interface Props {
    thumbnailDataURL?: string
    loadingState: 'loaded' | 'loading' | 'error'
}

const LoadingIndicator = ({ thumbnailDataURL, loadingState }: Props) => {
    return (
        <motion.div
            className={styles}
            exit={{
                opacity: 0,
            }}
            transition={{
                duration: 0.2,
            }}
        >
            {loadingState !== 'loaded' && (
                <div className="loading-spinner-container">
                    <div className="loading-state-indicator">
                        {loadingState == 'loading' && (
                            <LoadingSpinner size={36} />
                        )}
                        {loadingState == 'error' && (
                            <Icon32ErrorCircleOutline
                                width={36}
                                height={36}
                                fill="var(--red)"
                            />
                        )}
                    </div>
                </div>
            )}
            {loadingState !== 'loaded' && thumbnailDataURL && (
                <div className="thumbnail-wrapper">
                    <img src={thumbnailDataURL} className="thumbnail" />
                </div>
            )}
        </motion.div>
    )
}

export default LoadingIndicator
