import { useState } from 'react'
import { css } from '@linaria/core'

import { AnimatePresence } from 'framer-motion'
import { useSwiperSlide } from 'swiper/react'

import ToolBar from './ToolBar'
import LoadingIndicator from './LoadingIndicator'

import { IMedia } from './index'

const styles = css`
    display: flex;
    justify-content: center;
    padding-bottom: max(78px, calc(env(safe-area-inset-bottom) + 70px));
    height: 100vh;

    @supports (height: 100svh) {
        height: 100svh;
    }

    .swiper-zoom-container {
        z-index: 1;
        position: relative;
    }

    .video {
        width: auto;
        height: 100%;
        max-width: 100%;
        object-fit: contain;
    }
`

export interface Props {
    media: IMedia
}

const Media = ({ media }: Props) => {
    const swiperSlide = useSwiperSlide()
    const [loadingState, setLoadingState] = useState<
        'loading' | 'loaded' | 'error'
    >('loading')

    return (
        <div className={styles}>
            <div className="swiper-zoom-container">
                <AnimatePresence>
                    {(swiperSlide.isActive || swiperSlide.isNext) &&
                        loadingState !== 'loaded' && (
                            <LoadingIndicator
                                loadingState={loadingState}
                                thumbnailDataURL={media.thumbnailDataURL}
                            />
                        )}
                </AnimatePresence>
                {media.type === 'image' &&
                    (swiperSlide.isActive ||
                        swiperSlide.isNext ||
                        loadingState == 'loaded') && (
                        <img
                            onLoad={() => setLoadingState('loaded')}
                            onError={() => setLoadingState('error')}
                            src={media.url}
                            width="100%"
                            style={{
                                visibility:
                                    loadingState == 'loaded'
                                        ? 'visible'
                                        : 'hidden',
                            }}
                        />
                    )}
                {media.type === 'video' && (
                    <video src={media.url} className="video"></video>
                )}
            </div>
            <ToolBar
                photoURL={media.url}
                handleRemove={media.handleRemove}
                caption={media.caption}
            />
        </div>
    )
}

export default Media
