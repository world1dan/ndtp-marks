import { ReactNode } from 'react'
import { css } from '@linaria/core'

import TouchableWithEffect from 'Components/TouchableWithEffect'

const styles = css`
    background: var(--bg4);
    border-radius: 9px;
    height: 42px;
    width: 42px;
    display: grid;
    place-items: center;
`

export interface Props {
    onClick: () => void
    icon: ReactNode
}

const ToolButton = ({ onClick, icon }: Props) => {
    return (
        <TouchableWithEffect className={styles} onClick={onClick}>
            {icon}
        </TouchableWithEffect>
    )
}

export default ToolButton
