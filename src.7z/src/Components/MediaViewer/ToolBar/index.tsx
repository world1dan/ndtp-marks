import { css } from '@linaria/core'

import { ref } from 'firebase/storage'
import { Icon28ShareExternal, Icon24DeleteOutline } from '@vkontakte/icons'

import { storage } from '../../../Firebase'

import ToolButton from './ToolButton'
import shareImageFromStorage from 'Utils/shareImageFromStorage'

const styles = css`
    background: var(--bg2);
    border-radius: 14px 14px 0 0;
    border: 1px var(--borders) solid;
    padding: 12px;
    padding-bottom: max(8px, env(safe-area-inset-bottom));

    display: grid;
    grid-template-columns: 42px 1fr 42px;

    position: absolute;
    bottom: 0;

    width: 100%;
    margin: 0 auto;
    max-width: 540px;

    .caption {
        color: var(--text-secondary-color);
        font-size: 13px;
        font-weight: 500;
        text-align: center;
    }
`

export interface Props {
    photoURL: string
    caption?: string
    handleRemove?: () => void
}

const ToolBar = ({ photoURL, handleRemove, caption }: Props) => {
    const sharePhoto = () => {
        try {
            shareImageFromStorage(ref(storage, photoURL), {
                title: caption ?? 'Фото',
            })
        } catch {
            alert('Не удалось поделиться фото')
        }
    }

    return (
        <div className={styles}>
            <ToolButton
                onClick={sharePhoto}
                icon={
                    <Icon28ShareExternal
                        width={24}
                        height={24}
                        fill="var(--blue)"
                    />
                }
            />
            {caption && <div className="caption">{caption}</div>}
            {handleRemove && (
                <ToolButton
                    onClick={handleRemove}
                    icon={
                        <Icon24DeleteOutline
                            width={24}
                            height={24}
                            fill="var(--red)"
                        />
                    }
                />
            )}
        </div>
    )
}

export default ToolBar
