import { css } from '@linaria/core'
import { Icon24Dismiss } from '@vkontakte/icons'

import TouchableWithEffect from 'Components/TouchableWithEffect'

const styles = css`
    position: fixed;
    right: 18px;
    top: 18px;
    color: var(--text-secondary-color);
    align-items: center;
    justify-content: center;
    z-index: 9999;
    background: var(--bg4);
    border-radius: 50%;
`

export interface Props {
    onClick: () => void
}

const CloseButton = ({ onClick }: Props) => {
    return (
        <TouchableWithEffect className={styles} onClick={onClick}>
            <Icon24Dismiss width={34} height={34} />
        </TouchableWithEffect>
    )
}

export default CloseButton
