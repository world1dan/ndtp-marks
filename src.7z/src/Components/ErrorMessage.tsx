import { ReactNode } from 'react'

import { css } from '@linaria/core'

import { Icon56ErrorOutline } from '@vkontakte/icons'

const styles = css`
    display: flex;
    flex-direction: column;

    margin: 0 auto;
    margin-top: 20vh;
    margin-bottom: 20vh;
    justify-content: center;
    align-items: center;

    background-color: var(--bg2);
    border-radius: 9px;
    width: fit-content;
    border: 1.5px var(--borders) solid;
    padding: 16px;
    gap: 8px;

    .error-details {
        color: var(--text-secondary-color);
        font-size: 14px;
    }
`

export interface Props {
    icon?: ReactNode
    title?: string
    details?: string
}

const ErrorMessage = ({ title, details, icon }: Props) => {
    return (
        <div>
            <div className={styles}>
                {icon ?? (
                    <Icon56ErrorOutline
                        style={{
                            color: 'var(--red)',
                        }}
                    />
                )}
                {title && <h3>{title}</h3>}
                {details && <p className="error-details">{details}</p>}
            </div>
        </div>
    )
}

export default ErrorMessage
