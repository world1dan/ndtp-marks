import { InputHTMLAttributes } from 'react'

import { css, cx } from '@linaria/core'

const styles = css`
    display: flex;
    flex-direction: column;
    gap: 8px;

    .label {
        font-size: 13px;
        font-weight: 600;
        padding-left: 10px;
    }

    .input {
        background-color: var(--bg3);
        padding: 12px;
        font-size: 14px;
        font-weight: 500;
        border-radius: 7px;
        width: 100%;
        transition: box-shadow 0.2s;

        &:focus {
            box-shadow: 0 0 0 2px var(--primary-color);
        }
    }
`

export enum InputHeight {
    Small = 'small',
    Medium = 'medium',
    Large = 'large',
}

export interface Props extends InputHTMLAttributes<HTMLInputElement> {
    height?: InputHeight
    label?: string
}

const TextInput = ({
    height = InputHeight.Medium,
    className,
    label,
    ...restProps
}: Props) => {
    return (
        <div className={styles}>
            {label && <label className="label">{label}</label>}
            <input className={cx('input', height, className)} {...restProps} />
        </div>
    )
}

export default TextInput
