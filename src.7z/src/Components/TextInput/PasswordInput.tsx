import { useState } from 'react'

import { css, cx } from '@linaria/core'

import { Icon24Hide, Icon24View } from '@vkontakte/icons'

import TextInput, { Props as TextInputProps } from './index'

const styles = css`
    position: relative;

    .toggle-password-show-icon {
        position: absolute;
        bottom: 10px;
        right: 12px;
        cursor: pointer;
    }
`

const inputStyles = css`
    padding-right: 44px !important;
`

const PasswordInput = ({ className, ...restProps }: TextInputProps) => {
    const [showPassword, setShowPassword] = useState(false)

    const togglePasswordShow = () => setShowPassword(!showPassword)

    return (
        <div className={styles}>
            <TextInput
                className={cx(className, inputStyles)}
                type={!showPassword ? 'password' : 'text'}
                {...restProps}
            />
            {showPassword ? (
                <Icon24Hide
                    className="toggle-password-show-icon"
                    onClick={togglePasswordShow}
                />
            ) : (
                <Icon24View
                    className="toggle-password-show-icon"
                    onClick={togglePasswordShow}
                />
            )}
        </div>
    )
}

export default PasswordInput
