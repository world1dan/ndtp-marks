import { createContext } from 'react'

export interface ISegmentedControlContext {
    controlId: string
    value: string
    handleChange: (optionId: string) => void
}

const SegmentedControlContext = createContext<ISegmentedControlContext>(
    {} as ISegmentedControlContext
)

export default SegmentedControlContext
