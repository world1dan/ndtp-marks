import { useId, memo, ReactElement } from 'react'
import { css } from '@linaria/core'

import SegmentedControlContext from './SegmentedContolContext'

import { Props as SegmentedContolOptionProps } from './SegmentedControlOption'

const styles = css`
    background-color: var(--segmented-control-bg);
    border-radius: 9px;
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(100px, 1fr));
    padding: 3px;
    position: relative;
`

export interface Props {
    value: string
    handleChange: (optionId: string) => void
    children:
        | ReactElement<SegmentedContolOptionProps>
        | Array<ReactElement<SegmentedContolOptionProps>>
}

const SegmentedControl = ({ value, handleChange, children }: Props) => {
    const controlId = useId()

    return (
        <SegmentedControlContext.Provider
            value={{
                controlId,
                value,
                handleChange,
            }}
        >
            <div className={styles}>{children}</div>
        </SegmentedControlContext.Provider>
    )
}

export default memo(SegmentedControl)
