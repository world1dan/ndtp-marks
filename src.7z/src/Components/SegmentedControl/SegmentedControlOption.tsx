import { ReactNode, useContext } from 'react'

import { css } from '@linaria/core'

import { motion } from 'framer-motion'

import SegmentedControlContext from './SegmentedContolContext'

const styles = css`
    font-weight: 600;
    padding: 12px 20px;
    position: relative;

    &:first-of-type {
        transform-origin: 12% center;
    }

    &:last-of-type {
        transform-origin: 84% center;
    }

    transition: all 230ms;
    transition-delay: 80ms;

    &:active {
        transition: all 120ms;
        transform: scale(0.95);
        opacity: 0.7;
    }

    .label {
        font-size: 12px;
        pointer-events: none;
        position: relative;
        z-index: 99;
    }

    .active {
        background-color: var(--segmented-control-active-bg);
        border-radius: 7px;
        bottom: 0;
        box-shadow: 0 0 0 1.5px var(--lvl4-borders) inset;
        position: absolute;
        right: 0;
        left: 0;
        top: 0;
        z-index: 1;
    }
`

export interface Props {
    id: string
    children: ReactNode
}

const SegmentedControlOption = ({ id, children }: Props) => {
    const { controlId, handleChange, value } = useContext(
        SegmentedControlContext
    )

    const isActive = id === value

    return (
        <button onClick={() => handleChange(id)} className={styles}>
            {isActive && (
                <motion.div
                    layoutId={controlId}
                    className="active"
                    transition={{
                        type: 'spring',
                        duration: 0.3,
                        bounce: 0,
                    }}
                />
            )}
            <div className="label">{children}</div>
        </button>
    )
}

export default SegmentedControlOption
