import { CSSProperties, ReactNode } from 'react'

import { css, cx } from '@linaria/core'

const styles = css`
    display: flex;

    &.vertical {
        flex-direction: column;
    }

    &.horizontal {
        align-items: center;
    }

    &.space-between {
        justify-content: space-between;
    }
`

export interface Props {
    children?: ReactNode
    direction?: 'horizontal' | 'vertical'
    gap?: CSSProperties['gap']
    padding?: CSSProperties['padding']
    spaceBetween?: boolean
    className?: string
}

const Stack = ({
    children,
    direction = 'vertical',
    gap = 8,
    className,
    spaceBetween = false,
    padding,
}: Props) => {
    return (
        <div
            className={cx(
                styles,
                direction,
                spaceBetween && 'space-between',
                className
            )}
            style={{
                gap,
                padding,
            }}
        >
            {children}
        </div>
    )
}

export default Stack
