import { forwardRef, InputHTMLAttributes } from 'react'
import { css } from '@linaria/core'

const styles = css`
    display: none;
    visibility: hidden;
`

const VisuallyHiddenInput = forwardRef<
    HTMLInputElement,
    InputHTMLAttributes<HTMLInputElement>
>(({ ...restProps }: InputHTMLAttributes<HTMLInputElement>, ref) => {
    return <input ref={ref} className={styles} {...restProps} />
})

VisuallyHiddenInput.displayName = 'VisuallyHiddenInput'

export default VisuallyHiddenInput
