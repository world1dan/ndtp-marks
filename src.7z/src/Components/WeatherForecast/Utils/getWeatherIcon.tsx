import { StaticWeatherIcons } from '../../Icons/Weather'

const weatherIconsMap = {
    '01d': 'ClearDay',
    '01n': 'ClearNight',
    '02d': 'PartlyCloudyDay',
    '02n': 'PartlyCloudyNight',
    '03d': 'Cloudy',
    '03n': 'Cloudy',
    '04d': 'Overcast',
    '04n': 'Overcast',
    '09d': 'Rain',
    '09n': 'Rain',
    '10d': 'PartlyCloudyDayRain',
    '10n': 'PartlyCloudyNightRain',
    '11d': 'ThunderstormsDayRain',
    '11n': 'ThunderstormsNnightRain',
    '13d': 'PartlyCloudyDaySnow',
    '13n': 'PartlyCloudyNightSnow',
    '50d': 'Mist',
    '50n': 'Mist',
}

const findIcon = (iconID: string) => {
    const iconName = weatherIconsMap[iconID]

    return iconName ?? 'ClearDay'
}

export const getStaticWeatherIcon = (iconID: string) => {
    const svg = StaticWeatherIcons[findIcon(iconID)]

    return function Icon({ width }: { width: number | string }) {
        return <img src={svg} width={width} />
    }
}
