import { getWeatherForecast } from './weatherAPI'
import { IWeatherForecast } from './types'
import useLocalStorage from '../../Hooks/useLocalStorage'
import useInterval from '../../Hooks/useInterval'

export interface IUseWeatherOptions {
    lat: number
    lon: number
}

const useWeatherForecast = ({
    lat,
    lon,
}: IUseWeatherOptions): [IWeatherForecast, () => void] => {
    const [weatherForecast, setWeatherForecast] =
        useLocalStorage<IWeatherForecast>('weather-forecast-cache')
    const [lastFetch, setLastFetch] = useLocalStorage<number>(
        'weather-forecast-last-fetch'
    )

    const fetchWeatherForecast = () => {
        if (process.env.NODE_ENV === 'production' || !weatherForecast) {
            if (lastFetch) {
                const now = new Date()
                const diff = now.getTime() - new Date(lastFetch).getTime()
                if (diff < 5000) {
                    return
                }
            }

            getWeatherForecast(lat, lon).then((weather) => {
                setWeatherForecast(weather)
                setLastFetch(Date.now())
            })
        }
    }

    useInterval(fetchWeatherForecast, 600000)

    return [weatherForecast, fetchWeatherForecast]
}

export default useWeatherForecast
