import { css } from '@linaria/core'

import { City } from '../types'

const styles = css`
    display: flex;
    align-items: center;
    flex-direction: column;
    gap: 2px;

    .title {
        font-size: 16px;
        font-weight: 600;
    }

    .location {
        display: flex;
        gap: 5px;
        align-items: center;
        color: var(--text-secondary-color);
        font-size: 13px;
        text-decoration: underline;
        cursor: pointer;
    }
`

export interface Props {
    city: City
    updateWeather: () => void
}

const Header = ({ city }: Props) => {
    return (
        <div className={styles}>
            <div className="title">Погода</div>
            <div className="location">{city.name}</div>
        </div>
    )
}

export default Header
