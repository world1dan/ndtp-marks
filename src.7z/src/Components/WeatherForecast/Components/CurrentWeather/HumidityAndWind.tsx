import { FC } from 'react'

import { css } from '@linaria/core'

import { StaticWeatherIcons } from '../../../Icons/Weather'
import { Main, Wind } from '../../types'

const styles = css`
    display: grid;
    flex-direction: column;
    align-items: center;
    grid-template-rows: 24px 24px;
    flex-grow: 1;
    justify-content: center;

    .data-row {
        display: flex;
        align-items: center;
        gap: 3px;
        color: var(--text-secondary-color);
        font-size: 13px;
        font-weight: 600;
    }
`

export interface IHumidityAndWindProps {
    humidity: Main['humidity']
    windSpeed: Wind['speed']
}

const HumidityAndWind: FC<IHumidityAndWindProps> = ({
    humidity,
    windSpeed,
}) => {
    return (
        <div className={styles}>
            <div className="data-row">
                <img
                    src={StaticWeatherIcons.Humidity}
                    alt="humidity"
                    width={34}
                />

                {humidity + '%'}
            </div>
            <div className="data-row">
                <img src={StaticWeatherIcons.Wind} alt="wind" width={30} />
                {windSpeed.toFixed(1) + ' м/с'}
            </div>
        </div>
    )
}

export default HumidityAndWind
