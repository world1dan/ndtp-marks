import { memo } from 'react'
import { css } from '@linaria/core'

import { motion } from 'framer-motion'
import { Icon24ArrowUturnLeftOutline } from '@vkontakte/icons'

import Button from 'Components/Button'

const styles = css`
    padding: 6px;
    display: grid;
    grid-template-columns: 1fr 130px;
    gap: 12px;
    font-size: 13px;
    font-weight: 600;
    max-width: 370px;
    margin: 0 auto;

    @media (min-width: 600px) {
        padding: 8px;
    }
`

export interface Props {
    text: string
    handleGoBack: () => void
}

const NotCurrentTermWarn = ({ text, handleGoBack }: Props) => {
    return (
        <motion.div
            className={styles}
            initial={{
                scale: 0.94,
                opacity: 0,
            }}
            animate={{
                scale: 1,
                opacity: 1,
            }}
        >
            {text}
            <Button
                onClick={handleGoBack}
                size="medium"
                iconLeft={
                    <Icon24ArrowUturnLeftOutline width={20} height={20} />
                }
            >
                Вернуться
            </Button>
        </motion.div>
    )
}

export default memo(NotCurrentTermWarn)
