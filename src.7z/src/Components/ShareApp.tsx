import { Icon24ShareExternalOutline } from '@vkontakte/icons'

import useClassroom from 'Hooks/useClassroom'
import useUser from 'Hooks/useUser'

import openAppShareDialog from 'Utils/openAppShareDialog'

import Button from './Button'
import LoadingSpinner from './LoadingSpinner'

const ShareApp = () => {
    const { userProfile } = useUser()
    const classroom = useClassroom(userProfile?.classroomId)

    const classId = userProfile?.classroomId
    const className = classroom?.className

    return (
        <Button
            disabled={!classId}
            iconLeft={
                classId ? <Icon24ShareExternalOutline /> : <LoadingSpinner />
            }
            onClick={
                classId
                    ? () => openAppShareDialog(classId, className)
                    : undefined
            }
        >
            Поделиться приложением
        </Button>
    )
}

export default ShareApp
