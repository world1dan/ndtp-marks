import { createContext } from 'react'

export interface IRadioGroupContext {
    selectedId: string | undefined
    handleSelect: (selectedId: string) => void
}

const RadioGroupContext = createContext({} as IRadioGroupContext)

export default RadioGroupContext
