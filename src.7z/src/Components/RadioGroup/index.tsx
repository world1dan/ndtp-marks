import { ReactNode } from 'react'

import { css } from '@linaria/core'

import RadioGroupContext from './RadioGroupContext'

const styles = css`
    display: flex;
    justify-content: space-between;
    gap: 6px;
    width: 100%;
`

export interface Props {
    value: string | undefined
    handleChange: (id: string) => void
    children?: ReactNode
}

const RadioGroup = ({ value, handleChange, children }: Props) => {
    return (
        <div className={styles}>
            <RadioGroupContext.Provider
                value={{
                    selectedId: value,
                    handleSelect: handleChange,
                }}
            >
                {children}
            </RadioGroupContext.Provider>
        </div>
    )
}

export default RadioGroup
