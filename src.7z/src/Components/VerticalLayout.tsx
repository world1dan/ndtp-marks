import { ReactNode } from 'react'

import { css, cx } from '@linaria/core'

const styles = css`
    display: flex;
    flex-direction: column;
    gap: 14px;
    padding: 14px;
    padding-bottom: calc(20px + env(safe-area-inset-bottom)) !important;

    &.noPadding {
        padding: 0;
    }

    @media (min-width: 500px) {
        padding: 20px;
    }

    @media (max-width: 400px) {
        padding: 10px;
    }

    @media (max-width: 330px) {
        padding: 0;

        > * {
            border-radius: 0;
        }
    }

    @media (min-width: 900px) {
        padding: 20px 35px;
    }
`

export interface Props {
    children: ReactNode
    noPadding?: boolean
}

const VerticalLayout = ({ children, noPadding }: Props) => {
    return (
        <div className={cx(styles, noPadding && 'noPadding')}>{children}</div>
    )
}

export default VerticalLayout
