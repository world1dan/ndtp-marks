import { css } from '@linaria/core'
import { IClassGroup } from 'Types/classGroup'

import { Icon24CheckCircleOff, Icon24CheckCircleOn } from '@vkontakte/icons'

const styles = css`
    background: var(--bg4);
    padding: 10px;
    border-radius: 7px;
    display: grid;
    grid-template-columns: 40px 1fr;
    align-items: center;
    justify-content: center;
    min-width: 270px;
    color: var(--text-on-primary-color);
    cursor: pointer;

    .group-info {
        font-size: 15px;
        font-weight: 600;
        gap: 8px;
    }
`

export interface Props extends IClassGroup {
    isSelected: boolean
    onClick: () => void
}

const ClassGroupItem = ({ isSelected, onClick, title, color }: Props) => {
    return (
        <div
            className={styles}
            onClick={onClick}
            style={{
                background: color,
            }}
        >
            {isSelected ? <Icon24CheckCircleOn /> : <Icon24CheckCircleOff />}
            <div className="group-info">{title}</div>
        </div>
    )
}

export default ClassGroupItem
