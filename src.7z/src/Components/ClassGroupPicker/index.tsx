import { useState } from 'react'

import { IClassGroup } from 'Types/classGroup'
import Stack from 'Components/Stack'
import ClassGroupItem from './ClassGroupItem'

export interface Props {
    classGroupsList: IClassGroup[]
    defaultGroup?: IClassGroup['id']
    handleChange: (classGroupId: IClassGroup['id']) => void
}

const ClassGroupPicker = ({
    classGroupsList,
    defaultGroup,
    handleChange,
}: Props) => {
    const [selectedClassGroupId, setSelectedClassGroupId] = useState<
        string | undefined
    >(defaultGroup)

    return (
        <Stack gap={10}>
            {classGroupsList.map((classGroup) => {
                return (
                    <ClassGroupItem
                        key={classGroup.id}
                        {...classGroup}
                        isSelected={selectedClassGroupId === classGroup.id}
                        onClick={() => {
                            setSelectedClassGroupId(classGroup.id)
                            handleChange(classGroup.id)
                        }}
                    />
                )
            })}
        </Stack>
    )
}

export default ClassGroupPicker
