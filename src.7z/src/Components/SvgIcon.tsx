export interface Props {
    icon: string
    width?: number
    height?: number
    color?: string
}

const SvgIcon = ({ icon, width = 24, height = 24, color }: Props) => {
    return (
        <img
            width={width}
            height={height}
            src={icon}
            style={{
                color: color,
            }}
        />
    )
}

export default SvgIcon
