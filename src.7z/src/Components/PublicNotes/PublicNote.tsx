import { css } from '@linaria/core'

import { Icon28UserCircleOutline } from '@vkontakte/icons'

import useUserProfile from 'Hooks/useUserProfile'

import { IPublicNote } from 'Types/publicNote'

const styles = css`
    display: flex;
    flex-direction: column;
    gap: 5px;
    margin-bottom: 50px;
    position: relative;

    .text {
        top: -5px;
        left: 10px;
        right: -20px;
        background-color: var(--bg4);
        font-size: 11px;
        font-weight: 600;
        padding: 3px 4px;
        border-radius: 5px 5px 5px 0;
        width: 100px;
        box-shadow: -6px 6px 6px #00000075;
        padding-bottom: 20px;
    }

    .avatar-container {
        width: 32px;
        height: 32px;
        background-color: var(--bg2);
        display: grid;
        place-items: center;
        border-radius: 50%;
        overflow: hidden;
        .avatar-placeholder {
            color: var(--text-secondary-color);
        }

        .avatar {
            object-fit: cover;
            display: block;
            width: 100%;

            &:not([src]) {
                display: none;
            }
        }
    }

    .user-info {
        position: absolute;
        display: flex;
        align-items: center;
        background-color: red;
        border-radius: 9px;
        bottom: -20px;
        left: -20px;
    }

    .name {
        padding: 0 10px;
        font-size: 11px;
        font-weight: 600;
        color: var(--text-color);
        text-align: center;
    }
`

export interface Props {
    publicNote?: IPublicNote
}

const PublicNote = ({
    publicNote = {
        createdBy: 'GoQSfb3VwkH0jJY3APfLDknzVmZ9',
        createdAt: new Date().getTime(),
        text: 'Рома лох цуйцуйцу йцу',
    },
}: Props) => {
    const { userProfile } = useUserProfile(publicNote.createdBy)

    if (!userProfile) return null

    return (
        <div className={styles}>
            <div className="user-info">
                <div className="avatar-container">
                    {userProfile.avatarURL ? (
                        <img
                            className="avatar"
                            src={userProfile.avatarURL}
                        ></img>
                    ) : (
                        <Icon28UserCircleOutline
                            width={30}
                            height={30}
                            className="avatar-placeholder"
                        />
                    )}
                </div>
                <div className="name">{userProfile.firstName}</div>
            </div>
            <div className="text">{publicNote.text}</div>
        </div>
    )
}
//<div className="text">{publicNote.text}</div>
export default PublicNote
