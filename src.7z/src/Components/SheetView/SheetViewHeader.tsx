import { css } from '@linaria/core'

import { Icon24Dismiss } from '@vkontakte/icons'

import TouchableWithEffect from 'Components/TouchableWithEffect'

const styles = css`
    height: 54px;
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    z-index: 1000;

    display: grid;
    grid-template-columns: 30px 1fr 30px;
    align-items: center;
    justify-content: center;
    padding: 0 12px;

    @media (min-width: 768px) {
        height: 58px;
    }

    background: var(--bg4-translucent);
    backdrop-filter: saturate(180%) blur(20px);
    box-shadow: 0 1px 0 0 var(--lvl4-borders);

    .title {
        grid-column: 2;
        text-align: center;
        font-weight: 600;
        font-size: 15px;
    }

    .close-button {
        color: var(--text-secondary-color);
        grid-column: 3;
    }
`

export interface Props {
    handleClose: () => void
    title?: string
}

const SheetViewHeader = ({ handleClose, title }: Props) => {
    return (
        <div className={styles}>
            {title && <div className="title">{title}</div>}

            <TouchableWithEffect onClick={handleClose} className="close-button">
                <Icon24Dismiss width={28} height={28} />
            </TouchableWithEffect>
        </div>
    )
}

export default SheetViewHeader
