import { MotionValue } from 'framer-motion'
import { createContext } from 'react'

export interface ISheetViewContext {
    scrollYProgress: MotionValue
}

const SheetViewContext = createContext({} as ISheetViewContext)

export default SheetViewContext
