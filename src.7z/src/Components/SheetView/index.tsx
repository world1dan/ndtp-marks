import { ReactNode, useMemo, useRef, useState } from 'react'

import { css, cx } from '@linaria/core'

import { AnimatePresence, motion, useScroll } from 'framer-motion'

import useKeyPress from 'Hooks/useKeyPress'
import usePageThemeColor from 'Hooks/usePageThemeColor'
import useSheetDrag from 'Hooks/useSheetDrag'

import Backdrop from '../Backdrop'
import ModalPortal from '../ModalPortal'
import SheetViewContext from './SheetViewContext'
import SheetViewHeader from './SheetViewHeader'

const styles = css`
    position: fixed;
    right: 0;
    left: 0;
    bottom: 0;
    overflow: hidden;
    top: 62px;

    &.height-fullscreen {
        top: 24px;
    }

    &.height-half-screen {
        top: 33%;
    }

    .content {
        overflow-y: auto;
        height: 100%;
        padding-top: 62px;
        padding-bottom: max(env(safe-area-inset-bottom), 14px);
        position: relative;

        &::-webkit-scrollbar {
            width: 0;
            display: none;
        }
    }

    background-color: var(--bg2);
    z-index: 999;
    border-radius: 13px 13px 0 0;

    animation: adaptive-panel-in 440ms cubic-bezier(0.38, 0.7, 0.125, 1) both;

    @keyframes adaptive-panel-in {
        from {
            transform: translateY(calc(100vh - 80px));
        }

        to {
            transform: translateY(0);
        }
    }

    margin: 0 auto;

    &.max-width-small {
        max-width: 500px;
    }

    &.max-width-normal {
        max-width: 620px;
    }

    &.max-width-large {
        max-width: 900px;
    }

    :global() {
        @media (max-width: 620px) {
            #root {
                transform: none;
                transition-property: transform, background-color, border-radius;
                transition-duration: 0.4s;
                background-color: var(--bg1);
                transform-origin: top;
            }

            body:has(.visible-sheet-view:not(.height-half-screen)) #root {
                overflow: hidden;
                border-radius: 16px 16px 0 0;
                background-color: var(--bg3);
                transform: scale(0.92) translateY(16px);
            }
        }
    }
`

export interface Props {
    maxWidth?: 'small' | 'normal' | 'large'
    height?: 'normal' | 'fullscreen' | 'half-screen'
    background?: string
    children?: ReactNode | ((closeSheet: () => void) => ReactNode)
    handleClose: () => void
    headerTitle?: string
}

const SheetView = ({
    children,
    handleClose,
    background,
    headerTitle,
    maxWidth = 'normal',
    height = 'normal',
}: Props) => {
    const [isVisible, setIsVisible] = useState(true)
    const ref = useRef<HTMLDivElement>(null)
    const contentRef = useRef<HTMLDivElement>(null)

    usePageThemeColor('var(--bg1)')

    const { scrollYProgress } = useScroll({
        container: contentRef,
    })

    const closeSheet = () => {
        setIsVisible(false)

        ref.current?.classList.remove('visible-sheet-view')
        ref.current?.animate([{ transform: 'translateY(100vh)' }], {
            duration: 220,
            easing: 'ease-in',
            fill: 'both',
        })
    }

    const { onPan, onPanStart, onPanEnd } = useSheetDrag({
        sheetRef: ref,
        sheetContentRef: contentRef,
        handleClose: closeSheet,
    })

    useKeyPress('Escape', closeSheet)

    const sheetViewContextValue = useMemo(
        () => ({
            scrollYProgress,
        }),
        [scrollYProgress]
    )

    return (
        <ModalPortal>
            <AnimatePresence onExitComplete={handleClose}>
                {isVisible && (
                    <Backdrop onClick={closeSheet}>
                        <motion.div
                            className={cx(
                                styles,
                                `max-width-${maxWidth}`,
                                `height-${height}`,
                                'visible-sheet-view'
                            )}
                            ref={ref}
                            onPan={onPan}
                            onPanStart={onPanStart}
                            onPanEnd={onPanEnd}
                            style={{
                                backgroundColor: background,
                            }}
                        >
                            <SheetViewContext.Provider
                                value={sheetViewContextValue}
                            >
                                <SheetViewHeader
                                    handleClose={closeSheet}
                                    title={headerTitle}
                                />
                                <div className="content" ref={contentRef}>
                                    {typeof children == 'function'
                                        ? children(closeSheet)
                                        : children}
                                </div>
                            </SheetViewContext.Provider>
                        </motion.div>
                    </Backdrop>
                )}
            </AnimatePresence>
        </ModalPortal>
    )
}

export default SheetView
