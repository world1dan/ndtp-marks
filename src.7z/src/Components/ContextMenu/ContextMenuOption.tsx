import { ReactNode } from 'react'
import { css } from '@linaria/core'

import { Icon24CheckCircleOn, Icon24CheckCircleOff } from '@vkontakte/icons'

const styles = css`
    background-color: var(--segmented-control-active-bg);
    padding: 6px;
    border-radius: 7px;
    display: grid;
    grid-template-columns: auto 1fr;
    align-items: center;
    justify-content: center;
    gap: 12px;
    min-height: 40px;
    min-width: 154px;
    box-shadow: 0 0 0 1.5px var(--lvl4-borders) inset;

    .option-content {
        font-weight: 600;
        font-size: 14px;
        text-align: left;
    }
`

export interface Props {
    children: ReactNode
    id: string | number
    isSelected?: boolean
    handleSelect?: (id: string | number) => void
}

const ContextMenuOption = ({
    children,
    id,
    isSelected,
    handleSelect,
}: Props) => {
    if (!handleSelect) return null

    return (
        <div className={styles} onClick={() => handleSelect(id)}>
            {isSelected ? <Icon24CheckCircleOn /> : <Icon24CheckCircleOff />}
            <div className="option-content">{children}</div>
        </div>
    )
}

export default ContextMenuOption
