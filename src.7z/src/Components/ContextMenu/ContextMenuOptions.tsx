import { Children, cloneElement, ReactElement } from 'react'

import { Props as ContextMenuOptionProps } from './ContextMenuOption'

export interface Props {
    children:
        | ReactElement<ContextMenuOptionProps>
        | Array<ReactElement<ContextMenuOptionProps>>
    value: number | string
    handleChange: (value: number | string) => void
}

const ContextMenuOptions = ({ children, value, handleChange }: Props) => {
    const arrayChildren = Children.toArray(children)

    if (arrayChildren.length == 0) return null

    return (
        <>
            {Children.map(
                // @ts-ignore
                arrayChildren,
                (child: ReactElement<ContextMenuOptionProps>) => {
                    return cloneElement(
                        // @ts-ignore
                        child as
                            | ReactElement<ContextMenuOptionProps>
                            | Array<ReactElement<ContextMenuOptionProps>>,
                        {
                            handleSelect: handleChange,
                            isSelected: value === child.props.id,
                        }
                    )
                }
            )}
        </>
    )
}

export default ContextMenuOptions
