import { ReactNode } from 'react'
import { css } from '@linaria/core'

import TouchableWithEffect from 'Components/TouchableWithEffect'

const styles = css`
    background-color: var(--bg4);
    border-radius: 7px;
    display: grid;
    gap: 2px;
    grid-template-columns: 35px 1fr;
    height: 44px;
    padding: 4px;
    place-items: center;
    min-width: 164px;

    .button-title {
        font-size: 14px;
        font-weight: 600;
        padding: 6px;
        text-align: left;
        width: 100%;
    }
`

export interface Props {
    onClick: () => void
    title: string
    icon: ReactNode
}

const ContextMenuBtn = ({ onClick, title, icon }: Props) => {
    return (
        <TouchableWithEffect className={styles} onClick={onClick}>
            {icon}
            <span className="button-title">{title}</span>
        </TouchableWithEffect>
    )
}

export default ContextMenuBtn
