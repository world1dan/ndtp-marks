import { CSSProperties, ReactNode, useEffect, useRef, useState } from 'react'

import { cx } from '@linaria/core'

import { Icon24MoreVertical } from '@vkontakte/icons'
import { CSSTransition } from 'react-transition-group'

import ModalPortal from 'Components/ModalPortal'

import './style.scss'

export interface Props {
    children: ReactNode
    icon?: ReactNode
    stayActiveOnClick?: boolean
    className?: string
    offsetTop?: number
    offsetLeft?: number
    position?: 'right' | 'left'
}

const ContextMenu = ({
    children,
    icon,
    stayActiveOnClick = false,
    position = 'right',
    className,
    offsetTop = 12,
    offsetLeft = -12,
}: Props) => {
    const [isOpen, setIsOpen] = useState(false)
    const [menuStyles, setMenuStyles] = useState<CSSProperties>()

    const buttonRef = useRef<HTMLButtonElement>(null)
    const menuRef = useRef<HTMLDivElement>(null)

    const handleOpen = () => {
        if (isOpen) return

        const openButton = buttonRef.current
        if (!openButton) throw new Error()

        const box = openButton.getBoundingClientRect()
        const x = (box.left + box.right) / 2 - offsetLeft
        let y = (box.top + box.bottom) / 2 + offsetTop

        let transformOrigin = undefined

        const useLeftPosition =
            position == 'left' ?? x + 200 < window.screen.height / 2

        if (y + 180 > window.screen.height) {
            y -= 100
            transformOrigin = 'bottom right'
        }

        if (useLeftPosition) {
            transformOrigin
                ? (transformOrigin += ' left')
                : (transformOrigin = 'top left')
        }

        setIsOpen(true)
        setMenuStyles({
            transform: useLeftPosition ? 'translateX(0)' : undefined,
            transformOrigin,
            top: y,
            left: x,
        })
    }

    // @ts-ignore
    useEffect(() => {
        if (isOpen) {
            const handleClose = (event: Event) => {
                const openButton = buttonRef.current
                const menu = menuRef.current
                const eventTarget = event.target

                if (!openButton || !menu) throw new Error()

                if (
                    eventTarget instanceof Element &&
                    (eventTarget == openButton ||
                        openButton.contains(eventTarget) ||
                        eventTarget == menu ||
                        menu.contains(eventTarget))
                )
                    return

                setIsOpen(false)
            }

            window.addEventListener('pointerdown', handleClose)
            window.addEventListener('wheel', handleClose)
            window.addEventListener('resize', handleClose)

            return () => {
                window.removeEventListener('pointerdown', handleClose)
                window.removeEventListener('wheel', handleClose)
                window.removeEventListener('resize', handleClose)
            }
        }
    }, [isOpen])

    return (
        <>
            <button
                ref={buttonRef}
                onClick={handleOpen}
                className={cx(
                    'context-menu-open-btn',
                    isOpen && 'active',
                    className
                )}
            >
                {icon ?? <Icon24MoreVertical />}
            </button>
            <CSSTransition
                in={isOpen}
                classNames="context-menu"
                unmountOnExit
                timeout={{
                    enter: 340,
                    exit: 160,
                }}
            >
                <ModalPortal>
                    <div className="menu-items-wraper" style={menuStyles}>
                        <div
                            className="menu-items"
                            ref={menuRef}
                            style={menuStyles}
                            onClick={
                                stayActiveOnClick
                                    ? undefined
                                    : () => setIsOpen(false)
                            }
                        >
                            {children}
                        </div>
                    </div>
                </ModalPortal>
            </CSSTransition>
        </>
    )
}

export default ContextMenu
