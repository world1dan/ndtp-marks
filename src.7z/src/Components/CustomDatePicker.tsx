import { InputHTMLAttributes, ReactNode } from 'react'

import { css } from '@linaria/core'

const styles = css`
    position: relative;
    height: 100%;

    .date-picker-toggle-button {
        display: flex;
        align-items: center;
        justify-content: center;
        position: absolute;
        left: 0;
        top: 0;
        height: 100%;
    }

    .date-picker-input {
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        opacity: 0;
        cursor: pointer;
        box-sizing: border-box;

        &::-webkit-calendar-picker-indicator {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            margin: 0;
            padding: 0;
            cursor: pointer;
        }
    }
`

export interface Props extends InputHTMLAttributes<HTMLInputElement> {
    children: ReactNode
}

const CustomDatePicker = ({ children, ...restProps }: Props) => {
    return (
        <div className={styles}>
            <div className="date-picker-toggle-button">{children}</div>
            <input className="date-picker-input" type="date" {...restProps} />
        </div>
    )
}

export default CustomDatePicker
