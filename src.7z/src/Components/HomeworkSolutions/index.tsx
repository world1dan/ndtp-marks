import SheetView from '../SheetView'
import { ILesson } from 'Types/lesson'
import useSubjects from 'Hooks/useSubjects'

import SolutionsGroup from './SolutionsGroup'

export interface Props {
    lessons: ILesson[]
    handleClose: () => void
}

const HomeworkSolutions = ({ lessons, handleClose }: Props) => {
    const subjects = useSubjects()

    if (!subjects) return null

    const groups = Object.values(lessons).map((lesson) => {
        const subject = subjects[lesson.id]

        if (!subject.solutionsURL || !lesson.hw) return

        const solutionsToShow = lesson.hw
            .replace(/ *\([^)]*\) */g, '')
            .split(',')
            .map((numString) => {
                const num = numString
                    .trim()
                    .replace(/[^\d.^\s.]/g, '')
                    .split(' ')
                    .filter((v) => v !== '')[0]

                if (!num) return null

                return parseInt(num?.includes('.') ? num?.split('.')[1] : num)
            })
            .filter((element): element is number => {
                return element !== null
            })

        return (
            <SolutionsGroup
                key={lesson.id}
                subject={subject}
                solutionsToShow={solutionsToShow}
                hw={lesson.hw}
            />
        )
    })

    return (
        <SheetView
            height="fullscreen"
            handleClose={handleClose}
            headerTitle="Решение"
        >
            {groups}
        </SheetView>
    )
}

export default HomeworkSolutions
