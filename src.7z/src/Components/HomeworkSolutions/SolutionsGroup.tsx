import SolutionBox from 'Components/SolutionBox'

import { css } from '@linaria/core'
import { ISubject } from 'Types/subjects'
import useLocalStorage from 'Hooks/useLocalStorage'
import { ISelectedChapters } from 'Pages/SolutionsSearch/Header'
import ChapterSelect from 'Pages/SolutionsSearch/ChapterSelect'

const styles = css`
    display: flex;
    gap: 6px;
    padding: 10px;

    .title {
        color: #fff;
        font-size: 14px;
        font-weight: bold;
        width: 100px;
        flex-shrink: 0;
    }

    .homework {
        box-shadow: 0 0 0 1.5px var(--borders-soft) inset;
        flex-grow: 1;
        font-size: 13px;
        font-weight: 600;
        overflow-x: auto;
        padding: 0 10px;
        white-space: nowrap;
        overflow-y: hidden;
    }

    .block {
        background-color: var(--bg4);
        border-radius: 6px;
        height: 38px;
        line-height: 38px;
        text-align: center;
    }
`

const chapterSelectStyles = css`
    padding: 10px;
    padding-top: 0;
`

export interface Props {
    subject: ISubject
    hw: string
    solutionsToShow: number[]
}

const SolutionsGroup = ({ subject, solutionsToShow, hw }: Props) => {
    const [selectedChapters, setSelectedChapters] =
        useLocalStorage<ISelectedChapters>('latest-used-chapters')

    const chapterId =
        selectedChapters?.[subject.id] ?? subject?.solutions?.chapters?.[0]?.id

    return (
        <>
            <div className={styles}>
                <div
                    className="title block"
                    style={{
                        backgroundColor: subject.color,
                    }}
                >
                    {subject.title}
                </div>
                <div className="homework block">{hw}</div>
            </div>
            {subject?.solutions?.chapters?.length && (
                <div className={chapterSelectStyles}>
                    <ChapterSelect
                        chapters={subject?.solutions?.chapters}
                        selectedChapterId={chapterId}
                        handleChange={(id) =>
                            setSelectedChapters({
                                ...selectedChapters,
                                [subject?.id]: id,
                            })
                        }
                    />
                </div>
            )}

            {solutionsToShow.map((num, key) => (
                <SolutionBox
                    key={key}
                    subject={subject}
                    startNum={num}
                    chapterId={chapterId}
                />
            ))}
        </>
    )
}

export default SolutionsGroup
