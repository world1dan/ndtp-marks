import {
    useState,
    ReactElement,
    // @ts-ignore
    unstable_Offscreen as Offscreen,
} from 'react'

import { useOutlet, useLocation } from 'react-router-dom'

const StillnessOutLets = () => {
    const outlet = useOutlet()
    const [outlets, setOutlets] = useState<
        {
            key: string
            pathname: string
            outlet: ReactElement | null
        }[]
    >([])

    const location = useLocation()
    const locationPathname = location.pathname

    const result = outlets.some((o) => o.pathname === locationPathname)

    if (!result) {
        const newOutlet = {
            key: location.key,
            pathname: locationPathname,
            outlet,
        }
        setOutlets([...outlets, newOutlet])
    }

    return (
        <>
            {outlets.map((outlet) => {
                return (
                    <Offscreen
                        key={outlet.key}
                        mode={
                            locationPathname === outlet.pathname
                                ? 'visible'
                                : 'hidden'
                        }
                    >
                        {outlet.outlet}
                    </Offscreen>
                )
            })}
        </>
    )
}

export default StillnessOutLets
