import { useState } from 'react'

import {
    Icon24Cancel,
    Icon24ChevronLeft,
    Icon24ChevronRight,
} from '@vkontakte/icons'

import MediaViewer from 'Components/MediaViewer'
import TouchableWithEffect from 'Components/TouchableWithEffect'

import './style.scss'

import { ISubject } from 'Types/subjects'

export const getSolutionImagesUrls = (
    subject: ISubject,
    num: number,
    chapterId?: string
) => {
    const urls = []

    if (!subject.solutionsURL) return null

    if (subject.solutionsURL.includes('{auto-num}')) {
        const baseUrl = subject.solutionsURL.replace('{num}', num.toString())

        for (let i = 1; i < 10; i++) {
            const url = baseUrl.replace('{auto-num}', i.toString())

            urls.push(url)
        }
    } else {
        let baseUrl = subject.solutionsURL.replace('?', num.toString())

        if (chapterId && baseUrl.includes('{chapter}')) {
            baseUrl = baseUrl.replace('{chapter}', chapterId)
        }

        urls.push(baseUrl)
    }

    return urls
}

export interface Props {
    subject: ISubject
    startNum: number
    chapterId?: string
    handleRemove?: () => void
}

const SolutionBox = ({ subject, startNum, handleRemove, chapterId }: Props) => {
    const [mediaViewerIndex, setMediaViewerIndex] = useState<number>()
    const [num, setNum] = useState(startNum)

    const openAltSolution = () => {
        const url = subject.altSolutionsURL?.replace('?', num.toString())

        window.open(url, '_blank')
    }

    const imagesUrls = getSolutionImagesUrls(subject, num, chapterId)

    return (
        <>
            <div className="hwr-sol-tools">
                {subject.altSolutionsURL && (
                    <button
                        className="block alt-solution-btn"
                        onClick={openAltSolution}
                    >
                        Решебник 2
                    </button>
                )}
                <div className="center-section block">
                    <TouchableWithEffect onClick={() => setNum(num - 1)}>
                        <Icon24ChevronLeft />
                    </TouchableWithEffect>

                    <button className="num">
                        {subject.solutionsUnit && (
                            <small>{subject.solutionsUnit + ' '}</small>
                        )}
                        {num}
                    </button>

                    <TouchableWithEffect onClick={() => setNum(num + 1)}>
                        <Icon24ChevronRight />
                    </TouchableWithEffect>
                </div>
                {handleRemove && (
                    <TouchableWithEffect
                        className="block close-btn"
                        onClick={handleRemove}
                    >
                        <Icon24Cancel />
                    </TouchableWithEffect>
                )}
            </div>

            <div className="hwr-sol-imgs">
                {imagesUrls?.map((url, i) => (
                    <img
                        key={url}
                        src={url}
                        width="100%"
                        onClick={() => setMediaViewerIndex(i)}
                        onError={(e) =>
                            (e.currentTarget.style.display = 'none')
                        }
                    />
                ))}
            </div>

            {mediaViewerIndex !== undefined && imagesUrls && (
                <MediaViewer
                    startIndex={mediaViewerIndex}
                    handleClose={() => setMediaViewerIndex(undefined)}
                    medias={imagesUrls?.map((url) => ({
                        url,
                        type: 'image',
                        caption: `${subject.title} - ${subject.solutionsUnit} ${num}`,
                    }))}
                />
            )}
        </>
    )
}

export default SolutionBox
