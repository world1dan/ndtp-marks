import { ReactNode } from 'react'

import { css, cx } from '@linaria/core'

const styles = css`
    margin: 10px 0;

    &.h1 {
        font-size: 34px;
        margin: 14px 0;
    }

    &.h3 {
        margin: 10px 0;
        font-size: 24px;
    }
`

export interface Props {
    children?: ReactNode
    type?: 'h1' | 'h2' | 'h3' | 'h4' | 'h5' | 'default'
}

const Text = ({ children, type = 'h5' }: Props) => {
    let TextElement = 'div'

    if (['h1', 'h2', 'h3', 'h4', 'h5'].includes(type ?? '')) {
        TextElement = type
    }

    return <TextElement className={cx(styles, type)}>{children}</TextElement>
}

export default Text
