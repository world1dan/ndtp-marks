import { useState } from 'react'

import { css } from '@linaria/core'

import { motion } from 'framer-motion'

import UserProfile from 'Pages/UserProfile'

import useUserProfile from 'Hooks/useUserProfile'

import LoadingSpinner from './LoadingSpinner'

const styles = css`
    display: flex;
    gap: 10px;
    align-items: center;
    font-size: 14px;
    font-weight: 500;
    text-decoration: underline;

    .avatar {
        display: block;
        object-fit: cover;
        width: 28px;
        height: 28px;
        border-radius: 50%;
    }
`

export interface Props {
    uid: string | undefined
    additionalText?: string
}

const UserProfileLink = ({ uid, additionalText }: Props) => {
    const [userProfileOpen, setUserProfileOpen] = useState(false)
    const { userProfile } = useUserProfile(uid)

    return (
        <>
            {userProfile ? (
                <motion.div
                    onClick={() => setUserProfileOpen(true)}
                    className={styles}
                    transition={{
                        type: 'tween',
                        duration: 0.1,
                    }}
                    whileTap={{
                        opacity: 0.5,
                    }}
                >
                    <img className="avatar" src={userProfile?.avatarURL} />
                    {userProfile?.firstName + userProfile?.lastName
                        ? ' ' + userProfile?.lastName
                        : ''}
                    {additionalText ? ',' + additionalText : ''}
                </motion.div>
            ) : (
                <LoadingSpinner height={28} />
            )}
            {userProfileOpen && uid && (
                <UserProfile
                    uid={uid}
                    handleClose={() => setUserProfileOpen(false)}
                />
            )}
        </>
    )
}

export default UserProfileLink
