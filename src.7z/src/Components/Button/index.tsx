import { CSSProperties, HTMLAttributes, ReactNode } from 'react'

import { css, cx } from '@linaria/core'

import TouchableWithEffect from 'Components/TouchableWithEffect'

const styles = css`
    display: flex;
    align-items: center;
    text-align: center;
    line-height: 1;
    justify-content: center;
    width: 100%;
    color: var(--text-color);
    background: var(--bg4);
    border-radius: 7px;
    font-weight: 600;
    font-size: 14px;
    transition: opacity 0.2s;
    position: relative;

    &[disabled] {
        opacity: 0.5;
        pointer-events: none;
        background-color: var(--bg4) !important;
    }

    &.primary:not([disabled]) {
        background-color: var(--primary-color);
        color: var(--text-on-primary-color);
    }

    &.destructive {
        color: var(--red);
    }

    &.small {
        height: 32px;
        padding: 0 6px;
    }

    &.medium {
        height: 40px;
        padding: 0 16px;
    }

    &.large {
        height: 48px;
        padding: 0 24px;
    }

    .icon {
        position: absolute;
        display: grid;
        place-items: center;
        margin: auto 0;
    }

    &.large .icon {
        &.right {
            right: 10px;
        }

        &.left {
            left: 10px;
        }
    }

    &.medium .icon {
        &.right {
            right: 8px;
        }

        &.left {
            left: 8px;
        }
    }

    &.small .icon {
        &.right {
            right: 4px;
        }

        &.left {
            left: 4px;
        }
    }
`

export interface Props extends HTMLAttributes<HTMLButtonElement> {
    children?: ReactNode
    size?: 'small' | 'medium' | 'large'
    appearance?: 'default' | 'destructive' | 'primary'
    disabled?: boolean
    iconRight?: ReactNode
    iconLeft?: ReactNode
    borderRadius?: CSSProperties['borderRadius']
    backgroundColor?: CSSProperties['backgroundColor']
}

const Button = ({
    children,
    className,
    size = 'medium',
    appearance = 'default',
    disabled,
    iconLeft,
    iconRight,
    style,
    borderRadius,
    backgroundColor,
    ...restProps
}: Props) => {
    return (
        <TouchableWithEffect
            className={cx(styles, className, size, appearance)}
            effect={disabled ? null : 'opacity'}
            disabled={disabled}
            style={{
                borderRadius,
                backgroundColor,
                ...style,
            }}
            {...restProps}
        >
            {iconLeft && <span className="icon left">{iconLeft}</span>}
            {children}
            {iconRight && <span className="icon right">{iconRight}</span>}
        </TouchableWithEffect>
    )
}

export default Button
