import { css } from '@linaria/core'
import { CSSProperties } from 'react'

const styles = css`
    height: 9px;
    border-radius: 10px;
    overflow: hidden;
    position: relative;
    display: flex;

    .remaining {
        width: 100%;
        opacity: 0.3;
    }

    .completed {
        position: absolute;
        left: 0;
        top: 0;
        bottom: 0;
        border-radius: 10px;
        transition: width 240ms ease-in-out;
    }
`

export interface Props {
    percent: number
    color: CSSProperties['backgroundColor']
}

const ProgressBar = ({ percent, color }: Props) => {
    return (
        <div className={styles}>
            <div
                className="remaining"
                style={{
                    backgroundColor: color,
                }}
            />
            <div
                className="completed"
                style={{
                    backgroundColor: color,
                    width: `${percent}%`,
                }}
            />
        </div>
    )
}

export default ProgressBar
