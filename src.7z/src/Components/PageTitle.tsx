import { css, cx } from '@linaria/core'
import { HTMLAttributes, ReactNode } from 'react'

const styles = css`
    font-size: 32px;
    font-weight: bold;
    margin: 0;

    @media (max-width: 600px) {
        font-size: 27px;
        padding-left: 14px;
    }
`

export interface Props extends HTMLAttributes<HTMLHeadingElement> {
    children: ReactNode
}

const PageTitle = ({ children, className, ...restProps }: Props) => {
    return (
        <h1 className={cx(styles, className)} {...restProps}>
            {children}
        </h1>
    )
}

export default PageTitle
