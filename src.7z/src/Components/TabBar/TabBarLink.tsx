import { ReactNode } from 'react'

import { css } from '@linaria/core'

import { NavLink, NavLinkProps } from 'react-router-dom'

const styles = css`
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    color: var(--tab-bar-btn);
    flex-grow: 1;
    max-width: 205px;
    transition-duration: 0.18s;
    transition-property: transform, opacity, color;

    &.active {
        color: var(--tab-bar-btn-active);
        transition-duration: 0.3s;
        transition-property: transform, opacity, color;
    }

    &:active {
        transform: scale(0.92);
        opacity: 0.6;
    }

    .title {
        font-size: 14px;
        font-weight: 600;
    }

    @media (max-width: 660px) {
        flex-direction: column;
        gap: 1px;

        .title {
            font-size: 10px;
            font-weight: 600;
        }
    }
`

export interface Props extends NavLinkProps {
    icon: ReactNode
    title: string
}

const TabBarLink = ({ icon, title, replace, ...restProps }: Props) => {
    return (
        <NavLink className={styles} replace={replace} {...restProps}>
            {icon}
            <span className="title">{title}</span>
        </NavLink>
    )
}

export default TabBarLink
