import { ReactNode } from 'react'

import { css } from '@linaria/core'

import ModalPortal from 'Components/ModalPortal'

const styles = css`
    position: fixed;
    right: 0;
    bottom: 0;
    left: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    height: var(--tab-bar-height);
    box-sizing: content-box;

    padding-right: env(safe-area-inset-right);
    padding-bottom: env(safe-area-inset-bottom);
    padding-left: env(safe-area-inset-left);

    background-color: var(--bg2);
    border-top: 1px solid var(--borders);
    touch-action: none;
    z-index: 99;
`

export interface ITabBarProps {
    children: ReactNode
}

const TabBar = ({ children }: ITabBarProps) => {
    return (
        <ModalPortal>
            <div className={styles}>{children}</div>
        </ModalPortal>
    )
}

export default TabBar
