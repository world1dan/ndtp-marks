
import StaticWeatherIcons from './static'

export { StaticWeatherIcons }
