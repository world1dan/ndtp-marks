import images from 'Assets/icons/images.svg'

const ImagesIcon = () => {
    return <img src={images} width="22px" />
}

export default ImagesIcon
