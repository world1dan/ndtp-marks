import link from 'Assets/icons/link.svg'

const LinkIcon = () => {
    return <img src={link} width="22px" />
}

export default LinkIcon
