import { css, cx } from '@linaria/core'

import { Icon20ChevronRight } from '@vkontakte/icons'
import { motion } from 'framer-motion'

const styles = css`
    padding: 6px;
    display: flex;
    justify-content: space-between;
    position: relative;
    align-items: center;

    .arrow {
        color: var(--text-secondary-color);
    }

    .step {
        background-color: var(--bg3);
        border-radius: 50%;
        width: 26px;
        height: 26px;
        display: grid;
        place-items: center;
        font-size: 12px;
        font-weight: bold;
        color: var(--text-secondary-color);
        position: relative;
        transition-duration: 600ms;

        span {
            z-index: 2;
        }

        &.completed {
            background: var(--bg4);
        }

        &.active {
            color: var(--text-on-primary-color);
        }
    }

    .active-step-indicator {
        position: absolute;
        right: 0;
        top: 0;
        left: 0;
        bottom: 0;
        background: var(--primary-color);
        border-radius: 50%;
        z-index: 1;
    }
`

export interface Props {
    stepsCount?: number
    currentStep: number
}

const ProgressBarWithSteps = ({ stepsCount = 4, currentStep = 2 }: Props) => {
    return (
        <div className={styles}>
            {new Array(stepsCount).fill(0).map((_, i) => (
                <>
                    <div
                        key={i}
                        className={cx(
                            'step',
                            i < currentStep && 'completed',
                            i == currentStep && 'active'
                        )}
                    >
                        <span>{i + 1}</span>
                        {i == currentStep && (
                            <motion.div
                                layout
                                layoutId="ffft "
                                className="active-step-indicator"
                                transition={{ duration: 0.23 }}
                            />
                        )}
                    </div>
                    {i !== stepsCount - 1 && (
                        <Icon20ChevronRight
                            className="arrow"
                            key={i + 'arrow'}
                        />
                    )}
                </>
            ))}
        </div>
    )
}

export default ProgressBarWithSteps
