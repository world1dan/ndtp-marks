import { useEffect, useRef, useState } from 'react'

import { css } from '@linaria/core'

import {
    motion,
    useDragControls,
    useMotionTemplate,
    useMotionValue,
    useTransform,
} from 'framer-motion'
import { useAudioPosition } from 'react-use-audio-player'

import useInterval from 'Hooks/useInterval'

const styles = css`
    position: relative;
    width: 100%;
    margin-top: 25px;

    .wrapper {
        position: relative;
    }

    .full-bar {
        width: 100%;
        border-radius: 9999px;
        height: 3px;
        background: #5a526f;
    }

    .filler {
        position: absolute;
        top: 0;

        .a {
            position: absolute;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            border-radius: 9999px;
            height: 3px;
            background: #a29cc0;
        }
    }

    .constrains {
        position: absolute;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
    }

    .scrubber {
        display: flex;
        position: absolute;
        justify-content: center;
        padding: 0;
        margin: 0;
        top: -15px;
        left: -15px;
        align-items: center;
        border-radius: 9999px;

        .scrubber-fill {
            border-radius: 9999px;
            width: 33px;
            height: 33px;
            background: #a29cc0;
        }
    }
`

export interface Props {
    playing: boolean
}

const PlayBar = ({ playing }: Props) => {
    const {
        duration,
        seek: setCurrentTime,
        position: currentTime,
    } = useAudioPosition()

    const [dragging, setDragging] = useState(false)
    const constraintsRef = useRef<HTMLDivElement>(null)
    const fullBarRef = useRef<HTMLDivElement>(null)
    const scrubberRef = useRef<HTMLButtonElement>(null)
    const scrubberX = useMotionValue(0)
    const currentTimePrecise = useMotionValue(currentTime)
    const progressPrecise = useTransform(
        currentTimePrecise,
        (v) => (v / duration) * 100
    )

    const progressPreciseWidth = useMotionTemplate`${progressPrecise}%`
    const dragControls = useDragControls()

    const mins = Math.floor(currentTime / 60)
    const secs = `${currentTime % 60}`.padStart(2, '0')
    const timecode = `${mins}:${secs}`
    const minsRemaining = Math.floor((duration - currentTime) / 60)
    const secsRemaining = `${(duration - currentTime) % 60}`.padStart(2, '0')
    const timecodeRemaining = `${minsRemaining}:${secsRemaining}`
    const progress = (currentTime / duration) * 100

    useEffect(() => {
        currentTimePrecise.set(currentTime)
    }, [currentTime])

    useInterval(
        () => {
            if (currentTime < duration) {
                currentTimePrecise.set(currentTimePrecise.get() + 0.01)

                const newX = getXFromProgress({
                    containerRef: fullBarRef,
                    progress: currentTimePrecise.get() / duration,
                })
                scrubberX.set(newX)
            }
        },
        playing ? 10 : null
    )

    return (
        <div className={styles}>
            <div
                className="wrapper"
                onPointerDown={(event) => {
                    const newProgress = getProgressFromX({
                        containerRef: fullBarRef,
                        x: event.clientX,
                    })
                    dragControls.start(event, { snapToCursor: true })
                    setCurrentTime(Math.floor(newProgress * duration))
                    currentTimePrecise.set(newProgress * duration)
                }}
            >
                <div ref={fullBarRef} className="full-bar" />
                <motion.div
                    layout
                    style={{ width: progressPreciseWidth }}
                    className="filler"
                >
                    <div className="a"></div>
                </motion.div>
                <div className="constrains" ref={constraintsRef}>
                    <motion.button
                        ref={scrubberRef}
                        drag="x"
                        dragConstraints={constraintsRef}
                        dragControls={dragControls}
                        dragElastic={0}
                        dragMomentum={false}
                        style={{ x: scrubberX }}
                        onDragStart={() => {
                            setDragging(true)
                        }}
                        onPointerDown={() => {
                            setDragging(true)
                        }}
                        onPointerUp={() => {
                            setDragging(false)
                            if (!scrubberRef.current) return

                            const scrubberBounds =
                                scrubberRef.current.getBoundingClientRect()
                            const middleOfScrubber =
                                scrubberBounds.x + scrubberBounds.width / 2
                            const newProgress = getProgressFromX({
                                containerRef: fullBarRef,
                                x: middleOfScrubber,
                            })
                            setCurrentTime(Math.floor(newProgress * duration))
                            currentTimePrecise.set(newProgress * duration)
                        }}
                        onDragEnd={() => {
                            setDragging(false)
                        }}
                        className="scrubber"
                    >
                        <motion.div
                            animate={{ scale: dragging ? 0.6 : 0.25 }}
                            transition={{ type: 'tween', duration: 0.15 }}
                            initial={false}
                            className="scrubber-fill"
                        ></motion.div>
                    </motion.button>
                </div>
            </div>
        </div>
    )
}

export default PlayBar

function getProgressFromX({ x, containerRef }) {
    const bounds = containerRef.current.getBoundingClientRect()
    const progress = (x - bounds.x) / bounds.width

    return clamp(progress, 0, 1)
}

function getXFromProgress({ progress, containerRef }) {
    const bounds = containerRef.current.getBoundingClientRect()

    return progress * bounds.width
}

function clamp(number, min, max) {
    return Math.max(min, Math.min(number, max))
}
