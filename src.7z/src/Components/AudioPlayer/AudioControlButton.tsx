import { css } from '@linaria/core'

import { HTMLMotionProps, motion } from 'framer-motion'

const styles = css``

export type Props = HTMLMotionProps<'button'>

const AudioControlButton = ({ children, ...restProps }: Props) => {
    return (
        <motion.button whileTap={{ scale: 0.84 }} {...restProps}>
            {children}
        </motion.button>
    )
}

export default AudioControlButton
