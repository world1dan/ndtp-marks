import { css } from '@linaria/core'

import {
    Icon28Forward10Outline,
    Icon28Replay10Outline,
    Icon32PauseCircle,
    Icon32PlayCircle,
    Icon36Pause,
    Icon36Play,
} from '@vkontakte/icons'
import { useAudioPosition } from 'react-use-audio-player'

import AudioControlButton from './AudioControlButton'

const styles = css`
    padding: 20px;
    display: flex;
    width: 100%;
    gap: 16px;
    justify-content: center;
    align-items: center;
`

export interface Props {
    isPlaying: boolean
    togglePlayPause: () => void
}

const PlaybackControls = ({ isPlaying, togglePlayPause }: Props) => {
    const { seek, position } = useAudioPosition()

    const forward = () => seek(position + 10)
    const replay = () => seek(position - 10)

    return (
        <div className={styles}>
            <AudioControlButton onClick={replay}>
                <Icon28Replay10Outline />
            </AudioControlButton>
            <AudioControlButton onClick={togglePlayPause}>
                {!isPlaying ? (
                    <Icon36Play width={42} height={42} />
                ) : (
                    <Icon36Pause width={42} height={42} />
                )}
            </AudioControlButton>
            <AudioControlButton onClick={forward}>
                <Icon28Forward10Outline />
            </AudioControlButton>
        </div>
    )
}

export default PlaybackControls
