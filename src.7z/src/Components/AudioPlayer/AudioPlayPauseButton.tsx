import { css } from '@linaria/core'

import { Icon32PauseCircle, Icon32PlayCircle } from '@vkontakte/icons'
import { motion } from 'framer-motion'

const styles = css``
export interface Props {
    isPlaying: boolean
    onClick: () => void
}

const AudioPlayPauseButton = ({ isPlaying, onClick }: Props) => {
    return (
        <motion.button onClick={onClick}>
            {!isPlaying ? <Icon32PlayCircle /> : <Icon32PauseCircle />}
        </motion.button>
    )
}

export default AudioPlayPauseButton
