import { css } from '@linaria/core'

import { AudioPlayerProvider, useAudioPlayer } from 'react-use-audio-player'

import PlayBar from './PlayBar'
import PlaybackControls from './PlaybackControls'

const styles = css`
    padding: 8px;
    background-color: var(--bg4);
    border-radius: 9px;
    margin: 12px;
`

export interface Props {
    file: string
}

const withAudioPlayerProvider = (Component: ({ file }: Props) => JSX.Element) =>
    function (props: Props) {
        return (
            <AudioPlayerProvider>
                <Component {...props} />
            </AudioPlayerProvider>
        )
    }

const AudioPlayer = ({ file }: Props) => {
    const { togglePlayPause, ready, loading, playing } = useAudioPlayer({
        src: file,
        autoplay: true,
        onend: () => console.log('sound has ended!'),
    })

    return (
        <div className={styles}>
            <PlayBar playing={playing} />
            <PlaybackControls
                isPlaying={playing}
                togglePlayPause={togglePlayPause}
            />
        </div>
    )
}

export default withAudioPlayerProvider(AudioPlayer)
