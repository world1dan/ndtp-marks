import { CSSProperties, useEffect, useState } from 'react'

import { css } from '@linaria/core'

const styles = css`
    display: grid;
    gap: 6px;
    overflow: hidden;

    .row {
        background: var(--bg2);
        border-radius: 5px;
        animation: 1.4s loader-animation infinite;
    }

    @keyframes loader-animation {
        0% {
            filter: brightness(1);
        }

        50% {
            filter: brightness(1.6);
        }

        100% {
            filter: brightness(1);
        }
    }

    @media (min-width: 700px) {
        &.two-columns {
            grid-template-columns: 1fr 1fr;
        }
    }
`

export interface ISuspenseProps {
    children: React.ReactNode
    delay?: number
    rowsCount?: number
    rowsHeight?: number
    twoColumns?: boolean
    style?: CSSProperties
    rowsStyle?: CSSProperties
    forceLoadingState?: boolean
}

const Suspense = ({
    children,
    delay = 300,
    rowsCount = 10,
    rowsHeight = 50,
    twoColumns,
    style,
    rowsStyle,
    forceLoadingState,
}: ISuspenseProps) => {
    const [loading, setLoading] = useState(true)

    useEffect(() => {
        const timeout = setTimeout(() => setLoading(false), delay)

        return () => clearTimeout(timeout)
    }, [delay])

    return loading || forceLoadingState ? (
        <div
            className={styles + (twoColumns ? ' two-columns' : '')}
            style={style}
        >
            {new Array(rowsCount).fill(0).map((_, i) => {
                return (
                    <div
                        className="row"
                        key={i}
                        style={{
                            animationDelay: i * 25 + 'ms',
                            height: rowsHeight,
                            ...rowsStyle,
                        }}
                    />
                )
            })}
        </div>
    ) : (
        (children as JSX.Element)
    )
}

export default Suspense
