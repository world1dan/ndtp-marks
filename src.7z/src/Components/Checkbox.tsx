import { css } from '@linaria/core'

import { AnimatePresence, motion } from 'framer-motion'
import { Icon24CheckCircleOn } from '@vkontakte/icons'

const styles = css`
    background-color: var(--bg4);
    padding: 7px;
    box-sizing: content-box;
    border-radius: 50%;
    color: var(--green);
`

export interface Props {
    isChecked: boolean
    handleChange: (isChecked: boolean) => void
    size?: number
}

const Checkbox = ({ isChecked, handleChange, size = 20 }: Props) => {
    return (
        <div
            className={styles}
            style={{
                width: size,
                height: size,
            }}
            onClick={() => handleChange(!isChecked)}
        >
            <AnimatePresence>
                {isChecked && (
                    <motion.div
                        initial={{ scale: 0.6, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        exit={{ scale: 0, opacity: 0 }}
                    >
                        <Icon24CheckCircleOn width={size} height={size} />
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    )
}

export default Checkbox
