import { isWithinInterval } from 'date-fns'
import { ISchoolQuarter } from 'Types/schoolQuarter'

import { getCurrentSchoolYearRange } from './getSchoolWeeks'

const getCurrentSchoolQuarter = (): ISchoolQuarter | undefined => {
    return getCurrentSchoolYearRange().quarters.find((quarter) => {
        return isWithinInterval(new Date(), {
            start: quarter.start,
            end: quarter.end,
        })
    })
}

export default getCurrentSchoolQuarter
