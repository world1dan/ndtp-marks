import Compressor from 'compressorjs'

const compressImage = async (
    image: File | Blob,
    options?: Compressor.Options
) => {
    if (image.type == 'image/gif') return image

    const compressedImage: Blob | File = await new Promise(
        (resolve, reject) => {
            new Compressor(image, {
                ...options,

                success(compressedImage) {
                    resolve(compressedImage)
                },
                error(error) {
                    reject(error)
                },
            })
        }
    )

    return compressedImage
}

export default compressImage
