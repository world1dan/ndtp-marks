const isStandalone = () => {
    return window.matchMedia('(display-mode: standalone)').matches
}

export default isStandalone
