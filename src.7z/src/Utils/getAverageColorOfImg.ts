import { FastAverageColor } from 'fast-average-color'

const getAverageColorOfImg = async (imageElement: HTMLImageElement) => {
    const fac = new FastAverageColor()

    return fac.getColorAsync(imageElement, {
        step: 100,
        ignoredColor: [
            [255, 255, 255, 255], // white
            [0, 0, 0, 255], // black
        ],
    })
}

export default getAverageColorOfImg
