import { addWeeks, areIntervalsOverlapping, eachWeekOfInterval } from 'date-fns'
import ru from 'date-fns/locale/ru'

import { ISchoolQuarter } from 'Types/schoolQuarter'
import { IWeekInfo } from 'Types/timetable'

interface ISchoolYear {
    start: Date
    end: Date
    quarters: ISchoolQuarter[]
}

export const getCurrentSchoolYearRange = (): ISchoolYear => {
    const currentDate = new Date()
    const currentYear = currentDate.getFullYear()
    const schoolYearStartYear =
        currentDate.getMonth() >= 5 ? currentYear : currentYear - 1

    return {
        start: new Date(schoolYearStartYear, 8, 1),
        end: new Date(schoolYearStartYear + 1, 4, 31),
        quarters: [
            {
                num: 1,
                start: new Date(schoolYearStartYear, 8, 1),
                end: new Date(schoolYearStartYear, 9, 31),
            },
            {
                num: 2,
                start: new Date(schoolYearStartYear, 10, 7),
                end: new Date(schoolYearStartYear, 11, 25),
            },
            {
                num: 3,
                start: new Date(schoolYearStartYear + 1, 0, 9),
                end: new Date(schoolYearStartYear + 1, 2, 26),
            },
            {
                num: 4,
                start: new Date(schoolYearStartYear + 1, 3, 3),
                end: new Date(schoolYearStartYear + 1, 5, 31),
            },
        ],
    }
}

const getQuarterOfWeek = (
    schoolYear: ISchoolYear,
    week: Interval
): ISchoolQuarter | undefined => {
    return schoolYear.quarters.find((quarter: Interval) => {
        return areIntervalsOverlapping(quarter, week)
    })
}

const getSchoolWeeks = (): IWeekInfo[] => {
    const schoolYear = getCurrentSchoolYearRange()
    const eachWeekStart = eachWeekOfInterval(schoolYear, {
        locale: ru,
    })

    return eachWeekStart.map((weekStart) => {
        const weekInterval = {
            start: weekStart,
            end: addWeeks(weekStart, 1),
        }

        const quarter = getQuarterOfWeek(schoolYear, weekInterval) // undefined if week is holiday

        return {
            quarter: getQuarterOfWeek(schoolYear, weekInterval),
            isHolidays: !quarter,
            ...weekInterval,
        }
    })
}

export default getSchoolWeeks
