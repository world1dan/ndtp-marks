import { getBlob, StorageReference } from 'firebase/storage'

const shareImageFromStorage = async (
    imageRef: StorageReference,
    shareOptions?: Omit<ShareData, 'files'>
) => {
    const blob = await getBlob(imageRef)
    const filename = imageRef.name + '.' + blob.type.split('/')[1]

    const filesArray = [
        new File([blob], filename, {
            type: blob.type,
            lastModified: new Date().getTime(),
        }),
    ]

    navigator.share({
        files: filesArray,
        ...shareOptions,
    })
}

export default shareImageFromStorage
