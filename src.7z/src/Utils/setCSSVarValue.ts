const cssVariableRegex = /var\((--[a-zA-Z0-9-_]+),? ?([a-zA-Z0-9 ()%#.,-]+)?\)/

const parseCSSVar = (CSSVar: string) => {
    const match = cssVariableRegex.exec(CSSVar)
    if (!match) return []

    const [, token, fallback] = match
    return [token, fallback]
}

const setCSSVarValue = (
    CSSVar: string,
    value: string,
    element: HTMLElement = document.documentElement
) => {
    element.style.setProperty(parseCSSVar(CSSVar)[0], value)
}

export default setCSSVarValue
