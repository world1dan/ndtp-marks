const getPageThemeColor = (): string | null => {
    const meta: HTMLMetaElement | null = document.querySelector(
        'meta[name=theme-color]'
    )

    if (!meta) throw new Error('No meta tag with name "theme-color" found')

    return meta.getAttribute('content')
}

export default getPageThemeColor
