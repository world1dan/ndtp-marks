import { isThisWeek, subWeeks } from 'date-fns'

import { IWeekInfo } from 'Types/timetable'

const getNextWeek = (weeks: IWeekInfo[]) => {
    return (
        weeks.find((week) =>
            isThisWeek(subWeeks(week.start, 1), {
                weekStartsOn: 1,
            })
        ) ?? weeks[weeks.length - 1]
    )
}

export default getNextWeek
