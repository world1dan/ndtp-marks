import { IClientConfig } from 'Types/clientConfig'

const getClientConfig = (): IClientConfig | null => {
    const json = localStorage.getItem('CLIENT_CONFIG')

    return json ? JSON.parse(json) : null
}

export default getClientConfig
