import changePageThemeColor from './changePageThemeColor'

const setClientColorTheme = (themeId: string) => {
    document.documentElement.setAttribute('theme', themeId)
    changePageThemeColor('var(--bg1)')
}

export default setClientColorTheme
