import { firestore } from '../../Firebase'
import { collection } from 'firebase/firestore'

const getClassroomTimetableCollection = (classroomId: string) => {
    return collection(firestore, 'classrooms', classroomId, 'timetable')
}

export default getClassroomTimetableCollection
