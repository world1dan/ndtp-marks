import { firestore } from '../../Firebase'
import { doc } from 'firebase/firestore'

const getClassroomDoc = (classroomId: string) => {
    return doc(firestore, 'classrooms', classroomId)
}

export default getClassroomDoc
