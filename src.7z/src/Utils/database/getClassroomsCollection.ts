import { firestore } from '../../Firebase'
import { collection, CollectionReference } from 'firebase/firestore'
import { IClassroom } from 'Types/classroom'

const getClassroomsCollection = () => {
    return collection(
        firestore,
        'classrooms'
    ) as CollectionReference<IClassroom>
}

export default getClassroomsCollection
