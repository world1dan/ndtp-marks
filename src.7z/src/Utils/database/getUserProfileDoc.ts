import { doc } from 'firebase/firestore'

import { firestore } from '../../Firebase'

const getUserProfileDoc = (uid: string) => {
    return doc(firestore, 'users', uid)
}

export default getUserProfileDoc
