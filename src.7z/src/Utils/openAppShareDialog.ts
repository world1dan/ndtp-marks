const openAppShareDialog = (classroomId: string, className = '') => {
    if (navigator.share !== undefined) {
        navigator.share({
            title: 'Дневник',
            text: `https://wd-school.web.app/#/install

Скопируй ID Класса и перейди по ссылке

ID Класса (${className}):
${classroomId}

Не твой класс? Напиши сюда:
https://world1dan.t.me`,
        })
    }
}

export default openAppShareDialog
