const cssVariableRegex = /var\((--[a-zA-Z0-9-_]+),? ?([a-zA-Z0-9 ()%#.,-]+)?\)/

const parseCSSVar = (CSSVar: string) => {
    const match = cssVariableRegex.exec(CSSVar)
    if (!match) return []

    const [, token, fallback] = match
    return [token, fallback]
}

const getCSSVarValue = (CSSVar: string) => {
    return getComputedStyle(document.documentElement)
        .getPropertyValue(parseCSSVar(CSSVar)[0])
        .trim()
}

export default getCSSVarValue
