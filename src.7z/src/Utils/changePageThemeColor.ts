import getCSSVarValue from './getCSSVarValue'

const changePageThemeColor = (color: string): string | null => {
    const meta: HTMLMetaElement | null = document.querySelector(
        'meta[name=theme-color]'
    )

    if (!meta) throw new Error('No meta tag with name "theme-color" found')

    const previousThemeColor = meta.getAttribute('content')

    meta.setAttribute(
        'content',
        color.startsWith('var') ? getCSSVarValue(color) : color
    )

    return previousThemeColor
}

export default changePageThemeColor
