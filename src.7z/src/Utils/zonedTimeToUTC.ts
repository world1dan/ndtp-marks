const getOffset = (timeZone = 'UTC', date = new Date()) => {
    const utcDate = new Date(date.toLocaleString('en-US', { timeZone: 'UTC' }))
    const tzDate = new Date(date.toLocaleString('en-US', { timeZone }))
    return tzDate.getTime() - utcDate.getTime()
}

const zonedTimeToUtc = (d: Date, timeZone: string) => {
    const utc = Date.UTC(
        d.getFullYear(),
        d.getMonth(),
        d.getDate(),
        d.getHours(),
        d.getMinutes(),
        d.getSeconds(),
        d.getMilliseconds()
    )

    const offsetMilliseconds = getOffset(timeZone, new Date(utc))

    return new Date(utc - offsetMilliseconds)
}

export default zonedTimeToUtc
