import { isThisWeek } from 'date-fns'

import { IWeekInfo } from 'Types/timetable'

const getCurrentWeek = (weeks: IWeekInfo[]) => {
    return (
        weeks.find((week) =>
            isThisWeek(week.start, {
                weekStartsOn: 1,
            })
        ) ?? weeks[weeks.length - 1]
    )
}

export default getCurrentWeek
