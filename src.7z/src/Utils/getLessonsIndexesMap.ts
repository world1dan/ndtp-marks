import { ITimetableDay } from 'Types/timetable'

const getLessonsIndexesMap = (
    lessons: ITimetableDay['lessons'],
    classGroupId?: string
) => {
    return Object.keys(lessons).filter((lessonNum) => {
        const lesson = lessons[lessonNum]

        return !(
            classGroupId &&
            lesson.targetGroups &&
            !lesson.targetGroups.includes(classGroupId)
        )
    })
}

export default getLessonsIndexesMap
