import { createContext } from 'react'

import { ITimePeriod } from 'Types/bellSchedule'

export interface ICurrentPeriodContext {
    currentPeriodNum: number | undefined
    currentPeriod: ITimePeriod | undefined
}

const CurrentPeriodContext = createContext({} as ICurrentPeriodContext)

export default CurrentPeriodContext
