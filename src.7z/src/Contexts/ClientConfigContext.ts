import { createContext } from 'react'

import { IClientConfig } from 'Types/clientConfig'

export interface IClientConfigContext {
    clientConfig: IClientConfig
    modifyClientConfig: (m: Partial<IClientConfig>) => void
}

const ClientConfigContext = createContext<IClientConfigContext>(
    {} as IClientConfigContext
)

export default ClientConfigContext
