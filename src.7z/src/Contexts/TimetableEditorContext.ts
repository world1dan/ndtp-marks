import { createContext } from 'react'

import { IClassroom } from 'Types/classroom'

export interface ITimetableEditorContext {
    classroom: IClassroom
}

export const TimetableEditorContext = createContext<ITimetableEditorContext>(
    {} as ITimetableEditorContext
)
