import { DocumentReference } from 'firebase/firestore'
import { createContext } from 'react'

import { ISubjectsManifest } from 'Types/subjects'

export interface ISubjectsManifestContext {
    subjectsManifest: ISubjectsManifest | undefined
    subjectsManifestDoc: DocumentReference
}

const SubjectsManifestContext = createContext<ISubjectsManifestContext>(
    {} as ISubjectsManifestContext
)

export default SubjectsManifestContext
