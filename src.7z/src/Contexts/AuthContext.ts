import { createContext } from 'react'

import { AuthError, User } from 'firebase/auth'
import { DocumentReference } from 'firebase/firestore'

import { IUserProfile } from 'Types/userProfile'

export interface IAuthContext {
    user: User
    userProfile: IUserProfile | undefined
    userProfileDoc: DocumentReference | undefined
    isLoading: boolean
    error: AuthError
}

export const AuthContext = createContext<IAuthContext>({} as IAuthContext)
