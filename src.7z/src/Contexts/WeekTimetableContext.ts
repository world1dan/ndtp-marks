import { DocumentReference } from 'firebase/firestore'
import { createContext } from 'react'

export interface IWeekTimetableContext {
    weekDoc: DocumentReference
    classGroupId: string | undefined
}

export const WeekTimetableContext = createContext<IWeekTimetableContext>(
    {} as IWeekTimetableContext
)
