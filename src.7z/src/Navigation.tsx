import { memo } from 'react'

import {
    Icon28CalendarOutline,
    Icon28EducationOutline,
    Icon28HomeOutline,
    Icon28SearchOutline,
} from '@vkontakte/icons'

import TabBar from 'Components/TabBar'
import TabBarLink from 'Components/TabBar/TabBarLink'

import useMediaQuery from 'Hooks/useMediaQuery'

const Navigation = () => {
    const useLargeIcons = useMediaQuery('(min-width: 660px)')

    const iconsSize = useLargeIcons ? 34 : 30

    return (
        <TabBar>
            <TabBarLink
                title="Четвертные"
                to="/"
                end
                icon={
                    <Icon28HomeOutline width={iconsSize} height={iconsSize} />
                }
            />
            <TabBarLink
                title="Итоги"
                to="/final_grades"
                icon={
                    <Icon28SearchOutline width={iconsSize} height={iconsSize} />
                }
            />
            <TabBarLink
                title="Рейтинг"
                to="/rating"
                icon={
                    <Icon28EducationOutline
                        width={iconsSize}
                        height={iconsSize}
                    />
                }
            />
            <TabBarLink
                title="Настройки"
                to="/settings"
                icon={
                    <Icon28CalendarOutline
                        width={iconsSize}
                        height={iconsSize}
                    />
                }
            />
        </TabBar>
    )
}

export default memo(Navigation)
