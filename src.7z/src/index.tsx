import { createRoot } from 'react-dom/client'

import * as OfflinePluginRuntime from '@lcdp/offline-plugin/runtime'
import LogRocket from 'logrocket'

import getClientConfig from 'Utils/getClientConfig'
import setClientColorTheme from 'Utils/setClientColorTheme'

import 'Styles/color-tokens.scss'
import 'Styles/global.scss'
import 'Styles/reset.scss'

import App from './App'

const colorThemeId = getClientConfig()?.colorThemeId

if (colorThemeId) {
    setClientColorTheme(colorThemeId)
}

const rootElement = document.getElementById('root')

if (rootElement) {
    createRoot(rootElement).render(<App />)
}

if (process.env.NODE_ENV === 'production') {
    OfflinePluginRuntime.install()
    LogRocket.init('jq5uww/wd-school')
}
