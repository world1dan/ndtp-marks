import { useEffect } from 'react'

const useEventListener = <
    KW extends keyof WindowEventMap,
    KH extends keyof HTMLElementEventMap
>(
    eventName: KW | KH,
    eventHandler: (
        event: WindowEventMap[KW] | HTMLElementEventMap[KH] | Event
    ) => void,
    element: HTMLElement | Document | Window | undefined = document,
    options?: AddEventListenerOptions
) => {
    useEffect(() => {
        element.addEventListener(eventName, eventHandler, options)

        return () => {
            element.removeEventListener(eventName, eventHandler, options)
        }
    }, [eventName, element, eventHandler, options])
}

export default useEventListener
