import { ChangeEventHandler, useState } from 'react'

const useInput = (initialValue = '') => {
    const [value, setValue] = useState(initialValue)

    const handleChange: ChangeEventHandler<HTMLInputElement> = (event) => {
        setValue(event.target.value)
    }

    return {
        value,
        onChange: handleChange,
    }
}

export default useInput
