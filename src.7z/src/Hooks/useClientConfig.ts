import { useContext } from 'react'

import ClientConfigContext from 'Contexts/ClientConfigContext'

import { IClientConfig } from 'Types/clientConfig'

const useClientConfig = (): [
    config: IClientConfig,
    modifyConfig: (changes: Partial<IClientConfig>) => void
] => {
    const { clientConfig, modifyClientConfig } = useContext(ClientConfigContext)

    return [clientConfig, modifyClientConfig]
}

export default useClientConfig
