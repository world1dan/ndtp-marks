import { useEffect } from 'react'

const useInterval = (
    callback: () => void,
    interval: number | null | undefined,
    initialRun = true
) => {
    useEffect(() => {
        if (!interval) return
        initialRun && callback()
        const intervalId = setInterval(callback, interval)

        return () => clearInterval(intervalId)
    }, [initialRun, interval])
}

export default useInterval
