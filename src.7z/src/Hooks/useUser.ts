import { useContext } from 'react'

import { AuthContext, IAuthContext } from 'Contexts/AuthContext'

const useUser = (): IAuthContext => {
    return useContext(AuthContext)
}

export default useUser
