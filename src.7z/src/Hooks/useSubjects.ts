import { useContext } from 'react'

import SubjectsManifestContext from 'Contexts/SubjectsManifestContext'

const useSubjects = () => {
    return useContext(SubjectsManifestContext)?.subjectsManifest
}

export default useSubjects
