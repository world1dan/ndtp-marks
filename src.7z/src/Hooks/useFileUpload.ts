import { useState } from 'react'

import { FirebaseError } from 'firebase/app'
import {
    StorageReference,
    TaskState,
    UploadMetadata,
    UploadTask,
    getDownloadURL,
    uploadBytesResumable,
} from 'firebase/storage'

const useFileUpload = (options?: { metadata?: UploadMetadata }) => {
    const [uploadTask, setUploadTask] = useState<UploadTask>()
    const [uploadProgress, setUploadProgress] = useState<number>()
    const [uploadState, setUploadState] = useState<TaskState>()
    const [uploadError, setUploadError] = useState<{
        code: FirebaseError['code']
        message: string
    }>()

    const [downloadURL, setDownloadURL] = useState<string>()

    const uploadFile = async (
        ref: StorageReference,
        file: File,
        metadata?: UploadMetadata
    ): Promise<string> => {
        const task = uploadBytesResumable(ref, file, {
            ...options?.metadata,
            ...metadata,
        })

        setUploadTask(task)

        return new Promise((resolve, reject) => {
            task.on(
                'state_changed',
                (snapshot) => {
                    const progress = Math.round(
                        (snapshot.bytesTransferred / snapshot.totalBytes) * 100
                    )

                    switch (snapshot.state) {
                        case 'paused':
                            break
                        case 'running':
                            break
                    }

                    setUploadState(snapshot.state)
                    setUploadProgress(progress)
                },
                (error) => {
                    setUploadTask(undefined)
                    setDownloadURL(undefined)
                    setUploadProgress(undefined)

                    switch (error.code) {
                        case 'storage/unauthorized':
                            setUploadError({
                                code: error.code,
                                message: 'Ошибка: Недостаточно прав',
                            })
                            break
                        case 'storage/canceled':
                            setUploadError({
                                code: error.code,
                                message: 'Загрузка отменена',
                            })
                            break
                        case 'storage/unknown':
                            setUploadError({
                                code: error.code,
                                message: 'Произошла неизвестная ошибка',
                            })
                    }
                    console.log(error)
                    reject(error)
                },
                async () => {
                    const downloadURL = await getDownloadURL(task.snapshot.ref)

                    if (downloadURL) {
                        setUploadTask(undefined)
                        setUploadState(undefined)
                        setDownloadURL(downloadURL)
                        resolve(downloadURL)
                    }
                }
            )
        })
    }

    return {
        uploadFile,
        state: uploadState,
        progress: uploadProgress,
        error: uploadError,
        uploadTask,
        downloadURL,
    }
}

export default useFileUpload
