import { useEffect, useRef } from 'react'
import changePageThemeColor from 'Utils/changePageThemeColor'

const usePageThemeColor = (color: string) => {
    const initialThemeColor = useRef<string | null>()

    useEffect(() => {
        initialThemeColor.current = changePageThemeColor(color)

        return () => {
            if (initialThemeColor.current) {
                changePageThemeColor(initialThemeColor.current)
            }
        }
    }, [color])
}

export default usePageThemeColor
