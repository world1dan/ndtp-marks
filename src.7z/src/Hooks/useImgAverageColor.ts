import { RefObject, useEffect, useState } from 'react'

import getAverageColorOfImg from 'Utils/getAverageColorOfImg'

const useImgAverageColor = (
    imgElement: RefObject<HTMLImageElement>,
    defaultColor?: string
) => {
    const [imgAverageColor, setImgAverageColor] = useState<string | undefined>(
        defaultColor
    )

    useEffect(() => {
        if (!imgElement.current) return

        const setAverageColor = async () => {
            try {
                const averageColor = await getAverageColorOfImg(
                    imgElement.current as HTMLImageElement
                )
                setImgAverageColor(averageColor.hex)
            } catch (e) {
                console.log(e)
            }
        }

        setAverageColor()
    }, [imgElement.current?.src, imgElement])

    return imgAverageColor
}

export default useImgAverageColor
