import { Dispatch, SetStateAction, useEffect, useState } from 'react'

const getFromLocalStorage = <T>(key: string, defaultValue?: T): T => {
    const json = localStorage.getItem(key)

    return json && json !== 'undefined' ? JSON.parse(json) : defaultValue
}

const useLocalStorage = <T>(
    key: string,
    defaultValue?: T
): [T, Dispatch<SetStateAction<T>>] => {
    const [value, setValue] = useState<T>(() =>
        getFromLocalStorage<T>(key, defaultValue)
    )

    useEffect(() => {
        if (value) {
            localStorage.setItem(key, JSON.stringify(value))
        }
    }, [value, key])

    useEffect(() => {
        setValue(getFromLocalStorage<T>(key, defaultValue))
    }, [key])

    return [value, setValue]
}

export default useLocalStorage
