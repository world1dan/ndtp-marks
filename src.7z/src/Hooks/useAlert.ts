import { useState } from 'react'

const useAlert = () => {
    const [isVisible, setIsVisible] = useState<boolean>(false)

    const showAlert = () => {
        setIsVisible(true)
    }

    return [isVisible, showAlert]
}

export default useAlert
