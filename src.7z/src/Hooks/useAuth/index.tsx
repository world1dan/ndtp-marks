import { useState, useEffect } from 'react'

import {
    onAuthStateChanged,
    createUserWithEmailAndPassword,
    signInWithEmailAndPassword,
    signOut,
    AuthError,
} from 'firebase/auth'

import { auth } from '../../Firebase'

import { authErrorsMap } from './authErrorsMap'

import { IAuthContext } from 'Contexts/AuthContext'

export const getErrorMessage = (error: AuthError) => {
    return authErrorsMap[error.code] || error.message
}

const useAuth = () => {
    const [user, setUser] = useState<IAuthContext['user'] | undefined | null>()
    const [errorMessage, setErrorMessage] = useState('')

    useEffect(() => {
        const unsubscribe = onAuthStateChanged(auth, setUser)

        return () => unsubscribe()
    }, [])

    const registerUserWithEmail = async (email: string, password: string) => {
        return createUserWithEmailAndPassword(auth, email, password).catch(
            (error: AuthError) => {
                setErrorMessage(getErrorMessage(error))
            }
        )
    }

    const signInUserWithEmail = async (email: string, password: string) => {
        return signInWithEmailAndPassword(auth, email, password).catch(
            (error: AuthError) => {
                setErrorMessage(getErrorMessage(error))
            }
        )
    }

    const signOutUser = () => {
        return signOut(auth)
    }

    return {
        errorMessage,
        user,
        registerUserWithEmail,
        signInUserWithEmail,
        signOutUser,
    }
}

export default useAuth
