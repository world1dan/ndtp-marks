import { useMemo } from 'react'

import { useCollection } from 'react-firebase-hooks/firestore'
import { collection } from 'firebase/firestore'

import { firestore } from '../Firebase'
import { IUserProfile } from 'Types/userProfile'

const useUsersProfiles = () => {
    const usersCollection = useMemo(() => {
        return collection(firestore, 'users')
    }, [])

    const [usersCollectionSnapshot, loading, error] =
        useCollection(usersCollection)

    const usersProfiles: IUserProfile[] = []

    usersCollectionSnapshot?.forEach((doc) => {
        usersProfiles.push({
            ...doc.data(),
            uid: doc.id,
        } as IUserProfile)
    })

    return {
        usersProfiles,
        loading,
        error,
    }
}

export default useUsersProfiles
