import Compressor from 'compressorjs'
import { StorageReference, UploadMetadata } from 'firebase/storage'

import compressImage from 'Utils/compressImage'

import useFileUpload from './useFileUpload'

const useImageUpload = (options?: {
    compress: Compressor.Options
    metadata?: UploadMetadata
}) => {
    const { uploadFile, downloadURL, ...uploadInfo } = useFileUpload({
        metadata: options?.metadata,
    })

    const uploadImage = async (
        ref: StorageReference,
        file: File,
        metadata?: UploadMetadata
    ): Promise<string> => {
        const compressedImage = (await compressImage(
            file,
            options?.compress
        )) as File

        return uploadFile(ref, compressedImage, {
            ...options?.metadata,
            ...metadata,
        })
    }

    return {
        uploadImage,
        ...uploadInfo,
        uploadedImageUrl: downloadURL,
    }
}

export default useImageUpload
