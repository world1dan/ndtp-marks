import { useContext } from 'react'

import CurrentPeriodContext from 'Contexts/CurrentPeriodContext'

const useCurrentPeriod = () => {
    return useContext(CurrentPeriodContext)
}

export default useCurrentPeriod
