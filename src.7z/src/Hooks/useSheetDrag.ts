import { PanInfo } from 'framer-motion'
import { RefObject, useEffect, useRef } from 'react'

export interface IUseSheetDragOptions {
    sheetRef: RefObject<HTMLDivElement>
    sheetContentRef: RefObject<HTMLDivElement>
    handleClose: () => void
}

const useSheetDrag = ({
    sheetRef,
    sheetContentRef,
    handleClose,
}: IUseSheetDragOptions) => {
    const touchStartPoint = useRef<number>()

    useEffect(() => {
        const node = sheetContentRef.current

        const onTouchMove = (event: TouchEvent) => {
            if ((node?.scrollTop as number) <= 0) {
                const touchY = event.changedTouches[0].clientY
                const prevTouchY = touchStartPoint.current

                if (prevTouchY && touchY >= prevTouchY && event.cancelable) {
                    event.preventDefault()
                }
            }
        }

        const onTouchStart = (event: TouchEvent) => {
            touchStartPoint.current = event.touches[0].clientY
        }

        node?.addEventListener('touchmove', onTouchMove, {
            passive: false,
        })

        node?.addEventListener('touchstart', onTouchStart, {
            passive: false,
        })

        return () => {
            node?.removeEventListener('touchmove', onTouchMove)
            node?.removeEventListener('touchstart', onTouchStart)
        }
    }, [sheetContentRef])

    const onPanStart = () => {
        sheetRef.current
            ?.getAnimations()
            .forEach((animation) => animation.finish())
    }

    const onPan = (
        _: MouseEvent | TouchEvent | PointerEvent,
        info: PanInfo
    ) => {
        const element = sheetRef.current
        if (!element) return

        if (
            element &&
            sheetContentRef.current &&
            sheetContentRef.current?.scrollTop <= 0 &&
            info.offset.y >= 0
        ) {
            element.animate(
                [
                    {
                        transform: 'translateY(' + info.offset.y + 'px)',
                    },
                ],
                {
                    duration: 20,
                    fill: 'both',
                }
            )
        }
    }

    const onPanEnd = (
        _: MouseEvent | TouchEvent | PointerEvent,
        info: PanInfo
    ) => {
        if (info.velocity.y >= 500) {
            handleClose()
        } else {
            if (sheetRef.current) {
                sheetRef.current
                    .getAnimations()
                    .forEach((animation) => animation.finish())
                sheetRef.current.animate(
                    [
                        {
                            transform: 'translateY(0)',
                        },
                    ],
                    {
                        duration: 500,
                        easing: 'cubic-bezier(0.38, 0.7, 0.125, 1)',
                        fill: 'both',
                    }
                )
            }
        }
    }

    return { onPan, onPanStart, onPanEnd }
}

export default useSheetDrag
