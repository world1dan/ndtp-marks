import { useEffect } from 'react'

const useKeyPress = (key: string, action: () => void) => {
    useEffect(() => {
        const onKeyDown = (event: KeyboardEvent) => {
            if (event.key === key) action()
        }
        window.addEventListener('keydown', onKeyDown)
        return () => window.removeEventListener('keydown', onKeyDown)
    }, [key, action])
}

export default useKeyPress
