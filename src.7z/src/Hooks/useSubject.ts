import { useContext } from 'react'

import SubjectsManifestContext from 'Contexts/SubjectsManifestContext'

const useSubject = (subjectID: string) => {
    return useContext(SubjectsManifestContext).subjectsManifest?.[subjectID]
}

export default useSubject
