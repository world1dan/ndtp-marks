import { useMemo } from 'react'

import { doc } from 'firebase/firestore'
import { useDocumentData } from 'react-firebase-hooks/firestore'

import { IUserProfile } from 'Types/userProfile'

import { firestore } from '../Firebase'

const useUserProfile = (uid: string | undefined) => {
    const userProfileDoc = useMemo(() => {
        return uid ? doc(firestore, 'users', uid) : undefined
    }, [uid])

    const [userProfile, loading, error] = useDocumentData(userProfileDoc)

    return {
        userProfile: { ...userProfile, uid } as IUserProfile | undefined,
        userProfileDoc,
        loading,
        error,
    }
}

export default useUserProfile
