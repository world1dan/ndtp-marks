import { useMemo } from 'react'
import { useCollectionData } from 'react-firebase-hooks/firestore'

import { IClassroom } from 'Types/classroom'

import getClassroomsCollection from 'Utils/database/getClassroomsCollection'

const useClassrooms = () => {
    const classroomDoc = useMemo(() => getClassroomsCollection(), [])

    const [classrooms] = useCollectionData<IClassroom>(classroomDoc)

    return classrooms
}

export default useClassrooms
