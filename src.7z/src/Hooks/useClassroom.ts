import { useMemo } from 'react'
import { useDocumentData } from 'react-firebase-hooks/firestore'

import { IClassroom } from 'Types/classroom'
import getClassroomDoc from 'Utils/database/getClassroomDoc'

const useClassroom = (
    classroomId: string | undefined | null
): IClassroom | undefined => {
    const classroomDoc = useMemo(
        () => (classroomId ? getClassroomDoc(classroomId) : null),
        [classroomId]
    )

    const [classroom] = useDocumentData(classroomDoc)

    return classroom as IClassroom | undefined
}

export default useClassroom
