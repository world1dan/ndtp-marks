export interface ILesson {
    id: string
    hw?: string
    link?: string
    changedBy?: string
    lastСhange?: string
    mediaAttachments?: IMediaAttachment[]
    audioAttachments?: IAudioAttachment[]
    danger?: boolean
    targetGroups?: string[]
    location?: string
}

export interface ILessonAttachment {
    attachedBy: string
    attachedAt: string
}

export interface IMediaAttachment extends ILessonAttachment {
    type: 'image' | 'video'
    url: string
    width?: number
    height?: number
    thumbnailDataURL?: string
}

export interface ILinkAttachment extends ILessonAttachment {
    URL: string
}

export interface IAudioAttachment extends ILessonAttachment {
    URL: string
}

export interface ILessonPath {
    date: Date
    lessonNum: number
}
