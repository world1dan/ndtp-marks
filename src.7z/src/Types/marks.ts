export interface IMark {
    id?: string
    value: number
    addedAt: string
    label?: string
    isImportant?: boolean
    importance?: 'default' | 'medium' | 'high'
}

export interface IQuarterMarks {
    [key: string]: IQuarterSubjectMarks
}

export interface IQuarterSubjectMarks {
    averageMarkTarget?: number | null
    marksList?: IMark[]
}

export interface IFinalGrades {
    [subjectId: number]: IFinalSubjectGrades
}

export interface IFinalSubjectGrades {
    [quarterId: string]: IMark
}

export interface IUserRating {
    quarterMarks: IQuarterSubjectMarks
    uid: string
    averageOfQuarter: number | undefined
    targetOfQuarter: number
}
