export interface ISubject {
    id: string
    title: string
    fullTitle?: string
    color: CSSStyleDeclaration['background']
    isHasMarks?: boolean
    books?: ISchoolbook[]
    solutionsURL?: string
    altSolutionsURL?: string
    solutionsUnit?: string
    solutions: {
        chapters: ISchoolBookChapter[]
    }
    workbooks: IWorkbook[]
}

export interface ISubjectsManifest {
    [key: string]: ISubject
}

export interface ISchoolbook {
    id: string
    URL?: string
    coverURL?: string
}

export interface ISchoolBookChapter {
    id: string
    name: string
}

export interface IWorkbook {
    id: string
    solutionsURL: string
    coverURL: string
}
