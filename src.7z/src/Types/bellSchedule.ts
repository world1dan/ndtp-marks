export interface IBellSchedule {
    periodName: string
    schedule: {
        [shiftNum: string]: {
            [periodNum: string]: ITimePeriod
        }
    }
}

export interface ITimePeriod {
    start: `${number}:${number}`
    end: `${number}:${number}`
}
