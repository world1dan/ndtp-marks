import { CSSProperties } from 'react'

export interface IClassGroup {
    id: string
    color: CSSProperties['background']
    title: string
}
