export type IUserBadge = 'cheater'

export interface IUserProfile {
    uid: string
    firstName: string
    lastName: string
    avatarURL?: string
    bannerURL?: string
    instagramUsername?: string
    telegramUsername?: string
    classGroupId?: string
    classroomId?: string
    badges?: IUserBadge[]
    isPrivate?: boolean
}
