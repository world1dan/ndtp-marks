import { IClassGroup } from './classGroup'

export interface IClassroom {
    id: string
    classGroups: IClassGroup[]
    className: string
}
