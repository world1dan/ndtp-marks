export interface IClientConfig {
    colorThemeId: string | undefined | null
    reduceEffect: boolean
}
