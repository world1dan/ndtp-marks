import { ILesson } from './lesson'
import { ISchoolQuarter } from './schoolQuarter'

export interface IWeekInfo {
    isHolidays: boolean
    quarter: ISchoolQuarter | undefined
    start: Date
    end: Date
}

export interface ITimetableWeek {
    weekInterval: {
        start: Date
        end: Date
    }
    days: {
        [dayId: string]: ITimetableDay
    }
}

export interface ITimetableDay {
    isHoliday?: boolean
    isDayOff?: boolean
    notice?: INotice

    lessons: {
        [lessonNum: number]: ILesson
    }
}

export interface INotice {
    text: string
    importance: 'default' | 'medium' | 'high'
}
