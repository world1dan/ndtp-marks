export interface ISchoolQuarter {
    num: number
    start: Date
    end: Date
}
