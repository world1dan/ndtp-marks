export interface IPublicNote {
    createdBy: string
    createdAt: number
    text: string
}