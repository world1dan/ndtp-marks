export interface INote {
    text: string
    isPinned: boolean
    createdAt: string
}

export interface INotesList {
    [id: string]: INote
}

export interface ITask {
    text: string
    isCompleted: boolean
    createdAt: string
}

export interface ITasksList {
    [id: string]: ITask
}
