import { useEffect, useState } from 'react'

import { css } from '@linaria/core'

import ScrollView from 'Components/ScrollView'
import Stack from 'Components/Stack'
import Text from 'Components/Text'

import DefaultInstallationGuide from './DefaultInstallationGuide'
import IOSInstallationGuide from './IOSInstallationGuide'

const styles = css`
    align-items: center;
    padding: 20px;

    .app-icon {
        width: 80px;
        display: block;
        border-radius: 14px;
        margin-top: 130px;
    }

    .icon-wraper {
        height: 210px;
    }
    .app-title {
        font-weight: 600;
        font-size: 23px;
    }

    .details {
        font-size: 14px;
        color: var(--text-secondary-color);
        text-align: center;
    }
`

const scrollViewStyles = css`
    width: 100vw;
    height: 100vh;

    @supports (width: 100svh) {
        width: 100svw;
        height: 100svh;
    }
`

let deferredPrompt: Event

const PWAInstallationGuide = () => {
    useEffect(() => {
        const handleInstallPrompt = (e: Event) => {
            e.preventDefault()
            //@ts-ignore
            deferredPrompt = e
        }

        window.addEventListener('beforeinstallprompt', handleInstallPrompt)

        return () =>
            window.removeEventListener(
                'beforeinstallprompt',
                handleInstallPrompt
            )
    }, [])

    let browserName

    if (navigator.userAgent.match(/chrome|chromium|crios/i)) {
        browserName = 'chrome'
    } else if (navigator.userAgent.match(/safari/i)) {
        browserName = 'safari'
    }

    return (
        <ScrollView className={scrollViewStyles}>
            <Stack className={styles} gap={18}>
                <div className="icon-wraper">
                    <img src="icons/apple-icon-180.png" className="app-icon" />
                </div>
                <h2 className="app-title">Дневник</h2>
                {browserName == 'safari' && (
                    <IOSInstallationGuide browserName={browserName} />
                )}
                {browserName == 'chrome' && (
                    <DefaultInstallationGuide
                        //@ts-ignore
                        install={() => deferredPrompt?.prompt()}
                    />
                )}
                {!browserName && (
                    <Text>
                        Браузер не поддерживается, используй Chrome или Safari
                    </Text>
                )}
                <div className="details">
                    Вопросы?{' '}
                    <a
                        href="https://t.me/world1dan"
                        target="_blank"
                        rel="noreferrer"
                    >
                        @world1dan
                    </a>
                </div>
            </Stack>
        </ScrollView>
    )
}

export default PWAInstallationGuide
