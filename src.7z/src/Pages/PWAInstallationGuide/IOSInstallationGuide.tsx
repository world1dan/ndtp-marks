import { useState } from 'react'

import { css } from '@linaria/core'

import {
    Icon28AddSquareOutline,
    Icon28ArrowDownOutline,
    Icon28ShareExternal,
} from '@vkontakte/icons'

import Stack from 'Components/Stack'

import WebViewEscape from './WebViewEscape'

const styles = css`
    text-align: center;
    align-items: center;
    padding: 12px;
    margin-top: 14px;

    .list {
        align-items: center;
    }

    .list-item {
        background-color: var(--bg3);
        padding: 11px 13px;
        width: fit-content;
        margin: 0 auto;
        border-radius: 9px;
        font-weight: 600;
        display: flex;
        gap: 8px;
        justify-content: center;
        align-items: center;
    }
`

function isWebView() {
    const htmlEl = document.getElementsByTagName('html')[0]
    const bodyEl = document.getElementsByTagName('body')[0]

    const oldHtmlHeight = htmlEl.style.height
    const oldBodyHeight = bodyEl.style.height

    htmlEl.style.height = '100vh'
    bodyEl.style.height = '100%'

    const webViewMode =
        document.documentElement.clientHeight ===
        document.documentElement.scrollHeight

    // restore height
    htmlEl.style.height = oldHtmlHeight
    bodyEl.style.height = oldBodyHeight

    return webViewMode
}

export interface Props {
    browserName: string
}

const IOSInstallationGuide = ({ browserName }: Props) => {
    const [isSafariWebView] = useState(
        browserName == 'safari' ? isWebView : false
    )

    if (isSafariWebView) {
        return <WebViewEscape />
    }

    return (
        <Stack className={styles} gap={40}>
            <Stack gap={16} className="list">
                <div className="list-item">
                    Нажми
                    <Icon28ShareExternal width={20} height={20} />
                    <b>Поделиться</b>
                </div>
                <Icon28ArrowDownOutline />
                <div className="list-item">
                    Добавить на гланый экран
                    <Icon28AddSquareOutline width={24} height={24} />
                </div>
                <div className="details">
                    Если такой кнопки нет, открой ссылку ссылку именно в Safari,
                    а не в телеграмме / вайбере и т.п
                </div>
            </Stack>
        </Stack>
    )
}

export default IOSInstallationGuide
