import { css } from '@linaria/core'

import { Icon28SafariOutline, Icon48ArrowDownOutline } from '@vkontakte/icons'

const styles = css`
    .pointer {
        position: fixed;
        bottom: 10px;
        right: 10px;
    }
    .message {
        position: fixed;
        background-color: var(--primary-color);
        bottom: 64px;
        right: 15px;
        padding: 8px 12px;
        font-size: 18px;
        display: flex;
        align-items: center;
        border-radius: 9px;

        .icon {
            display: inline-block;
            margin: 3px;
        }
    }
`

const WebViewEscape = () => {
    return (
        <div className={styles}>
            <div className="message">
                Нажми
                <Icon28SafariOutline className="icon" width={26} height={26} />,
                чтобы установить
            </div>
            <Icon48ArrowDownOutline className="pointer" />
        </div>
    )
}

export default WebViewEscape
