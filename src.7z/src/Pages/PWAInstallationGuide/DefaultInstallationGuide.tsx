import { css } from '@linaria/core'

import { Icon28ArrowDownToSquareOutline } from '@vkontakte/icons'

import Button from 'Components/Button'
import LoadingSpinner from 'Components/LoadingSpinner'
import Stack from 'Components/Stack'

const styles = css`
    .install-button {
        margin-top: 100px;
        width: 280px;
    }
`

export interface Props {
    install: () => void | undefined
}

const DefaultInstallationGuide = ({ install }: Props) => {
    const canInstall = !!install

    return (
        <Stack className={styles} gap={18}>
            <Button
                className="install-button"
                onClick={install}
                size="large"
                appearance="primary"
                disabled={!canInstall}
                iconLeft={<Icon28ArrowDownToSquareOutline />}
                iconRight={!canInstall && <LoadingSpinner />}
            >
                Установить
            </Button>
            <div className="details">
                После установки приложение появиться
                <br />
                на главном экране
            </div>
            <div className="details">
                Если кнопка неактивна, открой
                <br />
                эту ссылку в Chrome
            </div>
        </Stack>
    )
}

export default DefaultInstallationGuide
