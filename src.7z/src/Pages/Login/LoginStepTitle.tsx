import { ReactNode } from 'react'

import { css } from '@linaria/core'

const styles = css`
    font-size: 30px;
    margin: 20px;
    text-align: center;
    font-weight: 600;
`

export interface Props {
    children: ReactNode
}

const LoginStepTitle = ({ children }: Props) => {
    return <h1 className={styles}>{children}</h1>
}

export default LoginStepTitle
