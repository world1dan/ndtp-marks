import { useState } from 'react'

import { Icon24ChevronLeft } from '@vkontakte/icons'
import { AuthError, sendPasswordResetEmail } from 'firebase/auth'
import { Link } from 'react-router-dom'

import Button from 'Components/Button'
import Stack from 'Components/Stack'
import TextInput from 'Components/TextInput'
import Text from 'Components/Text'

import AuthForm from 'Pages/Login/AuthForm'

import { auth } from '../../../../Firebase'

import useInput from 'Hooks/useInput'
import { getErrorMessage } from 'Hooks/useAuth'

const ForgotPassword = () => {
    const [isSended, setIsSended] = useState(false)
    const [errorMessage, setErrorMessage] = useState<string>()

    const email = useInput()

    const sendPasswordResetLink = async () => {
        try {
            await sendPasswordResetEmail(auth, email.value)
            setIsSended(true)
            setErrorMessage(undefined)
        } catch (error) {
            setErrorMessage(getErrorMessage(error as AuthError))
        }
    }

    return (
        <Stack gap={18}>
            <Text type="h1">Восстановление пароля</Text>
            {isSended && (
                <>
                    <Text type="h5">
                        Ссылка для восстановления пароля отправлена на указанный
                        email.
                    </Text>
                    <Text type="h5">
                        Проверь папку <b>Спам</b>, если не можешь найти письмо
                    </Text>
                </>
            )}
            <AuthForm errorMessage={errorMessage}>
                <TextInput
                    {...email}
                    label="Email"
                    type="email"
                    placeholder="Email"
                    autoComplete="current-email"
                />
                <Button
                    onClick={sendPasswordResetLink}
                    appearance="primary"
                    size="large"
                    disabled={!email.value || isSended}
                >
                    Отправить ссылку
                </Button>
                <Link to="/login">
                    <Button size="large" iconLeft={<Icon24ChevronLeft />}>
                        Вернуться
                    </Button>
                </Link>
            </AuthForm>
        </Stack>
    )
}

export default ForgotPassword
