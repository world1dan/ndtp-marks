import { useState } from 'react'

import { css } from '@linaria/core'

import { Link, useNavigate } from 'react-router-dom'

import { Icon20DoorEnterArrowRightOutline } from '@vkontakte/icons'
import { getDoc } from 'firebase/firestore'

import Button from 'Components/Button'
import LoadingSpinner from 'Components/LoadingSpinner'
import Stack from 'Components/Stack'
import Text from 'Components/Text'
import TextInput from 'Components/TextInput'
import PasswordInput from 'Components/TextInput/PasswordInput'

import AuthForm from 'Pages/Login/AuthForm'

import useAuth from 'Hooks/useAuth'

import getUserProfileDoc from 'Utils/database/getUserProfileDoc'

import { IUserProfile } from 'Types/userProfile'

import useLoginForm from '../../AuthForm/useLoginForm'

const styles = css`
    display: flex;
    flex-direction: column;
    gap: 12px;

    .links {
        display: flex;
        justify-content: space-between;
        margin-top: 20px;

        .link {
            border-radius: 5px;
            font-size: 15px;
            font-weight: 600;
        }
    }
`

const SignIn = () => {
    const navigate = useNavigate()
    const { signInUserWithEmail, errorMessage } = useAuth()
    const [isPending, setIsPending] = useState(false)

    const handleSignIn = async (email: string, password: string) => {
        setIsPending(true)
        const user = await signInUserWithEmail(email, password)

        if (user) {
            const userProfileDoc = getUserProfileDoc(user.user.uid)
            const userProfile = (
                await getDoc(userProfileDoc)
            ).data() as IUserProfile

            setIsPending(false)

            if (userProfile?.classroomId) {
                navigate('/', { replace: true })
            } else {
                navigate('complete-profile')
            }
        } else {
            setIsPending(false)
        }
    }

    const {
        emailValue,
        passwordValue,
        handleEmailChange,
        handlePasswordChange,
        onSubmit,
    } = useLoginForm(handleSignIn)

    return (
        <Stack gap={18}>
            <Text type="h1">Вход</Text>

            <AuthForm
                onSubmit={onSubmit}
                className={styles}
                errorMessage={errorMessage}
            >
                <TextInput
                    label="Email"
                    type="email"
                    value={emailValue}
                    onChange={handleEmailChange}
                    autoComplete="current-email"
                />
                <PasswordInput
                    label="Пароль"
                    value={passwordValue}
                    onChange={handlePasswordChange}
                    autoComplete="current-password"
                />
                <Button
                    appearance="primary"
                    size="large"
                    disabled={!passwordValue || !emailValue}
                    iconRight={
                        !isPending ? (
                            <Icon20DoorEnterArrowRightOutline />
                        ) : (
                            <LoadingSpinner />
                        )
                    }
                >
                    Войти
                </Button>

                <div className="links">
                    <Link to="signup" className="link">
                        Зарегистрироваться
                    </Link>
                    <Link to="forgot-password" className="link">
                        Забыли пароль?
                    </Link>
                </div>
            </AuthForm>
        </Stack>
    )
}

export default SignIn
