import { useState } from 'react'
import { css } from '@linaria/core'

import { Link, useNavigate } from 'react-router-dom'
import {
    Icon20DoorEnterArrowRightOutline,
    Icon24ChevronLeft,
} from '@vkontakte/icons'

import Button from 'Components/Button'
import ProgressBarWithSteps from 'Components/ProgressBarWithSteps'
import Stack from 'Components/Stack'
import Text from 'Components/Text'
import ErrorAlert from 'Components/ErrorAlert'
import PasswordInput from 'Components/TextInput/PasswordInput'
import LoadingSpinner from 'Components/LoadingSpinner'
import TextInput from 'Components/TextInput'
import AuthForm from 'Pages/Login/AuthForm'

import useAuth from 'Hooks/useAuth'
import useLoginForm from '../../AuthForm/useLoginForm'

const styles = css`
    display: flex;
    flex-direction: column;
    gap: 10px;
`

const SignUp = () => {
    const { registerUserWithEmail, errorMessage: firebaseAuthErrorMessage } =
        useAuth()

    const [errorMessage, setErrorMessage] = useState<string>()
    const [isPending, setIsPending] = useState(false)

    const navigate = useNavigate()

    const handleSignUp = async (
        email: string,
        password: string,
        passwordRepeat: string
    ) => {
        if (password !== passwordRepeat) {
            setErrorMessage('Пароли не совпадают')
            return
        }

        setIsPending(true)

        const user = await registerUserWithEmail(email, password)

        if (user) {
            navigate('/login/complete-profile/')
            return
        }

        setErrorMessage(undefined)
        setIsPending(false)
    }

    const {
        emailValue,
        passwordValue,
        passwordRepeatValue,
        handleEmailChange,
        handlePasswordChange,
        handlePasswordRepeatChange,
        onSubmit,
    } = useLoginForm(handleSignUp)

    return (
        <Stack gap={16}>
            <Text type="h1">Регистрация</Text>
            <ProgressBarWithSteps currentStep={0} stepsCount={3} />

            <AuthForm
                onSubmit={onSubmit}
                className={styles}
                errorMessage={errorMessage}
            >
                {firebaseAuthErrorMessage && (
                    <ErrorAlert errorMessage={firebaseAuthErrorMessage} />
                )}

                <TextInput
                    label="Email"
                    type="email"
                    value={emailValue}
                    onChange={handleEmailChange}
                    autoComplete="off"
                />
                <PasswordInput
                    label="Пароль"
                    value={passwordValue}
                    onChange={handlePasswordChange}
                    autoComplete="off"
                    placeholder="Не менее 6 символов"
                />
                <PasswordInput
                    label="Повтор пароля"
                    value={passwordRepeatValue}
                    onChange={handlePasswordRepeatChange}
                    autoComplete="off"
                />
                <Button
                    appearance="primary"
                    size="large"
                    disabled={!emailValue || !passwordValue}
                    iconRight={
                        !isPending ? (
                            <Icon20DoorEnterArrowRightOutline />
                        ) : (
                            <LoadingSpinner />
                        )
                    }
                >
                    Зарегистрироваться
                </Button>
                <Link to="/login">
                    <Button size="large" iconLeft={<Icon24ChevronLeft />}>
                        Вернуться
                    </Button>
                </Link>
            </AuthForm>
        </Stack>
    )
}

export default SignUp
