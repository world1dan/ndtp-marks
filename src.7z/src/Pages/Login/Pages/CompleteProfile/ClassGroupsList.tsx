import ClassGroupPicker from 'Components/ClassGroupPicker'

import useClassroom from 'Hooks/useClassroom'

export interface Props {
    classroomId: string
    handleClassGroupSelect: (id: string) => void
}

const ClassGroupsList = ({ classroomId, handleClassGroupSelect }: Props) => {
    const { classGroups } = useClassroom(classroomId) ?? {}

    if (!classGroups || classGroups.length == 0)
        return <div>Нет групп или профилей</div>

    return (
        <ClassGroupPicker
            classGroupsList={classGroups}
            handleChange={handleClassGroupSelect}
        />
    )
}

export default ClassGroupsList
