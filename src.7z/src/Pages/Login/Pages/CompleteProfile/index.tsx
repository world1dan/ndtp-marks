import { ChangeEvent, useState } from 'react'

import { useNavigate, useSearchParams } from 'react-router-dom'

import Button from 'Components/Button'
import ProfileCard from 'Components/ProfileCard'
import ProgressBarWithSteps from 'Components/ProgressBarWithSteps'
import Stack from 'Components/Stack'
import Text from 'Components/Text'
import TextInput from 'Components/TextInput'

import NameEditor from 'Pages/Settings/NameEditor'
import useProfileEdit from 'Pages/Settings/useProfileEdit'

import ClassGroupsList from './ClassGroupsList'

const CompleteProfile = () => {
    const [currentStep, setCurrentStep] = useState(1)
    const [selectedClassGroupId, setSelectedClassGroupId] = useState<string>()
    const navigate = useNavigate()

    const {
        userProfile,
        updateProfile,
        changeClassGroup,
        editProfileAvatar,
        editProfileBanner,
    } = useProfileEdit(() => navigate('/login', { replace: true }))

    const [searchParams] = useSearchParams()
    const classroomIdFromUrl = searchParams.get('classroomId')
    const [classroomId, setClassroomId] = useState(classroomIdFromUrl ?? '')

    const save = () => {
        if (!selectedClassGroupId || !classroomId) return

        updateProfile({
            classGroupId: selectedClassGroupId,
            classroomId,
        })

        changeClassGroup(selectedClassGroupId)
        navigate('/', { replace: true })
    }

    const handleClassroomIdInputChange = (
        event: ChangeEvent<HTMLInputElement>
    ) => {
        const value = event.target.value

        if (value.match(/^[a-z0-9]+$/i) || value == '') {
            setClassroomId(value)
        }
    }

    return (
        <Stack gap={16}>
            <Text type="h1">Регистрация</Text>

            <Stack gap={8}>
                <ProgressBarWithSteps
                    currentStep={currentStep}
                    stepsCount={3}
                />

                {currentStep == 1 && (
                    <>
                        <ProfileCard
                            userProfile={userProfile}
                            editProfileAvatar={editProfileAvatar}
                            editProfileBanner={editProfileBanner}
                        />
                        <NameEditor
                            userProfile={userProfile}
                            updateProfile={(updatedProperties) => {
                                updateProfile(updatedProperties)
                                setCurrentStep(2)
                            }}
                        />
                    </>
                )}
                {currentStep == 2 && (
                    <>
                        <Stack gap={20}>
                            <TextInput
                                label="ID Класса"
                                type="text"
                                value={classroomId ?? ''}
                                onChange={handleClassroomIdInputChange}
                                autoComplete="classroomId"
                            />

                            {classroomId && (
                                <>
                                    <Text type="h4">
                                        Выбери свой профиль или группу
                                    </Text>
                                    <ClassGroupsList
                                        classroomId={classroomId}
                                        handleClassGroupSelect={(id: string) =>
                                            setSelectedClassGroupId(id)
                                        }
                                    />
                                </>
                            )}
                            <Button
                                onClick={save}
                                appearance="primary"
                                size="large"
                                disabled={!selectedClassGroupId || !classroomId}
                            >
                                Готово
                            </Button>
                        </Stack>
                    </>
                )}
            </Stack>
        </Stack>
    )
}

export default CompleteProfile
