import { css } from '@linaria/core'

import { Route, Routes } from 'react-router-dom'

import RequireAuth from 'Components/RequireAuth'
import ScrollView from 'Components/ScrollView'

import CompleteProfile from './Pages/CompleteProfile'
import ForgotPassword from './Pages/ForgotPassword'
import SignIn from './Pages/SignIn'
import SignUp from './Pages/SignUp'

const styles = css`
    padding: 18px;
    max-width: 400px;
    margin: 0 auto;

    @media (min-height: 600px) {
        padding-top: 10vh;
    }

    padding-bottom: 10vh;
`
const Login = () => {
    return (
        <ScrollView fullHeight className={styles}>
            <Routes>
                <Route path="/" element={<SignIn />} />
                <Route path="signup" element={<SignUp />} />
                <Route
                    path="complete-profile"
                    element={
                        <RequireAuth>
                            <CompleteProfile />
                        </RequireAuth>
                    }
                />
                <Route path="forgot-password" element={<ForgotPassword />} />
            </Routes>
        </ScrollView>
    )
}

export default Login
