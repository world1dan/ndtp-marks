import { HTMLAttributes, ReactNode } from 'react'
import { css, cx } from '@linaria/core'

import ErrorAlert from 'Components/ErrorAlert'

const styles = css`
    display: flex;
    flex-direction: column;
    gap: 10px;
`

export interface Props extends HTMLAttributes<HTMLFormElement> {
    className?: string
    errorMessage?: string
    children: ReactNode
}

const AuthForm = ({
    children,
    className,
    errorMessage,
    ...restProps
}: Props) => {
    return (
        <form className={cx(styles, className)} {...restProps}>
            {errorMessage && <ErrorAlert errorMessage={errorMessage} />}
            {children}
        </form>
    )
}

export default AuthForm
