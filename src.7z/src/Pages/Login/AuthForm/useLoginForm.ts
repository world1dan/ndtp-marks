import { ChangeEvent, FormEvent, useState } from 'react'

const useLoginForm = (
    handleLogin: (
        emailValue: string,
        passwordValue: string,
        passwordRepeatValue: string
    ) => void
) => {
    const [passwordValue, setPasswordValue] = useState('')
    const [passwordRepeatValue, setPasswordRepeatValue] = useState('')
    const [emailValue, setEmailValue] = useState('')

    const handleEmailChange = (event: ChangeEvent<HTMLInputElement>) => {
        setEmailValue(event.target.value)
    }

    const handlePasswordChange = (event: ChangeEvent<HTMLInputElement>) => {
        setPasswordValue(event.target.value)
    }

    const handlePasswordRepeatChange = (
        event: ChangeEvent<HTMLInputElement>
    ) => {
        setPasswordRepeatValue(event.target.value)
    }

    const onSubmit = (event: FormEvent<HTMLFormElement>) => {
        event.preventDefault()

        handleLogin(emailValue, passwordValue, passwordRepeatValue)
    }

    return {
        emailValue,
        passwordValue,
        passwordRepeatValue,
        handleEmailChange,
        handlePasswordChange,
        handlePasswordRepeatChange,
        onSubmit,
    }
}

export default useLoginForm
