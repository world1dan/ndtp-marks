import {
    Icon24BrushOutline,
    Icon24DoorArrowRightOutline,
    Icon28ClearDataOutline,
} from '@vkontakte/icons'

import { signOut } from 'firebase/auth'
import { clearIndexedDbPersistence, terminate } from 'firebase/firestore'

import Button from 'Components/Button'
import ProfileCard from 'Components/ProfileCard'

import Stack from 'Components/Stack'
import Switch from 'Components/Switch'

import useClientConfig from 'Hooks/useClientConfig'
import useUser from 'Hooks/useUser'

import { auth, firestore } from '../../Firebase'
import About from './About'
import Caption from './Caption'
import ClassSettings from './ClassSettings'
import ColorSchemeMenu from './ColorSchemeMenu'
import NameEditor from './NameEditor'
import useProfileEdit from './useProfileEdit'
import { css } from '@linaria/core'
import ScrollView from 'Components/ScrollView'

const styles = css`
    max-width: 600px;
    padding: 20px;
    margin: 0 auto;
`

const Settings = () => {
    const { userProfile } = useUser()

    const [config, modifyConfig] = useClientConfig()

    const {
        editProfileAvatar,
        editProfileBanner,
        updateProfile,
        changeClassGroup,
        avatarUploadState,
        bannerUploadState,
        setClassId,
    } = useProfileEdit()

    const clearPersistence = async () => {
        await terminate(firestore)
        await clearIndexedDbPersistence(firestore)
        location.reload()
    }

    return (
        <ScrollView>
            <Stack className={styles} gap={10}>
                <ProfileCard
                    userProfile={userProfile}
                    editProfileAvatar={editProfileAvatar}
                    editProfileBanner={editProfileBanner}
                    avatarUploadState={avatarUploadState}
                    bannerUploadState={bannerUploadState}
                />
                <NameEditor
                    userProfile={userProfile}
                    updateProfile={updateProfile}
                />
                <ClassSettings
                    classId={userProfile?.classroomId}
                    setClassId={setClassId}
                    classGroupId={userProfile?.classGroupId}
                    setClassGroup={changeClassGroup}
                />
                <Caption>
                    <Icon24BrushOutline
                        color="var(--text-color)"
                        width={23}
                        height={23}
                    />
                    Тема интерфейса
                </Caption>
                <ColorSchemeMenu />
                <Stack direction="horizontal" spaceBetween padding={6}>
                    <Caption>Отключить некоторые эффекты и анимации</Caption>
                    <Switch
                        checked={config.reduceEffect}
                        onChange={(e) =>
                            modifyConfig({ reduceEffect: e.target.checked })
                        }
                    />
                </Stack>
                <Stack direction="horizontal" spaceBetween padding={6}>
                    <Caption>Скрыть мои оценки</Caption>
                    <Switch
                        checked={userProfile?.isPrivate}
                        onChange={(e) =>
                            updateProfile({ isPrivate: e.target.checked })
                        }
                    />
                </Stack>
                <Stack direction="horizontal">
                    <Button
                        iconLeft={<Icon24DoorArrowRightOutline />}
                        onClick={() => signOut(auth)}
                        size="large"
                        appearance="destructive"
                    >
                        Выйти
                    </Button>
                    <Button
                        onClick={clearPersistence}
                        size="large"
                        iconLeft={
                            <Icon28ClearDataOutline width={23} height={23} />
                        }
                    >
                        Очистить кэш
                    </Button>
                </Stack>
                <About />
            </Stack>
        </ScrollView>
    )
}

export default Settings
