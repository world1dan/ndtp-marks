import { memo } from 'react'
import { css } from '@linaria/core'

import ColorSchemeItem from './ColorSchemeItem'

import useClientConfig from 'Hooks/useClientConfig'
import setClientColorTheme from 'Utils/setClientColorTheme'

type ColorScheme = {
    name: string
    themeId: string
    color: string
}

const colorSchemes: ColorScheme[] = [
    { name: 'Темная', themeId: 'dark-gray', color: '#212122' },
    { name: 'Светлая', themeId: 'light', color: '#e1e3e6' },
]

const styles = css`
    padding: 10px;
    padding-top: 0;
    display: grid;
    grid-template-columns: repeat(2, 54px);
    gap: 8px;
    overflow: auto;
`

const ColorSchemeMenu = () => {
    const [clientConfig, modifyClientConfig] = useClientConfig()

    const changeColorScheme = (themeId: string) => {
        modifyClientConfig({ colorThemeId: themeId })
        setClientColorTheme(themeId)
    }

    const currentThemeId = clientConfig.colorThemeId

    return (
        <div className={styles}>
            {colorSchemes.map(({ themeId, color }) => {
                return (
                    <ColorSchemeItem
                        key={themeId}
                        color={color}
                        themeId={themeId}
                        isActive={currentThemeId === themeId}
                        onClick={() => changeColorScheme(themeId)}
                    />
                )
            })}
        </div>
    )
}

export default memo(ColorSchemeMenu)
