import { css } from '@linaria/core'

import {
    Icon20CopyOutline,
    Icon20UserReplyOutline,
    Icon24Users3Outline,
} from '@vkontakte/icons'

import Button from 'Components/Button'
import ClassGroupPicker from 'Components/ClassGroupPicker'
import LoadingSpinner from 'Components/LoadingSpinner'
import Stack from 'Components/Stack'

import useClassroom from 'Hooks/useClassroom'

import Caption from './Caption'

const styles = css`
    padding: 8px;
    background-color: var(--bg3);
    border-radius: 7px;

    .change-class-btn {
        background-color: var(--bg2);
    }

    .class-info {
        padding: 6px;

        .class-name {
            font-size: 17px;
        }

        .class-id {
            gap: 5px;
            color: var(--text-secondary-color);
            font-family: monospace;
            font-size: 14px;
            display: flex;
            align-items: center;
        }
    }
`

export interface Props {
    classGroupId: string | undefined
    setClassGroup: (classGroupId: string) => void
    classId: string | undefined
    setClassId: (classId: string) => void
}

const ClassSettings = ({
    classGroupId,
    setClassGroup,
    classId,
    setClassId,
}: Props) => {
    const schoolClass = useClassroom(classId)
    const classGroups = schoolClass?.classGroups

    const copyClassId = async () => {
        if (navigator.clipboard && classId) {
            await navigator.clipboard.writeText(classId)
            alert('ID Класса скопирован')
        }
    }

    const changeClass = async () => {
        const newClassId = prompt('Введи ID нового класса:')

        if (newClassId) {
            try {
                await setClassId(newClassId)
            } catch (e) {
                alert(
                    'Не удалось изменить класс. Возможно, класса с таким ID не существует'
                )
            }
        }
    }

    return (
        <>
            <Caption>
                <Icon24Users3Outline
                    color="var(--text-color)"
                    width={23}
                    height={23}
                />
                Твой класс
            </Caption>
            <Stack className={styles} gap={12}>
                {schoolClass ? (
                    <>
                        <Stack
                            direction="horizontal"
                            spaceBetween
                            className="class-info"
                        >
                            <h5 className="class-name">
                                {schoolClass?.className}
                            </h5>
                            <button className="class-id" onClick={copyClassId}>
                                {<Icon20CopyOutline width={16} height={16} />}
                                id:
                                {schoolClass?.id}
                            </button>
                        </Stack>

                        {classGroups && classGroups.length > 0 && (
                            <>
                                <Caption>Группа / Профиль</Caption>
                                <ClassGroupPicker
                                    handleChange={setClassGroup}
                                    classGroupsList={classGroups}
                                    defaultGroup={classGroupId}
                                />
                            </>
                        )}
                    </>
                ) : (
                    <LoadingSpinner height={120} size={32} />
                )}
            </Stack>
            <Button
                className="change-class-btn"
                iconLeft={<Icon20UserReplyOutline />}
                onClick={changeClass}
            >
                Сменить класс
            </Button>
        </>
    )
}

export default ClassSettings
