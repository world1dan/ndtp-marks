import { ReactNode } from 'react'

import { css } from '@linaria/core'

const styles = css`
    font-size: 13px;
    font-weight: 600;
    padding-left: 10px;
    display: flex;
    align-items: center;
    gap: 8px;
`

export interface Props {
    children: ReactNode
}

const Caption = ({ children }: Props) => {
    return <h5 className={styles}>{children}</h5>
}

export default Caption
