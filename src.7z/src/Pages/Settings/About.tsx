import { css } from '@linaria/core'

const styles = css`
    display: flex;
    justify-content: center;
    flex-direction: column;
    align-items: center;
    margin-top: 24px;
    gap: 8px;

    .build-num {
        font-family: monospace;
        color: var(--text-secondary-color);
    }

    .developer {
        font-weight: 600;
        font-size: 14px;
    }
`

const About = () => {
    return (
        <div className={styles}>
            <div className="build-num">
                Build-{process.env.BUILD_NUMBER as string}
            </div>
            <a
                className="developer"
                href="https://t.me/world1dan"
                target="_blank"
                rel="noreferrer"
            >
                by world1dan
            </a>
        </div>
    )
}

export default About
