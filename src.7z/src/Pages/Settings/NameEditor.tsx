import { useEffect, useState } from 'react'

import Button from 'Components/Button'
import Stack from 'Components/Stack'
import TextInput from 'Components/TextInput'

import { IUserProfile } from 'Types/userProfile'

export interface Props {
    userProfile: IUserProfile | undefined
    updateProfile: (updatedProperties: object) => void
}

const NameEditor = ({ userProfile, updateProfile }: Props) => {
    const [isEdited, setIsEdited] = useState(false)
    const [firstName, setFirstName] = useState(userProfile?.firstName ?? '')
    const [lastName, setLastName] = useState(userProfile?.lastName ?? '')
    const [instagramUsername, setInstagramUsername] = useState(
        userProfile?.instagramUsername ?? ''
    )
    const [telegramUsername, setTelegramUsername] = useState(
        userProfile?.telegramUsername ?? ''
    )

    useEffect(() => {
        if (!isEdited) return () => setIsEdited(true)
    }, [isEdited, firstName, lastName, instagramUsername, telegramUsername])

    const handleSave = () => {
        setIsEdited(false)
        updateProfile({
            firstName,
            lastName,
            instagramUsername: instagramUsername.replace('@', ''),
            telegramUsername: telegramUsername.replace('@', ''),
        })
    }

    return (
        <>
            <TextInput
                label="Имя"
                value={firstName}
                onChange={(event) => setFirstName(event.target.value)}
            />
            <TextInput
                label="Фамилия"
                value={lastName}
                onChange={(event) => setLastName(event.target.value)}
            />

            <Stack direction="horizontal">
                <TextInput
                    label="Instagram"
                    value={instagramUsername}
                    placeholder="@"
                    onChange={(event) =>
                        setInstagramUsername(event.target.value)
                    }
                />
                <TextInput
                    label="Telegram"
                    value={telegramUsername}
                    placeholder="@"
                    onChange={(event) =>
                        setTelegramUsername(event.target.value)
                    }
                />
            </Stack>

            <Button
                onClick={handleSave}
                appearance="primary"
                disabled={!isEdited}
                size="large"
            >
                Сохранить
            </Button>
        </>
    )
}

export default NameEditor
