import { getDoc, setDoc } from 'firebase/firestore'
import { ref } from 'firebase/storage'
import { nanoid } from 'nanoid'

import useImageUpload from 'Hooks/useImageUpload'
import useUser from 'Hooks/useUser'

import getClassroomDoc from 'Utils/database/getClassroomDoc'

import { IUserProfile } from 'Types/userProfile'

import { storage } from '../../Firebase'

const useProfileEdit = (handleError?: () => void) => {
    const { userProfile, userProfileDoc, user } = useUser()

    if (!userProfileDoc) {
        handleError && handleError()
        //throw new Error('User profile doc is undefined')
    }

    const { uploadImage, state: avatarUploadState } = useImageUpload({
        compress: {
            width: 640,
            height: 640,
            quality: 0.6,
            resize: 'cover',
        },
        metadata: {
            cacheControl: 'public,max-age=2419200',
        },
    })

    const { uploadImage: uploadBanner, state: bannerUploadState } =
        useImageUpload({
            compress: {
                width: 1440,
                height: 720,
                quality: 0.7,
                resize: 'cover',
            },
            metadata: {
                cacheControl: 'public,max-age=2419200',
            },
        })

    const updateProfile = (updatedProperties: Partial<IUserProfile>) => {
        setDoc(userProfileDoc, updatedProperties, {
            merge: true,
        })
    }

    const editProfileBanner = async (bannerPhoto: File) => {
        if (bannerPhoto) {
            const bannerURL = await uploadBanner(
                ref(storage, `profile-banners/${user.uid}_${nanoid()}`),
                bannerPhoto
            )

            updateProfile({
                bannerURL,
            })
        }
    }

    const editProfileAvatar = async (avatarPhoto: File) => {
        if (avatarPhoto) {
            const avatarURL = await uploadImage(
                ref(storage, `profile-avatars/${user.uid}_${nanoid()}`),
                avatarPhoto
            )

            updateProfile({
                avatarURL,
            })
        }
    }

    const changeClassGroup = (classGroupId: string) => {
        updateProfile({
            classGroupId,
        })
    }

    const setClassId = async (classId: string) => {
        const classDoc = getClassroomDoc(classId)
        const isValidClassId = (await getDoc(classDoc)).exists()

        if (isValidClassId) {
            updateProfile({
                classroomId: classId,
            })
        } else {
            throw new Error('Сlass does not exist')
        }
    }

    return {
        avatarUploadState,
        bannerUploadState,
        updateProfile,
        editProfileAvatar,
        editProfileBanner,
        changeClassGroup,
        userProfile,
        userProfileDoc,
        setClassId,
    }
}

export default useProfileEdit
