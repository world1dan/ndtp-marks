import { memo, useState } from 'react'

import { css } from '@linaria/core'

import { Icon24LockOutline, Icon28BlockOutline } from '@vkontakte/icons'

import SegmentedControl from 'Components/SegmentedControl'
import SegmentedControlOption from 'Components/SegmentedControl/SegmentedControlOption'

import Header from 'Pages/Marks/Header'
import QuarterMarks from 'Pages/Marks/QuarterMarks'
import YearMarks from 'Pages/Marks/YearMarks'

import getCurrentSchoolQuarter from 'Utils/getCurrentSchoolQuarter'

import { IUserProfile } from 'Types/userProfile'

const styles = css`
    position: relative;
    background-color: var(--bg1);
    padding: 8px;
    border-radius: 9px;
`

const alertStyles = css`
    width: 100%;
    display: grid;
    grid-template-columns: 32px 1fr 32px;
    gap: 16px;
    align-items: center;
    color: var(--red);
    background-color: var(--bg4);
    padding: 10px 14px;
    font-size: 15px;
    border-radius: 9px;
    margin: 0 auto;
    margin-bottom: 10px;
    max-width: 500px;
    font-weight: 600;
    text-align: center;

    .details {
        padding-top: 4px;
        font-size: 14px;
        color: var(--text-secondary-color);
    }
`

export interface Props {
    userProfile: IUserProfile
}

const UserMarks = ({ userProfile }: Props) => {
    const [currentTab, setCurrentTab] = useState('quarter')
    const [schoolQuarterId, setSchoolQuarterId] = useState(
        () => getCurrentSchoolQuarter()?.num ?? 2
    )

    if (userProfile.isPrivate) {
        return (
            <div className={alertStyles}>
                <Icon24LockOutline width={32} height={32} />
                <div>
                    Оценки скрыты
                    <div className="details">
                        Пользователь запретил доступ <br />к своим оценкам
                    </div>
                </div>
            </div>
        )
    }
    return (
        <div className={styles}>
            <Header>
                <SegmentedControl
                    value={currentTab}
                    handleChange={setCurrentTab}
                >
                    <SegmentedControlOption id="quarter">
                        Четверть
                    </SegmentedControlOption>
                    <SegmentedControlOption id="finalGrades">
                        Год
                    </SegmentedControlOption>
                </SegmentedControl>
            </Header>

            {userProfile.badges?.includes('cheater') && (
                <div className={alertStyles}>
                    <Icon28BlockOutline width={32} height={32} />
                    <div>
                        {userProfile.firstName} - Аферист
                        <div className="details">
                            Оценки этого пользователя не соответствуют реальным,
                            поэтому он был исключен из рейтинга.
                        </div>
                    </div>
                </div>
            )}

            {currentTab == 'quarter' && (
                <QuarterMarks
                    uid={userProfile.uid}
                    schoolQuarterId={schoolQuarterId}
                    readOnly
                    setSchoolQuarterId={setSchoolQuarterId}
                />
            )}
            {currentTab == 'finalGrades' && (
                <YearMarks uid={userProfile.uid} readOnly />
            )}
        </div>
    )
}

export default memo(UserMarks)
