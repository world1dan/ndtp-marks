import ProfileCard from 'Components/ProfileCard'
import SheetView from 'Components/SheetView'
import VerticalLayout from 'Components/VerticalLayout'

import useUserProfile from 'Hooks/useUserProfile'

import UserMarks from './UserMarks'

export interface Props {
    uid: string
    handleClose: () => void
}

const UserProfile = ({ uid, handleClose }: Props) => {
    const { userProfile } = useUserProfile(uid)

    return (
        <SheetView
            headerTitle="Профиль"
            maxWidth="large"
            height="fullscreen"
            handleClose={handleClose}
        >
            <VerticalLayout>
                {userProfile && <ProfileCard userProfile={userProfile} />}
                {userProfile && <UserMarks userProfile={userProfile} />}
            </VerticalLayout>
        </SheetView>
    )
}

export default UserProfile
