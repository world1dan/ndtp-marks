import { DocumentReference, getDoc } from 'firebase/firestore'

import Button from 'Components/Button'
import Stack from 'Components/Stack'

export interface Props {
    marksDoc: DocumentReference
}

const ImportExportMarks = ({ marksDoc }: Props) => {
    const downloadJSON = (JSONString: string) => {
        const dataStr =
            'data:text/json;charset=utf-8,' + encodeURIComponent(JSONString)
        const dlAnchorElem = document.createElement('a')
        dlAnchorElem.setAttribute('href', dataStr)
        dlAnchorElem.setAttribute('download', 'scene.json')
        dlAnchorElem.click()
    }

    const exportMarks = async () => {
        const marksDocData = (await getDoc(marksDoc)).data()
        downloadJSON(JSON.stringify(marksDocData, null, 4))
    }

    return (
        <Stack direction="horizontal">
            <Button onClick={exportMarks}>Экспорт</Button>
        </Stack>
    )
}

export default ImportExportMarks
