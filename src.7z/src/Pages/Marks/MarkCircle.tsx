import { ReactNode, useState } from 'react'

import { css } from '@linaria/core'

import { Icon24HelpOutline } from '@vkontakte/icons'
import { motion } from 'framer-motion'

import BottomSheet from 'Components/BottomSheet'

import getMarkStyle from './Utils/getMarkStyle'

export const styles = css`
    background-color: var(--bg4);
    border-radius: 50%;
    box-shadow: 0 0 0 1.2px var(--lvl4-borders) inset;
    display: grid;
    font-size: 15px;
    font-weight: bold;
    height: 34px;
    place-items: center;
    width: 34px;

    &.large {
        width: 90px;
        height: 90px;
        font-size: 38px;
    }

    @media (min-width: 500px) {
        font-size: 16px;
        height: 36px;
        width: 36px;
    }
`

export interface Props {
    value: number | undefined | null
    isImportant?: boolean
    handleClick?: () => void
    withAnimation?: boolean
    aboutMarkContent?: ReactNode
    large?: boolean
}

const MarkCircle = ({
    value,
    isImportant = false,
    handleClick,
    withAnimation = false,
    aboutMarkContent,
    large,
}: Props) => {
    const [aboutMarkOpen, setAboutMarkOpen] = useState(false)

    const markStyle = value ? getMarkStyle(value, isImportant) : undefined

    return (
        <>
            {withAnimation ? (
                <motion.button
                    className={`${styles} ${large ? 'large' : ''}`}
                    style={markStyle}
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    exit={{ scale: 0 }}
                    onClick={() => {
                        if (aboutMarkContent) setAboutMarkOpen(true)
                        if (handleClick) handleClick()
                    }}
                >
                    {value ?? (
                        <Icon24HelpOutline fill="var(--text-secondary-color)" />
                    )}
                </motion.button>
            ) : (
                <button
                    className={`${styles} ${large ? 'large' : ''}`}
                    style={markStyle}
                    onClick={() => {
                        if (aboutMarkContent) setAboutMarkOpen(true)
                        if (handleClick) handleClick()
                    }}
                >
                    {value ?? (
                        <Icon24HelpOutline fill="var(--text-secondary-color)" />
                    )}
                </button>
            )}
            {aboutMarkOpen && (
                <BottomSheet
                    handleClose={() => setAboutMarkOpen(false)}
                    bottomCloseBtn={false}
                >
                    {aboutMarkContent}
                </BottomSheet>
            )}
        </>
    )
}

export default MarkCircle
