import { CSSProperties, useState } from 'react'

import { css } from '@linaria/core'

import { Icon16CalendarOutline } from '@vkontakte/icons'

import BottomSheet from 'Components/BottomSheet'
import RadioButton from 'Components/RadioButton'
import RadioGroup from 'Components/RadioGroup'
import SheetView from 'Components/SheetView'
import Stack from 'Components/Stack'
import Switch from 'Components/Switch'

import { IMark } from 'Types/marks'
import { ISubject } from 'Types/subjects'

import MarksNumpad from '../MarksNumpad'
import DatePicker from './DatePicker'

const styles = css`
    display: flex;
    flex-direction: column;
    padding: 14px;
    gap: 8px;

    .row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 6px;
        padding-left: 17px;

        .caption {
            font-size: 15px;
            font-weight: 600;
        }
    }

    .subject {
        padding: 10px 22px;
        border-radius: 7px;
        font-weight: bold;
        font-size: 14px;
    }

    .header {
        display: grid;
        grid-template-columns: 4px 1fr;
        background-color: var(--bg3);
        padding: 8px;
        border-radius: 9px;
        row-gap: 8px;
        font-weight: 600;

        .subject-color {
            grid-row: 1 / 4;
            width: 6px;
            border-radius: 7px;
        }

        .block {
            display: flex;
            align-items: center;
            padding: 6px;
            flex-direction: column;
            gap: 6px;
        }

        .title {
            font-size: 15px;
        }

        .description {
            color: var(--text-secondary-color);
            font-size: 14px;
        }

        .importance-toggle {
            background-color: var(--bg4);
            border-radius: 7px;
            padding: 6px 12px;
            max-width: 300px;
            width: 100%;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;

            --switch-background-color: var(--bg2);

            .importance-toggle-label {
                font-size: 13px;
            }
        }
    }
`

export interface Props {
    title: string
    description: string
    subjectColor?: CSSProperties['backgroundColor'] | undefined
    withImportanceToggle?: boolean
    withDatePicker?: boolean
    mark?: IMark
    handleClose: () => void
    handleClear?: () => void
    handleSubmit: (
        markValue: number,
        isImportantMark: boolean,
        addedAt?: string
    ) => void
    handleDateChange?: (date: Date) => void
    subject: ISubject
}

const MarkEditor = ({
    title,
    description,
    handleSubmit,
    handleClose,
    subjectColor,
    subject,
    withImportanceToggle = false,
    withDatePicker = false,
    handleDateChange,
    handleClear,
    mark,
}: Props) => {
    const [markImportance, setMarkImportance] = useState('default')

    const [isImportantMark, setIsImportantMark] = useState(false)
    const [dateValue, setDateValue] = useState<Date | null>(
        mark?.addedAt ? new Date(mark?.addedAt) : new Date()
    )

    const handleMarkInput = (markValue: number) => {
        //handleSubmit(markValue, isImportantMark, dateValue?.toUTCString())
    }

    return (
        <SheetView
            handleClose={handleClose}
            headerTitle="Новая оценка"
            height="half-screen"
        >
            {(close: () => void) => (
                <div className={styles}>
                    <div className="row">
                        <div className="caption">Предмет</div>
                        <div
                            className="subject"
                            style={{
                                backgroundColor: subjectColor,
                            }}
                        >
                            {subject.fullTitle ?? subject.title}
                        </div>
                    </div>
                    <div className="row">
                        <div className="caption">Дата</div>

                        <DatePicker
                            value={
                                (dateValue ?? new Date())
                                    .toISOString()
                                    .split('T')[0]
                            }
                            onChange={(event) => {
                                setDateValue(event.target.valueAsDate)
                            }}
                        />
                    </div>

                    <div className="row">
                        <div className="caption">За что эта оценка?</div>
                    </div>

                    <RadioGroup
                        value={markImportance}
                        handleChange={setMarkImportance}
                    >
                        <RadioButton id="default" label="Урок" />
                        <RadioButton id="medium" label="Самостоятельная" />
                        <RadioButton id="high" label="К/р" />
                    </RadioGroup>
                </div>
            )}
        </SheetView>
    )
}

export default MarkEditor

/*<header className="header">
                        {subjectColor && (
                            <div
                                className="subject-color"
                                style={{
                                    backgroundColor: subjectColor,
                                    boxShadow: `${subjectColor} 0 0 4px`,
                                }}
                            />
                        )}
                        <div className="block">
                            <div className="title">{title}</div>
                            <div className="description">{description}</div>
                        </div>
                        {withDatePicker && (
                            <div className="date-picker">
                                <Stack
                                    className="date"
                                    direction="horizontal"
                                    gap={5}
                                >
                                    <Icon16CalendarOutline
                                        width={16}
                                        height={16}
                                    />
                                    {(dateValue
                                        ? new Date(dateValue)
                                        : new Date()
                                    ).toLocaleDateString('ru-RU', {
                                        day: '2-digit',
                                        month: '2-digit',
                                        year: '2-digit',
                                    })}
                                </Stack>
                                <DatePicker
                                    value={
                                        (dateValue ?? new Date())
                                            .toISOString()
                                            .split('T')[0]
                                    }
                                    onChange={(event) => {
                                        setDateValue(event.target.valueAsDate)
                                        handleDateChange &&
                                            event.target.valueAsDate &&
                                            handleDateChange(
                                                event.target.valueAsDate
                                            )
                                    }}
                                />
                            </div>
                        )}
                        {withImportanceToggle && (
                            <div className="importance-toggle">
                                <div className="importance-toggle-label">
                                    Отметить как оценку за к/р
                                </div>
                                <Switch
                                    checked={isImportantMark}
                                    onChange={(e) =>
                                        setIsImportantMark(e.target.checked)
                                    }
                                />
                            </div>
                        )}
                    </header>
                    <MarksNumpad
                        handleClear={
                            handleClear
                                ? () => {
                                      close()
                                      handleClear()
                                  }
                                : undefined
                        }
                        handleMarkInput={(value) => {
                            close()
                            handleMarkInput(value)
                        }}
                    />*/
