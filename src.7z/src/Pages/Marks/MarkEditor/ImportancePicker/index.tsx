import { css } from '@linaria/core'

import RadioButton from 'Components/RadioButton'
import RadioGroup from 'Components/RadioGroup'

const styles = css``

const ImportancePicker = () => {
    return (
        <RadioGroup>
            <RadioButton id="default" label="Урок" />
            <RadioButton id="medium" label="Самостоятельная" />
            <RadioButton id="high" label="К/р" />
        </RadioGroup>
    )
}

export default ImportancePicker
