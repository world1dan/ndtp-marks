import { InputHTMLAttributes } from 'react'

import { css } from '@linaria/core'

import { isToday } from 'date-fns'

import CustomDatePicker from 'Components/CustomDatePicker'
import Stack from 'Components/Stack'

export interface Props extends InputHTMLAttributes<HTMLInputElement> {
    value: string | number
}

const styles = css`
    position: relative;
    font-weight: 600;
    display: grid;
    background-color: var(--bg3);
    grid-template-columns: 70px 110px;
    border-radius: 9px;
    align-items: center;
    height: 40px;
    gap: 12px;

    .date {
        font-size: 15px;
        padding: 0 12px;
    }

    .date-input {
        background-color: var(--bg4);
        box-shadow: 0 0 0 1.5px var(--lvl4-borders) inset;
        padding: 6px 10px;
        border-radius: 5px;
        font-size: 12px;
    }
`

const DatePicker = ({ value, ...restProps }: Props) => {
    const date = new Date(value)
    const dateString = isToday(date)
        ? 'Сегодня'
        : date.toLocaleDateString('ru-RU', {
              day: '2-digit',
              month: '2-digit',
              year: '2-digit',
          })

    return (
        <Stack className={styles} direction="horizontal">
            <div className="date">{dateString}</div>

            <CustomDatePicker value={value} {...restProps}>
                <div className="date-input">Изменить дату</div>
            </CustomDatePicker>
        </Stack>
    )
}

export default DatePicker
