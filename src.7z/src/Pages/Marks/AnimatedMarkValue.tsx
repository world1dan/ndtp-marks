import { memo, useRef } from 'react'

import { Icon24HelpOutline } from '@vkontakte/icons'
import { AnimatePresence, Variants, motion } from 'framer-motion'

const markColorMap = {
    decrease: '#ff3b30',
    increase: '#34c759',
}

const variants: Variants = {
    initial: {
        position: 'absolute',
        opacity: 0,
        y: -60,
    },
    animate: (markDelta: 'decrease' | 'increase' | null) => {
        return {
            opacity: 1,
            y: 0,
            color: markDelta
                ? [
                      markColorMap[markDelta],
                      getComputedStyle(document.documentElement)
                          .getPropertyValue('--text-color')
                          .trim(),
                  ]
                : undefined,
            transition: {
                duration: 0.3,
                color: {
                    delay: 0.8,
                },
            },
            transitionEnd: {
                position: 'static',
            },
        }
    },
    exit: {
        position: 'absolute',
        opacity: 0,
        y: 30,
        scale: 0.4,
        transition: {
            duration: 0.2,
        },
    },
}

export interface Props {
    markValue: number | null | undefined
    className?: string
}

const AnimatedMarkValue = ({ markValue, className }: Props) => {
    const prevMarkValue = useRef(markValue)

    let delta = null

    if (
        markValue &&
        prevMarkValue.current &&
        prevMarkValue.current !== markValue
    ) {
        delta = prevMarkValue.current > markValue ? 'decrease' : 'increase'
    }

    prevMarkValue.current = markValue

    return (
        <AnimatePresence initial={false}>
            <motion.div
                className={className}
                key={markValue}
                custom={delta}
                variants={variants}
                initial="initial"
                animate="animate"
                exit="exit"
            >
                {!markValue || isNaN(markValue) ? (
                    <Icon24HelpOutline fill="var(--text-secondary-color)" />
                ) : (
                    Number(markValue.toFixed(2))
                )}
            </motion.div>
        </AnimatePresence>
    )
}

export default memo(AnimatedMarkValue)
