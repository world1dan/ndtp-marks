import { useContext, useState } from 'react'

import { css } from '@linaria/core'

import {
    Icon20CalendarOutline,
    Icon24DeleteOutline,
    Icon24WriteOutline,
} from '@vkontakte/icons'

import { BottonSheetContext } from 'Components/BottomSheet/BottomSheetContext'
import Button from 'Components/Button'
import Stack from 'Components/Stack'

import { IMark } from 'Types/marks'
import { ISubject } from 'Types/subjects'

import MarkCircle from '../MarkCircle'
import MarkEditor from '../MarksPicker'

const styles = css`
    display: flex;
    flex-direction: column;
    gap: 10px;
    padding: 12px;

    .modal-title {
        padding-left: 5px;
        color: var(--text-secondary-color);
        font-weight: 600;
        font-size: 14px;
    }

    .info {
        display: grid;
        grid-template-rows: 100px 30px 20px;
        place-items: center;
        gap: 10px;
        height: 220px;
    }

    .subject {
        font-weight: 600;
        font-size: 20px;
    }

    .addedAt {
        display: flex;
        gap: 8px;
        align-items: center;
        color: var(--text-secondary-color);
        font-weight: 600;
        font-size: 15px;
    }

    .mark-num {
        display: flex;
        grid-row: 1 / 3;
        align-items: center;
        justify-content: center;
        font-weight: 700;
        font-size: 36px;
        background-color: var(--bg4);
        border-radius: 9px;
        box-shadow: 0 0 0 1px var(--lvl4-borders) inset;
    }
`

export interface Props {
    mark: IMark
    markType: 'quarterMark' | 'yearMark'
    subject: ISubject
    removeMark?: (mark: IMark) => void
    editMark?: (mark: IMark, update: Partial<IMark>) => void
    readOnly?: boolean
}

const AboutMark = ({
    mark,
    markType,
    subject,
    removeMark,
    editMark,
    readOnly,
}: Props) => {
    const { close } = useContext(BottonSheetContext)
    const [updateMarkDialog, setUpdateMarkDialog] = useState(false)

    const date = new Date(mark.addedAt).toLocaleString()

    const handleMarkEdit = (
        value: number,
        isImportant: boolean,
        addedAt?: string
    ) => {
        editMark &&
            editMark(mark, {
                value,
                isImportant,
                addedAt: addedAt ?? mark.addedAt,
            })
    }

    const handleRemove = () => {
        close()
        setTimeout(() => {
            removeMark && removeMark(mark)
        }, 150)
    }

    return (
        <>
            <div className={styles}>
                <div className="modal-title">
                    {markType === 'quarterMark'
                        ? 'Оценка'
                        : 'Оценка за четверть'}
                </div>
                <div className="info">
                    <MarkCircle
                        value={mark.value}
                        isImportant={mark.isImportant}
                        large
                    />

                    <div className="subject">
                        {subject.fullTitle || subject.title}
                    </div>
                    <div className="addedAt">
                        <Icon20CalendarOutline />
                        {date}
                    </div>
                </div>
                {!readOnly && removeMark && (
                    <Stack direction="horizontal">
                        <Button
                            size="large"
                            onClick={() => setUpdateMarkDialog(true)}
                            iconLeft={
                                <Icon24WriteOutline width={28} height={28} />
                            }
                        >
                            Изменить
                        </Button>
                        <Button
                            size="large"
                            onClick={handleRemove}
                            appearance="destructive"
                            iconLeft={<Icon24DeleteOutline fill="var(--red)" />}
                        >
                            Удалить
                        </Button>
                    </Stack>
                )}
            </div>
            {updateMarkDialog && (
                <MarkEditor
                    subjectColor={subject.color}
                    handleClose={() => setUpdateMarkDialog(false)}
                    handleSubmit={handleMarkEdit}
                    description={subject.fullTitle || subject.title}
                    title={`Изменить оценку (${mark.value})`}
                    withImportanceToggle
                />
            )}
        </>
    )
}

export default AboutMark
