import { memo, useState } from 'react'

import { css } from '@linaria/core'

import { Icon24AddCircleOutline } from '@vkontakte/icons'

import { IFinalSubjectGrades, IMark } from 'Types/marks'
import { ISubject } from 'Types/subjects'

import AboutMark from '../AboutMark'
import MarkCircle, { styles as markCircleStyles } from '../MarkCircle'
import MarksPicker from '../MarksPicker'

export const styles = css`
    align-items: center;
    background-color: var(--bg2);
    border-radius: 5px;
    display: grid;
    gap: 10px;
    grid-template-columns: 4px 74px 1fr 1fr 1fr 1fr 54px;
    justify-items: center;
    min-height: 50px;
    border: 1.5px var(--borders) solid;
    padding: 5px;

    .color-indicator {
        border-radius: 2px;
        height: 100%;
        width: 100%;
    }

    .year-mark {
        border-left: 2px var(--borders) solid;
        display: flex;
        justify-content: center;
        width: 100%;
    }

    .subject-title {
        justify-self: flex-start;
        font-size: 14px;
        font-weight: 600;
        margin: 0;
    }

    @media (max-width: 340px) {
        gap: 6px;
        grid-template-columns: 4px 70px 1fr 1fr 1fr 1fr 50px;

        .subject-title {
            font-size: 14px;
            margin-left: 4px;
        }
    }

    @media (min-width: 600px) {
        grid-template-columns: 7px 140px 1fr 1fr 1fr 1fr 90px;
        overflow: hidden;

        .subject-title {
            padding-left: 10px;
        }
    }
`

export interface Props {
    subject: ISubject
    marks: IFinalSubjectGrades
    readOnly?: boolean
    setFinalMark: (quarterId: number, subjectID: string, mark: IMark) => void
    removeFinalMark: (quarterId: number, subjectID: string) => void
}

const YearSubjectMarks = ({
    subject,
    marks,
    readOnly,
    setFinalMark,
    removeFinalMark,
}: Props) => {
    const [addDialog, setAddDialog] = useState<false | number>(false)

    let sum = 0
    let count = 0

    const quarterMarks = []

    for (let i = 1; i <= 4; i++) {
        const mark = marks[i]

        if (mark) {
            sum += mark.value
            count++
            quarterMarks.push(
                <MarkCircle
                    value={mark.value}
                    key={subject.id + i}
                    aboutMarkContent={
                        <AboutMark
                            mark={mark}
                            subject={subject}
                            readOnly={readOnly}
                            markType="yearMark"
                            editMark={(mark, update) =>
                                setFinalMark(i, subject.id, {
                                    ...mark,
                                    ...update,
                                })
                            }
                            removeMark={() => removeFinalMark(i, subject.id)}
                        />
                    }
                />
            )
        } else {
            quarterMarks.push(
                <div
                    className={markCircleStyles}
                    onClick={!readOnly ? () => setAddDialog(i) : undefined}
                    key={i}
                >
                    {!readOnly && (
                        <Icon24AddCircleOutline fill="var(--text-secondary-color)" />
                    )}
                </div>
            )
        }
    }

    let average: number | null = sum / count

    if (average) {
        average = Math.round(Number(average.toFixed(2)))
    } else {
        average = null
    }

    const handleSubmit = (mark: number) =>
        setFinalMark(addDialog as number, subject.id, {
            value: mark,
            addedAt: new Date().toUTCString(),
        })

    return (
        <>
            <div className={styles}>
                <div
                    className="color-indicator"
                    style={{
                        backgroundColor: subject.color,
                        boxShadow: `${subject.color} 0px 0px 3px`,
                    }}
                />

                <h5 className="subject-title">{subject.title}</h5>

                {quarterMarks}

                <div className="year-mark">
                    <MarkCircle value={average} />
                </div>
            </div>

            {addDialog && (
                <MarksPicker
                    handleSubmit={handleSubmit}
                    handleClose={() => setAddDialog(false)}
                    title={`Оценка за ${addDialog} четверть`}
                    description={subject.fullTitle || subject.title}
                    subjectColor={subject.color}
                />
            )}
        </>
    )
}

export default memo(
    YearSubjectMarks,
    (prevProps, nextProps) =>
        JSON.stringify(prevProps) === JSON.stringify(nextProps)
)
