import { useCallback, useMemo } from 'react'

import { deleteField, doc, setDoc } from 'firebase/firestore'
import { useDocumentData } from 'react-firebase-hooks/firestore'

import { IFinalGrades, IMark } from 'Types/marks'

import { firestore } from '../../../Firebase'

const useFinalGrades = (uid: string) => {
    const finalGradesDoc = useMemo(() => {
        return doc(firestore, `finalGrades/${uid}`)
    }, [uid])

    const [finalGrades] = useDocumentData<IFinalGrades>(finalGradesDoc)

    const setFinalMark = useCallback(
        (quarterId: number, subjectId: string, mark: IMark) => {
            setDoc(
                finalGradesDoc,
                {
                    [subjectId]: {
                        [quarterId]: mark,
                    },
                },
                { merge: true }
            )
        },
        [finalGradesDoc]
    )

    const removeFinalMark = useCallback(
        (quarterId: number, subjectId: string) => {
            setDoc(
                finalGradesDoc,
                {
                    [subjectId]: {
                        [quarterId]: deleteField(),
                    },
                },
                { merge: true }
            )
        },
        [finalGradesDoc]
    )

    return { finalGrades, finalGradesDoc, setFinalMark, removeFinalMark }
}

export default useFinalGrades
