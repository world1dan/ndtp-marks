import { css, cx } from '@linaria/core'

import { IFinalGrades } from 'Types/marks'
import { ISubjectsManifest } from 'Types/subjects'

import AnimatedMarkValue from '../AnimatedMarkValue'
import { styles as yearSubjectMarksStyles } from './YearSubjectMarks'

const styles = css`
    .year-mark,
    .quarter-mark {
        font-weight: bold;
    }

    .subject-title {
        padding: 6px 0;
    }

    .year-mark {
        border-left: none;
    }

    .quarter-mark-wrapper {
        position: relative;
        width: 100%;
        height: 100%;
        display: grid;
        place-items: center;
        overflow: hidden;
    }
`

export interface Props {
    finalGrades: IFinalGrades | undefined | null
    subjects: ISubjectsManifest
}

const AverageGrades = ({ finalGrades, subjects }: Props) => {
    const sumInQuarters = {}
    const countInQuarters = {}

    let yearMarksSum = 0
    let subjectsWithYearMark = 0

    Object.entries(finalGrades ?? {}).forEach(([subjectId, grades]) => {
        if (!subjects[subjectId].isHasMarks) return

        let count = 0
        let sum = 0

        for (let i = 1; i <= 4; i++) {
            if (grades[i]) {
                count += 1
                sum += grades[i].value
                sumInQuarters[i] = (sumInQuarters[i] ?? 0) + grades[i].value
                countInQuarters[i] = (countInQuarters[i] ?? 0) + 1
            }
        }

        let average = sum / count

        if (average) {
            average = Math.round(Number(average.toFixed(2)))
            yearMarksSum += average
            subjectsWithYearMark += 1
        }
    })

    const quarterMarksComponents = []

    for (let i = 1; i <= 4; i++) {
        const average = sumInQuarters[i] / countInQuarters[i]

        quarterMarksComponents.push(
            <div className="quarter-mark-wrapper" key={i}>
                <AnimatedMarkValue
                    className="quarter-mark"
                    markValue={average ? Number(average.toFixed(2)) : undefined}
                />
            </div>
        )
    }

    let globalAverage: string | number | null =
        yearMarksSum / subjectsWithYearMark

    if (!isNaN(globalAverage)) {
        globalAverage = Number(globalAverage.toFixed(2))
    } else {
        globalAverage = null
    }

    return (
        <div className={cx(yearSubjectMarksStyles, styles)}>
            <div></div>
            <h5 className="subject-title">Средний балл</h5>
            {quarterMarksComponents}
            <div className="year-mark quarter-mark-wrapper">
                {
                    <AnimatedMarkValue
                        className="quarter-mark"
                        markValue={globalAverage}
                    />
                }
            </div>
        </div>
    )
}

export default AverageGrades
