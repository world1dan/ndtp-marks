import { css } from '@linaria/core'

import Suspense from 'Components/Suspense'

import useSubjects from 'Hooks/useSubjects'

import AverageGrades from './AverageGrades'
import YearSubjectMarks from './YearSubjectMarks'
import useFinalGrades from './useFinalGrades'
import useAuth from 'Hooks/useAuth'
import ScrollView from 'Components/ScrollView'

const styles = css`
    display: grid;
    gap: 6px;
    margin: 0 auto;
    max-width: 580px;

    .header {
        border: 1.5px var(--borders) solid;
        align-items: center;
        background-color: var(--bg2);
        border-radius: 5px;
        display: grid;
        gap: 10px;
        grid-template-columns: 92px 1fr 1fr 1fr 1fr 54px;
        height: 46px;
        padding: 5px;

        > * {
            font-size: 15px;
            font-weight: 600;
            text-align: center;

            &.subject-column-name {
                padding-left: 14px;
                text-align: left;
            }

            &.year {
                border-left: 2px var(--borders) solid;
                justify-content: center;
            }
        }

        @media (min-width: 600px) {
            grid-template-columns: 157px 1fr 1fr 1fr 1fr 90px;

            .subject-column-name {
                padding-left: 27px;
            }
        }
    }
`

export interface Props {
    uid?: string
    readOnly?: boolean
}

const orderOfSubjects = [
    'bel',
    'bel_lit',
    'rus',
    'rus_lit',
    'eng',
    'math',
    'inform',
    'world_history',
    'bel_history',
    'social',
    'geo',
    'bio',
    'phis',
    'him',
    'cherch',
    'medp',
    'pe',
    'trud',
    'upk',
    'dpp',
]

const YearMarks = ({ uid, readOnly }: Props) => {
    const { user } = useAuth()
    const subjects = useSubjects()
    const { finalGrades, setFinalMark, removeFinalMark } = useFinalGrades(uid ?? user?.uid)

    if (!subjects) return null

    return (
        <ScrollView>
        <div className={styles}>
            <header className="header">
                <span className="subject-column-name">Предмет</span>
                <span>I</span>
                <span>II</span>
                <span>III</span>
                <span>IV</span>
                <span className="year">Год</span>
            </header>
            <Suspense delay={300} rowsCount={16}>
                {Object.values(subjects)
                    .filter((subject) => subject.isHasMarks)
                    .sort(
                        (a, b) =>
                            orderOfSubjects.indexOf(a.id) -
                            orderOfSubjects.indexOf(b.id)
                    )
                    .map((subject) => (
                        <YearSubjectMarks
                            key={subject.id}
                            setFinalMark={setFinalMark}
                            removeFinalMark={removeFinalMark}
                            readOnly={readOnly}
                            subject={subject}
                            marks={finalGrades?.[subject.id] ?? {}}
                        />
                    ))}

                <AverageGrades finalGrades={finalGrades} subjects={subjects} />
            </Suspense>
        </div>
        </ScrollView>
    )
}

export default YearMarks
