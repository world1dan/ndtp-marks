import { DocumentReference } from 'firebase/firestore'
import { createContext } from 'react'

const QuarterMarksDocContext = createContext({} as DocumentReference)

export default QuarterMarksDocContext
