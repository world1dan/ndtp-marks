import { createContext } from 'react'

export interface ISchoolTermContext {
    currentSchoolTermId: number
    selectedSchoolTermId: number
}
const SchoolTermContext = createContext({} as ISchoolTermContext)

export default SchoolTermContext
