import { useCallback, useMemo, useState } from 'react'

import { css } from '@linaria/core'

import { useSearchParams } from 'react-router-dom'

import ErrorMessage from 'Components/ErrorMessage'
import NotCurrentTermWarn from 'Components/NotCurrentTermWarn'
import Stack from 'Components/Stack'
import Suspense from 'Components/Suspense'

import useSubjects from 'Hooks/useSubjects'

import getCurrentSchoolQuarter from 'Utils/getCurrentSchoolQuarter'

import Average from './Average'
import Header from './Header'
import QuarterMarksContext from './QuarterMarksContext'
import QuarterMarksDocContext from './QuarterMarksDocContext'
import SchoolTermContext, { ISchoolTermContext } from './SchoolTermContext'
import SubjectMarks from './SubjectMarks'
import useQuarterMarks from './useQuarterMarks'
import useAuth from 'Hooks/useAuth'
import ScrollView from 'Components/ScrollView'

const styles = css`
    display: grid;
    grid-auto-flow: row;
    row-gap: 8px;


    @media (min-width: 750px) {
        column-gap: 12px;
        grid-auto-flow: row;
        grid-template-columns: 1fr 1fr;
        row-gap: 12px;
    }
`
const wrapperStyles = css`
max-width: 1100px;
margin: 0 auto;

`
export interface Props {
    uid?: string
    readOnly?: boolean
}

const orderOfSubjects = [
    'bel',
    'bel_lit',
    'rus',
    'rus_lit',
    'eng',
    'math',
    'inform',
    'world_history',
    'bel_history',
    'social',
    'geo',
    'bio',
    'phis',
    'him',
    'cherch',
    'medp',
    'pe',
    'trud',
    'upk',
    'dpp',
]

const QuarterMarks = ({
    uid,
    readOnly,
}: Props) => {
    const {user } = useAuth()

    const [searchParams, setSearchParams] = useSearchParams()
    const subjectSearchQuery = searchParams.get('subjectSearchQuery') ?? ''

    const [schoolQuarterId, setSchoolQuarterId] = useState(
        () => getCurrentSchoolQuarter()?.num ?? 2
    )

    const { quarterMarks, quarterMarksDoc, loading } = useQuarterMarks(
        schoolQuarterId,
        uid ?? user?.uid
    )

    const currentSchoolTermId = getCurrentSchoolQuarter()?.num ?? 2

    const subjects = useSubjects()

    const handleSearch = useCallback(
        (query: string) => {
            setSearchParams(
                {
                    subjectSearchQuery: query,
                },
                {
                    replace: true,
                }
            )
        },
        [setSearchParams]
    )

    const schoolTermContext = useMemo<ISchoolTermContext>(
        () => ({
            currentSchoolTermId,
            selectedSchoolTermId: schoolQuarterId,
        }),
        [currentSchoolTermId, schoolQuarterId]
    )

    if (!subjects) return null

    const subjectsWithMarks = Object.values(subjects)
        .filter(
            (subject) =>
                subject.isHasMarks &&
                (subjectSearchQuery
                    ? (subject.fullTitle ?? subject.title)
                          .toLowerCase()
                          .includes(subjectSearchQuery.toLowerCase())
                    : true)
        )
        .sort((a, b) => a.title.localeCompare(b.title))

    return (
        <ScrollView>
            <Stack className={wrapperStyles}>
                <SchoolTermContext.Provider value={schoolTermContext}>
                    <QuarterMarksDocContext.Provider value={quarterMarksDoc}>
                        <QuarterMarksContext.Provider value={quarterMarks ?? {}}>
                            <Header
                                searchQuery={subjectSearchQuery}
                                setSearchQuery={handleSearch}
                                schoolQuarterId={schoolQuarterId}
                                setSchoolQuarterId={setSchoolQuarterId}
                            />
                            {currentSchoolTermId !== schoolQuarterId && (
                                <NotCurrentTermWarn
                                    text="Ты просматриваешь оценки за прошлую или будущую четверть"
                                    handleGoBack={() =>
                                        setSchoolQuarterId(currentSchoolTermId)
                                    }
                                />
                            )}
                            <Suspense
                                key={schoolQuarterId}
                                delay={300}
                                rowsCount={18}
                                rowsHeight={90}
                                twoColumns
                                forceLoadingState={loading}
                            >
                                <div className={styles}>
                                    {subjectsWithMarks.length ? (
                                        subjectsWithMarks
                                            .sort(
                                                (a, b) =>
                                                    orderOfSubjects.indexOf(a.id) -
                                                    orderOfSubjects.indexOf(b.id)
                                            )
                                            .map((subject) => {
                                                return (
                                                    <SubjectMarks
                                                        readOnly={readOnly}
                                                        key={subject.id}
                                                        subject={subject}
                                                        subjectMarks={
                                                            quarterMarks?.[
                                                                subject.id
                                                            ] ?? {
                                                                marksList: [],
                                                                averageMarkTarget:
                                                                    null,
                                                            }
                                                        }
                                                    />
                                                )
                                            })
                                    ) : (
                                        <ErrorMessage title="Ничего не найдено" />
                                    )}
                                </div>
                                <Average
                                    quarterMarks={quarterMarks}
                                    schoolQuarterID={schoolQuarterId}
                                />
                            </Suspense>
                        </QuarterMarksContext.Provider>
                    </QuarterMarksDocContext.Provider>
                </SchoolTermContext.Provider>
            </Stack>
        </ScrollView>
    )
}

export default QuarterMarks
