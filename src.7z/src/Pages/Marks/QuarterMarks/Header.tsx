import { memo } from 'react'
import { css } from '@linaria/core'

import { Icon24Search } from '@vkontakte/icons'

import QuarterPicker from '../QuarterPicker'
import Stack from 'Components/Stack'

const styles = css`
    background: var(--bg2);
    border-radius: 7px;
    padding: 4px 10px;
    border: 1.5px var(--borders) solid;
    max-width: 500px;
    margin: 0 auto;
    width: 100%;

    .search-input {
        flex-grow: 1;
        height: 100%;
        font-size: 15px;
        font-weight: 600;
        background-color: var(--bg2);
    }
`

export interface Props {
    searchQuery: string
    setSearchQuery: (query: string) => void
    schoolQuarterId: number
    setSchoolQuarterId: (id: number) => void
}

const Header = ({
    searchQuery,
    setSearchQuery,
    schoolQuarterId,
    setSchoolQuarterId,
}: Props) => {
    return (
        <Stack direction="horizontal" className={styles}>
            <Icon24Search
                width={22}
                height={22}
                fill="var(--text-secondary-color)"
            />
            <input
                className="search-input"
                type="text"
                placeholder="Найти предмет"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
            />
            <QuarterPicker
                setActiveQuarterId={setSchoolQuarterId}
                activeQuarterId={schoolQuarterId}
            />
        </Stack>
    )
}

export default memo(Header)
