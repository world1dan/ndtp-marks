import { createContext } from 'react'
import { IQuarterMarks } from 'Types/marks'

const QuarterMarksContext = createContext({} as IQuarterMarks)

export default QuarterMarksContext
