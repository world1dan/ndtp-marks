import { memo, useState } from 'react'

import { cx } from '@linaria/core'

import MarkEditor from 'Pages/Marks/MarksPicker'

import { IQuarterSubjectMarks } from 'Types/marks'
import { ISubject } from 'Types/subjects'

import MarkCircle from '../../MarkCircle'
import AboutQuarterMark from './AboutQuarterMark'
import AddMark from './AddMark'
import AverageMark from './AverageMark'
import NoNewMarksWarning from './NoNewMarksWarning'
import Tools from './Tools'
import './style.scss'
import useSubjectMarksController from './useSubjectMarksController'

export interface Props {
    subject: ISubject
    subjectMarks: IQuarterSubjectMarks
    embedded?: boolean
    readOnly?: boolean
}

const SubjectMarks = ({ subject, subjectMarks, embedded, readOnly }: Props) => {
    const [targetDialog, setTargetDialog] = useState(false)

    const { changeMarkTarget, addQuarterMark, removeAllSubjectMarks } =
        useSubjectMarksController(subject)

    const openTargetDialog = readOnly ? undefined : () => setTargetDialog(true)
    const closeTargetDialog = () => setTargetDialog(false)

    const marksCount = subjectMarks.marksList?.length ?? 0

    return (
        <>
            <div className={cx('SubjectMarks', embedded && 'embedded')}>
                {!embedded && (
                    <div
                        className="color-indicator"
                        style={{
                            backgroundColor: subject.color,
                            boxShadow: '0px 0px 3px ' + subject.color,
                        }}
                    />
                )}

                <div className="main-content">
                    {!embedded && (
                        <h5 className="subject-title">
                            {subject.fullTitle || subject.title}
                        </h5>
                    )}

                    <NoNewMarksWarning marksList={subjectMarks.marksList} />

                    <div className="marks-container">
                        {subjectMarks.marksList &&
                            subjectMarks.marksList
                                .sort(
                                    (a, b) =>
                                        new Date(a.addedAt).getTime() -
                                        new Date(b.addedAt).getTime()
                                )
                                .map((mark) => (
                                    <MarkCircle
                                        key={mark.id ?? mark.addedAt}
                                        value={mark.value}
                                        isImportant={mark.isImportant}
                                        aboutMarkContent={
                                            <AboutQuarterMark
                                                markType="quarterMark"
                                                mark={mark}
                                                subject={subject}
                                                readOnly={readOnly}
                                            />
                                        }
                                    />
                                ))}
                        {!readOnly && (
                            <AddMark
                                subject={subject}
                                addQuarterMark={addQuarterMark}
                                layoutDependency={marksCount}
                            />
                        )}
                    </div>
                    <Tools
                        subjectMarks={subjectMarks}
                        removeAllSubjectMarks={
                            readOnly ? undefined : removeAllSubjectMarks
                        }
                        openTargetDialog={openTargetDialog}
                    />
                </div>

                <AverageMark
                    subjectMarks={subjectMarks}
                    handleTargetDialogOpen={openTargetDialog}
                />
            </div>
            {targetDialog && !readOnly && (
                <MarkEditor
                    handleClear={() => changeMarkTarget(null)}
                    handleSubmit={changeMarkTarget}
                    handleClose={closeTargetDialog}
                    title="Выбери цель для этого предмета"
                    description={subject.fullTitle || subject.title}
                    subjectColor={subject.color}
                />
            )}
        </>
    )
}

export default memo(SubjectMarks, (prevProps, nextProps) => {
    return (
        JSON.stringify(prevProps.subjectMarks) ==
        JSON.stringify(nextProps.subjectMarks)
    )
})
