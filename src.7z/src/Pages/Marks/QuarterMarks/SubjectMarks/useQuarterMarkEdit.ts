import { useContext } from 'react'

import { arrayRemove, setDoc } from 'firebase/firestore'

import { IMark } from 'Types/marks'
import { ISubject } from 'Types/subjects'

import QuarterMarksContext from '../QuarterMarksContext'
import QuarterMarksDocContext from '../QuarterMarksDocContext'

const useQuarterMarkEdit = (subject: ISubject) => {
    const quarterMarks = useContext(QuarterMarksContext)
    const quarterMarksDoc = useContext(QuarterMarksDocContext)

    const marksList = quarterMarks?.[subject.id]?.marksList ?? []

    const updateMark = (mark: IMark, update: Partial<IMark>) => {
        const updatedMarksList = marksList.map((m: IMark) => {
            if (m.addedAt == mark.addedAt) {
                return { ...m, ...update }
            } else {
                return m
            }
        })

        setDoc(
            quarterMarksDoc,
            {
                [subject.id]: {
                    marksList: updatedMarksList,
                },
            },
            { merge: true }
        )
    }

    const removeQuarterMark = (mark: IMark) => {
        setDoc(
            quarterMarksDoc,
            {
                [subject.id]: {
                    marksList: arrayRemove(mark),
                },
            },
            { merge: true }
        )
    }

    return {
        updateMark,
        removeQuarterMark,
    }
}

export default useQuarterMarkEdit
