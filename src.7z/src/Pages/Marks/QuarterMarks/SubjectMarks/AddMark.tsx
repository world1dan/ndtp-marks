import { useState } from 'react'

import { Icon24AddCircleOutline } from '@vkontakte/icons'
import { motion } from 'framer-motion'

import { styles } from 'Pages/Marks/MarkCircle'
import MarkEditor from 'Pages/Marks/MarksPicker'

import { ISubject } from 'Types/subjects'

export interface Props {
    addQuarterMark: (
        value: number,
        isImportant: boolean,
        addedAt?: string
    ) => void
    subject: ISubject
    layoutDependency: number
}

const AddMark = ({ addQuarterMark, subject, layoutDependency }: Props) => {
    const [addMarkMenuOpen, setAddMarkMenuOpen] = useState(false)

    return (
        <>
            <motion.button
                className={styles}
                onClick={() => setAddMarkMenuOpen(true)}
                layout="position"
                layoutDependency={layoutDependency}
            >
                <Icon24AddCircleOutline fill="var(--text-secondary-color)" />
            </motion.button>
            {addMarkMenuOpen && (
                <MarkEditor
                    title="Новая оценка"
                    description={subject.fullTitle || subject.title}
                    handleClose={() => setAddMarkMenuOpen(false)}
                    withImportanceToggle
                    subjectColor={subject.color}
                    handleSubmit={addQuarterMark}
                    withDatePicker
                />
            )}
        </>
    )
}

export default AddMark
