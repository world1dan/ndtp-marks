import { useLayoutEffect, useRef, useState } from 'react'

import { css } from '@linaria/core'

import { AnimatePresence } from 'framer-motion'
import { nanoid } from 'nanoid'

import SheetView from 'Components/SheetView'

import MarkCircle from 'Pages/Marks/MarkCircle'

import useKeyPress from 'Hooks/useKeyPress'

import { IMark, IQuarterSubjectMarks } from 'Types/marks'

import AnimatedMarkValue from '../../../AnimatedMarkValue'
import MarksInput from '../../../MarksNumpad'
import getAverageMark from '../../../Utils/getAverageMark'

const styles = css`
    display: flex;
    flex-direction: column;
    gap: 18px;
    padding: 10px;

    @media (min-height: 700px) {
        padding: 16px;
        gap: 22px;
    }

    .average-mark {
        align-items: center;
        bottom: 0;
        display: flex;
        font-size: 40px;
        font-weight: 700;
        justify-content: center;
        height: 70px;

        @media (min-height: 700px) {
            height: 90px;
            font-size: 48px;
        }
    }

    .average-mark-target {
        margin: 0 auto;
        background-color: var(--bg4);
        color: var(--text-secondary-color);
        font-weight: 600;
        padding: 6px 14px;
        border-radius: 9px;
        font-size: 12px;

        @media (min-height: 700px) {
            font-size: 13px;
        }
    }

    .info {
        color: var(--text-secondary-color);
        font-size: 13px;
        font-weight: 600;
        margin-bottom: 13px;
        text-align: center;

        @media (min-height: 700px) {
            font-size: 14px;
        }
    }

    .marks-container {
        display: flex;
        align-items: flex-start;
        gap: 5px;
        height: 48px;
        overflow-x: auto;

        @media (min-width: 768px) {
            height: 52px;
            gap: 6px;
            max-width: 500px;
            margin: 0 auto;
        }

        > * {
            flex-shrink: 0;
        }
    }
`
export interface Props {
    initialMarks?: IQuarterSubjectMarks['marksList']
    averageMarkTarget?: number | null | undefined
    handleClose: () => void
}

const Calculator = ({
    initialMarks = [],
    averageMarkTarget,
    handleClose,
}: Props) => {
    const addedMarksContainerRef = useRef<HTMLDivElement>(null)

    const [addedMarks, setAddedMarks] = useState<IMark[]>([])

    useLayoutEffect(() => {
        const element = addedMarksContainerRef.current
        if (element) {
            addedMarksContainerRef.current?.scroll({
                left: element.scrollWidth,
                behavior: 'smooth',
            })
        }
    }, [addedMarks.length])

    const removeMark = (mark: IMark) => {
        setAddedMarks((prev) => {
            return prev.filter((m) => {
                return m.id !== mark.id
            })
        })
    }

    const removeLast = () => {
        setAddedMarks((prev) => {
            return prev.slice(0, -1)
        })
    }

    useKeyPress('Backspace', removeLast)

    const handleMarkInput = (markValue: number) => {
        setAddedMarks((prev) => [
            ...prev,
            {
                id: nanoid(),
                value: markValue,
                addedAt: new Date().toUTCString(),
            },
        ])
    }

    const averageMark = getAverageMark([...initialMarks, ...addedMarks])

    return (
        <SheetView
            handleClose={handleClose}
            headerTitle="Калькулятор оценок"
            height="fullscreen"
        >
            <div className={styles}>
                <div className="average-mark">
                    <AnimatedMarkValue markValue={averageMark} />
                </div>
                {averageMarkTarget && (
                    <div className="average-mark-target">
                        Цель: {averageMarkTarget}
                    </div>
                )}
                <div className="marks-display">
                    <div className="info">Оценки, которые уже есть</div>

                    <div className="marks-container">
                        {initialMarks.map((mark) => {
                            return (
                                <MarkCircle value={mark.value} key={mark.id} />
                            )
                        })}
                    </div>

                    <div className="info">Добавленные оценки</div>

                    <div
                        className="marks-container"
                        ref={addedMarksContainerRef}
                    >
                        <AnimatePresence>
                            {addedMarks.map((mark) => {
                                return (
                                    <MarkCircle
                                        value={mark.value}
                                        withAnimation
                                        handleClick={() => removeMark(mark)}
                                        key={mark.id}
                                    />
                                )
                            })}
                        </AnimatePresence>
                    </div>
                </div>
                <MarksInput
                    handleMarkInput={handleMarkInput}
                    handleLastMarkRemove={removeLast}
                />
            </div>
        </SheetView>
    )
}

export default Calculator
