import { useState } from 'react'

import { css } from '@linaria/core'

import {
    Icon24DeleteOutline,
    Icon24StatisticsOutline,
    Icon28ArrowUpCircleOutline,
} from '@vkontakte/icons'

import ContextMenu from 'Components/ContextMenu'
import ContextMenuBtn from 'Components/ContextMenu/ContextMenuBtn'

import { IQuarterSubjectMarks } from 'Types/marks'

import Calculator from './Calculator'

const styles = css`
    position: absolute;
    right: -3px;
    top: -3px;
`

export interface Props {
    removeAllSubjectMarks?: () => void
    subjectMarks: IQuarterSubjectMarks
    openTargetDialog?: () => void
}

const Tools = ({
    removeAllSubjectMarks,
    subjectMarks,
    openTargetDialog,
}: Props) => {
    const [calculatorOpen, setCalculatorOpen] = useState(false)

    return (
        <>
            <div className={styles}>
                <ContextMenu offsetLeft={-4} offsetTop={16}>
                    <ContextMenuBtn
                        title="Калькулятор"
                        icon={
                            <Icon24StatisticsOutline width={23} height={23} />
                        }
                        onClick={() => setCalculatorOpen(true)}
                    />
                    {openTargetDialog && (
                        <ContextMenuBtn
                            title="Изменить цель"
                            onClick={openTargetDialog}
                            icon={
                                <Icon28ArrowUpCircleOutline
                                    width={23}
                                    height={23}
                                />
                            }
                        />
                    )}
                    {removeAllSubjectMarks && (
                        <ContextMenuBtn
                            title="Удалить все"
                            icon={
                                <Icon24DeleteOutline
                                    width={23}
                                    height={23}
                                    fill="var(--red)"
                                />
                            }
                            onClick={removeAllSubjectMarks}
                        />
                    )}
                </ContextMenu>
            </div>
            {calculatorOpen && (
                <Calculator
                    initialMarks={subjectMarks.marksList}
                    averageMarkTarget={subjectMarks.averageMarkTarget}
                    handleClose={() => setCalculatorOpen(false)}
                />
            )}
        </>
    )
}

export default Tools
