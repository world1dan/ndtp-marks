import { useState } from 'react'

import { css } from '@linaria/core'

import { Icon16HelpOutline } from '@vkontakte/icons'

import { IQuarterSubjectMarks } from 'Types/marks'

import AnimatedNum from '../../AnimatedMarkValue'
import getAverageMark from '../../Utils/getAverageMark'
import Calculator from './Tools/Calculator'

export interface Props {
    subjectMarks: IQuarterSubjectMarks
    handleTargetDialogOpen: (() => void) | undefined
}

const styles = css`
    display: grid;
    gap: 4px;
    grid-template-rows: 1fr 28px;
    max-height: 120px;

    .gpa,
    .gpa-target {
        display: flex;
        justify-content: center;
        align-items: center;
        background: var(--bg4);
        border-radius: 5px;
        box-shadow: 0 0 0 1.5px var(--lvl4-borders) inset;
        gap: 4px;
    }

    .gpa {
        position: relative;
        overflow: hidden;
        font-size: 18px;
        font-weight: bold;
        transition: box-shadow 200ms;

        @media (min-width: 500px) {
            font-size: 21px;
        }
    }

    .gpa-target {
        color: var(--text-secondary-color);
        font-size: 10px;
        font-weight: 600;

        @media (min-width: 500px) {
            font-size: 11px;
        }
    }
`

const AverageMark = ({ subjectMarks, handleTargetDialogOpen }: Props) => {
    const [calculatorOpen, setCalculatorOpen] = useState(false)

    const average = subjectMarks.marksList
        ? getAverageMark(subjectMarks.marksList)
        : undefined

    const isLowerThanTarget =
        average &&
        subjectMarks.averageMarkTarget &&
        Math.round(average) < subjectMarks.averageMarkTarget

    const averageToDisplay = average ? Number(average.toFixed(2)) : null

    return (
        <div className={styles}>
            <button
                className="gpa"
                onClick={() => setCalculatorOpen(true)}
                style={{
                    boxShadow: isLowerThanTarget
                        ? 'inset 0 0 3px 2px var(--yellow)'
                        : undefined,
                }}
            >
                <AnimatedNum markValue={averageToDisplay} />
            </button>
            <button className="gpa-target" onClick={handleTargetDialogOpen}>
                Цель:{' '}
                {subjectMarks.averageMarkTarget ?? (
                    <Icon16HelpOutline className="no-gpa-target" />
                )}
            </button>

            {calculatorOpen && (
                <Calculator
                    initialMarks={subjectMarks?.marksList}
                    averageMarkTarget={subjectMarks.averageMarkTarget}
                    handleClose={() => setCalculatorOpen(false)}
                />
            )}
        </div>
    )
}

export default AverageMark
