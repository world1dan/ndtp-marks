import { useContext } from 'react'

import { css } from '@linaria/core'

import { Icon20InfoCircleOutline } from '@vkontakte/icons'
import { differenceInDays } from 'date-fns'

import { IQuarterSubjectMarks } from 'Types/marks'

import SchoolTermContext from '../SchoolTermContext'

const styles = css`
    color: var(--red);
    font-size: 11px;
    font-weight: 500;
    display: flex;
    gap: 8px;
    align-items: center;

    @media (min-width: 500px) {
        font-size: 12px;
    }
`

export interface Props {
    marksList: IQuarterSubjectMarks['marksList']
}

const NoNewMarksWarning = ({ marksList }: Props) => {
    const { currentSchoolTermId, selectedSchoolTermId } =
        useContext(SchoolTermContext)

    const marksCount = marksList?.length ?? 0

    let showNoNewMarksWarning =
        marksCount != 0 && marksList
            ? differenceInDays(
                  new Date(),
                  new Date(marksList[marksCount - 1].addedAt)
              ) >= 13
            : false

    if (currentSchoolTermId !== selectedSchoolTermId) {
        showNoNewMarksWarning = false
    }

    if (!showNoNewMarksWarning) return null

    return (
        <div className={styles}>
            <Icon20InfoCircleOutline width={22} height={22} />
            Последняя оценка была более <br />2 недель назад
        </div>
    )
}

export default NoNewMarksWarning
