import AboutMark, { Props } from '../../AboutMark'
import useQuarterMarkEdit from './useQuarterMarkEdit'

const AboutQuarterMark = ({ subject, ...restProps }: Props) => {
    const { updateMark, removeQuarterMark } = useQuarterMarkEdit(subject)

    return (
        <AboutMark
            subject={subject}
            editMark={updateMark}
            removeMark={removeQuarterMark}
            {...restProps}
        />
    )
}

export default AboutQuarterMark
