import { useContext } from 'react'

import { arrayUnion, setDoc } from 'firebase/firestore'
import { nanoid } from 'nanoid'

import { IMark } from 'Types/marks'
import { ISubject } from 'Types/subjects'

import QuarterMarksDocContext from '../QuarterMarksDocContext'

const useSubjectMarksController = (subject: ISubject) => {
    const quarterMarksDoc = useContext(QuarterMarksDocContext)

    const addQuarterMark = (
        value: number,
        isImportant: boolean,
        addedAt: string = new Date().toUTCString()
    ) => {
        const newMark: IMark = {
            id: nanoid(),
            value,
            isImportant,
            addedAt,
        }

        setDoc(
            quarterMarksDoc,
            {
                [subject.id]: {
                    marksList: arrayUnion(newMark),
                },
            },
            { merge: true }
        )
    }

    const changeMarkTarget = (newTarget: number | null) => {
        setDoc(
            quarterMarksDoc,
            {
                [subject.id]: {
                    averageMarkTarget: newTarget,
                },
            },
            { merge: true }
        )
    }

    const removeAllSubjectMarks = () => {
        setDoc(
            quarterMarksDoc,
            {
                [subject.id]: {
                    marksList: [],
                },
            },
            { merge: true }
        )
    }

    return {
        addQuarterMark,
        changeMarkTarget,
        removeAllSubjectMarks,
    }
}

export default useSubjectMarksController
