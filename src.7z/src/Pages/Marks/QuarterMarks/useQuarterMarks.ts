import { useMemo } from 'react'

import { doc } from 'firebase/firestore'
import { useDocumentData } from 'react-firebase-hooks/firestore'

import { firestore } from '../../../Firebase'

import { IQuarterMarks } from 'Types/marks'

const useQuarterMarks = (quarterID: number, userUID: string) => {
    const quarterMarksDoc = useMemo(() => {
        return doc(
            firestore,
            `marks/quartersMarks/${
                quarterID == 1 ? 3 : quarterID == 3 ? 1 : quarterID
            }/${userUID}`
        )
    }, [quarterID, userUID])

    const [quarterMarks, loading, error] =
        useDocumentData<IQuarterMarks>(quarterMarksDoc)

    return {
        loading,
        error,
        quarterMarks,
        quarterMarksDoc,
    }
}

export default useQuarterMarks
