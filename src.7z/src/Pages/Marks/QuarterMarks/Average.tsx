import { CSSProperties, memo } from 'react'

import { css } from '@linaria/core'

import { Icon16HelpOutline } from '@vkontakte/icons'

import Stack from 'Components/Stack'

import { IQuarterMarks } from 'Types/marks'

import AnimatedMarkValue from '../AnimatedMarkValue'
import MarksCount from '../MarksCount'
import analyzeQuarterMarks from '../Utils/analyzeQuarterMarks'

const stackStyles = css`
    margin: 0 auto;
    margin-top: 10px;
    width: 100%;
    max-width: 500px;
    margin-bottom: 20px;
`

const averageStyles = css`
    box-shadow: 0 0 0 1.5px var(--borders) inset;
    background: var(--bg2);
    border-radius: 7px;
    padding: 5px;
    display: grid;
    grid-template-columns: 1fr 100px;
    gap: 5px;

    @media (min-width: 500px) {
        grid-template-columns: 1fr 130px;
        border-radius: 7px;
        padding: 7px;
    }

    .title {
        font-size: 18px;
        font-weight: 600;
    }

    .info {
        display: flex;
        flex-direction: column;
        gap: 5px;
        padding: 15px;
    }

    .sub-title {
        color: var(--text-secondary-color);
        font-size: 14px;
        font-weight: 600;
    }

    .average {
        display: grid;
        gap: 4px;
        grid-template-rows: 46px 34px;

        .average-mark,
        .target {
            display: flex;
            justify-content: center;
            align-items: center;
            background: var(--bg4);
            border-radius: 5px;
            box-shadow: 0 0 0 1.5px var(--lvl4-borders) inset;
            gap: 4px;
            font-weight: 600;
        }

        .average-mark {
            position: relative;
            overflow: hidden;
            font-size: 18px;
            font-weight: bold;
            transition: box-shadow 200ms;

            @media (min-width: 500px) {
                font-size: 21px;
            }
        }

        .target {
            color: var(--text-secondary-color);
            font-size: 12px;
        }
    }
`

export interface Props {
    quarterMarks: IQuarterMarks | null | undefined
    schoolQuarterID: number
}
const Average = ({ quarterMarks, schoolQuarterID }: Props) => {
    const analyzed = quarterMarks
        ? analyzeQuarterMarks(quarterMarks)
        : {
              quarterMarksCount: 0,
              averageOfQuarter: undefined,
              targetOfQuarter: undefined,
          }

    const styles: CSSProperties = {}

    if (
        analyzed.averageOfQuarter &&
        analyzed.targetOfQuarter &&
        analyzed.averageOfQuarter < analyzed.targetOfQuarter
    ) {
        styles.boxShadow = 'inset 0 0 3px 2px var(--yellow)'
    }

    let targetOfQuarter: number | null = Number(
        analyzed.targetOfQuarter?.toFixed(2)
    )

    if (isNaN(targetOfQuarter) || targetOfQuarter === 0) {
        targetOfQuarter = null
    }

    return (
        <Stack className={stackStyles}>
            <div className={averageStyles}>
                <div className="info">
                    <span className="title">Средний балл</span>
                    <span className="sub-title">
                        {schoolQuarterID} Четверть
                    </span>
                </div>

                <div className="average">
                    <div className="average-mark" style={styles}>
                        <AnimatedMarkValue
                            markValue={analyzed.averageOfQuarter}
                        />
                    </div>
                    <div className="target">
                        Цель:{' '}
                        {targetOfQuarter ?? (
                            <Icon16HelpOutline className="no-gpa-target" />
                        )}
                    </div>
                </div>
            </div>
            <MarksCount marksCount={analyzed.quarterMarksCount} />
        </Stack>
    )
}

export default memo(Average)
