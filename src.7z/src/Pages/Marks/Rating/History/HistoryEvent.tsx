import { memo } from 'react'

import { css } from '@linaria/core'

import { Icon28UserCircleOutline } from '@vkontakte/icons'

import AboutMark from 'Pages/Marks/AboutMark'
import MarkCircle from 'Pages/Marks/MarkCircle'

import { IMark } from 'Types/marks'
import { ISubject } from 'Types/subjects'
import { IUserProfile } from 'Types/userProfile'

const styles = css`
    display: flex;
    align-items: center;
    padding: 4px 2px;
    gap: 12px;
    border-bottom: 2px solid var(--lvl4-borders);

    &:nth-last-child(2) {
        border-bottom: 0;
    }

    @media (min-width: 500px) {
        gap: 14px;
        padding: 4px;
    }

    @media (max-width: 360px) {
        gap: 8px;
    }

    & > * {
        flex-shrink: 0;
    }

    .color-indicator {
        height: 28px;
        width: 5px;
        border-radius: 2px;
    }

    .user-info,
    .subject-info {
        display: flex;
        align-items: center;
        gap: 8px;
        flex: 1;

        @media (min-width: 500px) {
            gap: 10px;
        }
    }

    .subject-info {
        max-width: 90px;

        @media (min-width: 500px) {
            max-width: 120px;
        }
    }

    .username,
    .subject {
        font-size: 13px;
        white-space: nowrap;
        text-overflow: ellipsis;
        overflow: hidden;

        @media (min-width: 500px) {
            font-size: 14px;
        }
    }

    .date {
        font-size: 13px;
        letter-spacing: -0.5px;
        color: var(--text-secondary-color);
    }

    .avatar {
        border-radius: 50%;
        width: 24px;
        height: 24px;
        object-fit: contain;

        @media (min-width: 500px) {
            width: 28px;
            height: 28px;
        }
    }

    .avatar-placeholder {
        color: var(--text-secondary-color);
    }
`

const dateFormatOptions: Intl.DateTimeFormatOptions = {
    day: 'numeric',
    month: 'numeric',
    hour: 'numeric',
    minute: 'numeric',
}

export interface Props {
    mark: IMark
    subject: ISubject
    userProfile: IUserProfile
}

const HistoryEvent = ({ mark, subject, userProfile }: Props) => {
    const dateString = new Date(mark.addedAt).toLocaleString(
        'ru-RU',
        dateFormatOptions
    )

    return (
        <div className={styles}>
            <MarkCircle
                value={mark.value}
                isImportant={mark.isImportant}
                aboutMarkContent={
                    <AboutMark
                        mark={mark}
                        subject={subject}
                        markType="quarterMark"
                    />
                }
            />
            <div className="subject-info">
                <div
                    className="color-indicator"
                    style={{
                        background: subject.color,
                        boxShadow: `${subject.color} 0px 0px 3px`,
                    }}
                />
                <div className="subject">{subject.title}</div>
            </div>
            <div className="user-info">
                {userProfile.avatarURL ? (
                    <img
                        className="avatar"
                        src={userProfile.avatarURL}
                        decoding="async"
                        loading="lazy"
                        width={24}
                        height={24}
                    />
                ) : (
                    <Icon28UserCircleOutline
                        className="avatar-placeholder"
                        width={26}
                        height={26}
                    />
                )}
                <div className="username">{userProfile.firstName}</div>
            </div>
            <div className="date">{dateString}</div>
        </div>
    )
}

export default memo(HistoryEvent)
