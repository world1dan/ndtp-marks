import { memo } from 'react'

import { css } from '@linaria/core'

import { Icon16HistoryBackwardOutline } from '@vkontakte/icons'

import useSubjects from 'Hooks/useSubjects'

import declOfNum from 'Utils/declOfNum'

import { ISortingType } from './'

const styles = css`
    display: flex;
    flex-direction: column;
    gap: 6px;
    font-weight: 600;
    margin-bottom: 6px;

    .info {
        padding: 10px;
        border-radius: 7px;
        background: var(--bg3);
        display: flex;
        justify-content: space-between;
        font-size: 13px;

        .title {
            line-height: 1.3;
            display: flex;
            gap: 8px;
            align-items: center;
        }

        .marks-count {
            color: var(--text-secondary-color);
        }
    }

    .sort-filter-menu {
        padding: 8px 10px;
        background: var(--bg3);
        border-radius: 7px;
        font-size: 13px;
        display: flex;
        gap: 10px;
        justify-content: space-between;

        .select {
            border: 0;
            font-weight: 600;
            background: var(--bg3);
            outline: none;
            font-size: 13px;
            color: var(--primary-color);
        }
    }
`

export interface Props {
    setSortingType: (type: ISortingType) => void
    marksCount?: number
}

const Header = ({ setSortingType, marksCount }: Props) => {
    const subjects = useSubjects()

    return (
        <div className={styles}>
            <div className="info">
                <div className="title">
                    <Icon16HistoryBackwardOutline />
                    История оценок
                </div>
                <div className="marks-count">
                    {marksCount}{' '}
                    {marksCount
                        ? declOfNum(marksCount, ['Оценка', 'Оценки', 'Оценок'])
                        : 'Оценок'}
                </div>
            </div>
            <div className="sort-filter-menu">
                Сортировка / Фильтр:
                <select
                    name="select"
                    className="select"
                    defaultValue={'date-recent'}
                    onChange={(event) =>
                        setSortingType(event.target.value as ISortingType)
                    }
                >
                    <option value="date-recent">Дата (сначала новые)</option>
                    <option value="date-old">Дата (сначала старые)</option>
                    <option value="only-own">Только мои</option>
                    <option value="mark">Оценка</option>
                    <option value="user">Имя</option>
                    {subjects && (
                        <optgroup label="По предметам">
                            {Object.values(subjects)
                                .filter((subject) => subject.isHasMarks)
                                .map((subject) => (
                                    <option value={subject.id} key={subject.id}>
                                        {subject.title}
                                    </option>
                                ))}
                        </optgroup>
                    )}
                </select>
            </div>
        </div>
    )
}

export default memo(Header)
