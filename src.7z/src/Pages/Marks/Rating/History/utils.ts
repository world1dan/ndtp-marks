import { IMarkEvent, ISortingType } from './index'

export function sortMarks(
    sortingType: ISortingType,
    marks: IMarkEvent[],
    userUid: string
) {
    switch (sortingType) {
        case 'date-recent':
            return marks.sort(
                (a, b) =>
                    new Date(b.mark.addedAt).getTime() -
                    new Date(a.mark.addedAt).getTime()
            )
        case 'date-old':
            return marks.sort(
                (a, b) =>
                    new Date(a.mark.addedAt).getTime() -
                    new Date(b.mark.addedAt).getTime()
            )
        case 'mark':
            return marks.sort((a, b) => b.mark.value - a.mark.value)
        case 'user':
            return marks.sort((a, b) =>
                a.userProfile.uid.localeCompare(b.userProfile.uid)
            )
        case 'only-own':
            return marks
                .filter((mark) => mark.userProfile.uid == userUid)
                .sort(
                    (a, b) =>
                        new Date(b.mark.addedAt).getTime() -
                        new Date(a.mark.addedAt).getTime()
                )
        default:
            return marks
                .filter((mark) => mark?.subject?.id == sortingType)
                .sort(
                    (a, b) =>
                        new Date(b.mark.addedAt).getTime() -
                        new Date(a.mark.addedAt).getTime()
                )
    }
}
