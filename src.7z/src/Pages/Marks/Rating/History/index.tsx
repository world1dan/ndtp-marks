import { useCallback, useMemo, useState } from 'react'

import { css } from '@linaria/core'

import LazyLoadingTrigger from 'Components/LazyLoadingTrigger'
import Suspense from 'Components/Suspense'

import useSubjects from 'Hooks/useSubjects'
import useUser from 'Hooks/useUser'

import { IMark, IUserRating } from 'Types/marks'
import { ISubject } from 'Types/subjects'
import { IUserProfile } from 'Types/userProfile'

import Header from './Header'
import HistoryEvent from './HistoryEvent'
import { sortMarks } from './utils'

const styles = css`
    background-color: var(--bg2);
    border-radius: 9px;
    border: 1.5px var(--borders) solid;
    padding: 6px;
`

export interface IMarkEvent {
    mark: IMark
    userProfile: IUserProfile
    subject: ISubject
}

export type ISortingType =
    | 'date-recent'
    | 'date-old'
    | 'mark'
    | 'user'
    | 'only-own'

export interface Props {
    usersRatings: IUserRating[]
    usersProfiles: IUserProfile[]
}

const History = ({ usersRatings, usersProfiles }: Props) => {
    const [visibleEventsCount, setVisibleEventsCount] = useState(10)
    const [sortingType, setSortingType] = useState<ISortingType>('date-recent')
    const subjects = useSubjects()

    const { user } = useUser()

    const everyMark = useMemo(() => {
        const list: IMarkEvent[] = []

        usersRatings.forEach((userRating) => {
            const userProfile = usersProfiles.find(
                (user) => user.uid === userRating.uid
            )

            if (!userProfile || userProfile.isPrivate) return

            Object.entries(userRating.quarterMarks).forEach(
                ([subjectId, subjectMarks]) => {
                    subjectMarks.marksList?.forEach((mark: IMark) => {
                        const subject = subjects?.[subjectId]

                        if (!subject) return

                        list.push({
                            mark,
                            userProfile,
                            subject,
                        })
                    })
                }
            )
        })
        return sortMarks(sortingType, list, user.uid)
    }, [usersRatings, usersProfiles, sortingType, user.uid, subjects])

    const showMore = useCallback(() => {
        setVisibleEventsCount((visibleEventsCount) => visibleEventsCount + 12)
    }, [])

    if (!subjects) return null

    return (
        <div className={styles}>
            <Header
                setSortingType={setSortingType}
                marksCount={everyMark.length}
            />
            <Suspense delay={300} rowsCount={10} rowsHeight={46}>
                {everyMark.slice(0, visibleEventsCount).map((event) => {
                    return (
                        <HistoryEvent
                            {...event}
                            key={
                                event.mark.addedAt +
                                event.mark.value +
                                event.userProfile.uid
                            }
                        />
                    )
                })}
            </Suspense>
            <LazyLoadingTrigger handler={showMore} />
        </div>
    )
}

export default History
