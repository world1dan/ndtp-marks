import { useMemo } from 'react'

import { collection } from 'firebase/firestore'
import { useCollection } from 'react-firebase-hooks/firestore'

import { IUserRating } from 'Types/marks'

import { firestore } from '../../../Firebase'
import analyzeQuarterMarks from '../Utils/analyzeQuarterMarks'

const useRating = (quarterId: number) => {
    const collectionRef = useMemo(
        () =>
            collection(
                firestore,
                'marks',
                'quartersMarks',
                (quarterId == 1 ? 3 : quarterId == 3 ? 1 : quarterId).toString()
            ),
        [quarterId]
    )

    const [usersQuarterMarksSnapshot, isLoading] = useCollection(collectionRef)

    const usersRatings: IUserRating[] = []

    let generalMarksCount = 0

    usersQuarterMarksSnapshot?.forEach((doc) => {
        const quarterMarks = doc.data()
        const uid = doc.id

        const { averageOfQuarter, targetOfQuarter, quarterMarksCount } =
            analyzeQuarterMarks(quarterMarks)

        generalMarksCount += quarterMarksCount

        usersRatings.push({
            uid,
            quarterMarks,
            averageOfQuarter,
            targetOfQuarter,
        })
    })

    return { usersRatings, generalMarksCount, isLoading }
}

export default useRating
