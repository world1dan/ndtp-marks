import { css } from '@linaria/core'
import ScrollView from 'Components/ScrollView'

import useUsersProfiles from 'Hooks/useUsersProfiles'
import { useState } from 'react'
import getCurrentSchoolQuarter from 'Utils/getCurrentSchoolQuarter'

import QuarterPicker from '../QuarterPicker'
import Chart from './Chart'
import History from './History'
import useRating from './useRating'

const styles = css`
    display: grid;
    gap: 10px;
    margin: 0 auto;
    max-width: 580px;
    position: relative;

    .quarter-select {
        position: absolute;
        top: 5px;
        right: 0;
        background: var(--bg2);
        padding: 4px;
        border-radius: 9px;
        border: 1.5px var(--borders) solid;
    }

    .not-current-quarter-alert {
        padding-top: 60px;
    }
`

const Rating = () => {
    const { usersProfiles } = useUsersProfiles()

    const [schoolQuarterId, setSchoolQuarterId] = useState(
        () => getCurrentSchoolQuarter()?.num ?? 2
    )

    const { usersRatings, isLoading } = useRating(schoolQuarterId)



    if (!usersProfiles || usersProfiles.length == 0) return null

    return (
        <ScrollView>
        <div className={styles}>
            <div className="quarter-select">
                <QuarterPicker
                    activeQuarterId={schoolQuarterId}
                    setActiveQuarterId={setSchoolQuarterId}
                />
            </div>
            <Chart
                usersRatings={usersRatings}
                usersProfiles={usersProfiles}
                isLoading={isLoading}
                key={schoolQuarterId}
            />

            <History
                usersRatings={usersRatings}
                usersProfiles={usersProfiles}
            />
        </div>
        </ScrollView>
    )
}

export default Rating
