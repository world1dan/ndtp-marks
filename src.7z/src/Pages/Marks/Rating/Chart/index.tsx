import { useEffect, useState } from 'react'

import { css } from '@linaria/core'

import { motion } from 'framer-motion'

import LoadingSpinner from 'Components/LoadingSpinner'

import useUser from 'Hooks/useUser'

import { IUserRating } from 'Types/marks'
import { IUserProfile } from 'Types/userProfile'

import Column from './Column'

const styles = css`
    height: 410px;
    overflow: hidden;

    .data-wrapper {
        height: 100%;
        align-items: flex-end;
        display: flex;
        gap: 5px;
        overflow-x: auto;
        overflow-y: hidden;
        padding: 6px;
        padding-top: 40px;

        &::-webkit-scrollbar {
            height: 8px;

            @media (min-width: 1000px) {
                height: 12px;
            }
        }

        &::-webkit-scrollbar-thumb {
            background-color: var(--bg4);
            border-radius: 20px;
        }
    }
`

export interface Props {
    usersRatings: IUserRating[]
    usersProfiles: IUserProfile[]
    isLoading: boolean
}

const Chart = ({
    usersRatings,
    usersProfiles,
    isLoading: isRatingLoading,
}: Props) => {
    const { user: currentUser } = useUser()

    const [loading, setLoading] = useState(true)

    useEffect(() => {
        setTimeout(() => setLoading(false), 300)
    }, [])

    const generateChartColumns = () => {
        return usersProfiles
            .map((userProfile) => {
                return {
                    userProfile,
                    userRating: usersRatings.find(
                        (r) => r.uid == userProfile.uid
                    ),
                }
            })
            .sort((a, b) => {
                if (
                    a.userProfile.badges?.includes('cheater') ||
                    a.userProfile.isPrivate ||
                    (!a.userRating?.averageOfQuarter &&
                        b.userRating?.averageOfQuarter)
                )
                    return 1

                if (
                    b.userProfile.badges?.includes('cheater') ||
                    b.userProfile.isPrivate ||
                    (a.userRating?.averageOfQuarter &&
                        !b.userRating?.averageOfQuarter)
                )
                    return -1

                if (
                    !a.userRating?.averageOfQuarter ||
                    !b.userRating?.averageOfQuarter
                )
                    return 0

                return (
                    b.userRating.averageOfQuarter -
                    a.userRating.averageOfQuarter
                )
            })
            .map((userInfo, i) => (
                <Column
                    key={userInfo.userProfile.uid}
                    i={i}
                    userProfile={userInfo.userProfile}
                    userRating={userInfo.userRating}
                    isOwn={currentUser?.uid == userInfo.userProfile.uid}
                />
            ))
    }

    const columns =
        usersRatings && !isRatingLoading && !loading
            ? generateChartColumns()
            : null

    return (
        <div className={styles}>
            {loading || isRatingLoading ? (
                <LoadingSpinner height="100%" size={38} />
            ) : (
                <motion.div className="data-wrapper" layoutScroll>
                    {columns}
                </motion.div>
            )}
        </div>
    )
}

export default Chart
