import { CSSProperties, ReactNode, useRef, useState } from 'react'

import {
    Icon24HelpOutline,
    Icon24LockOutline,
    Icon28CrownOutline,
    Icon28UserCircleOutline,
} from '@vkontakte/icons'
import { motion } from 'framer-motion'

import UserProfile from 'Pages/UserProfile'

import useImgAverageColor from 'Hooks/useImgAverageColor'

import getCSSVarValue from 'Utils/getCSSVarValue'

import { IUserRating } from 'Types/marks'
import { IUserProfile } from 'Types/userProfile'

import './style.scss'

interface IMotionVariantsCustom {
    i: number
    isOwn: boolean
    height: CSSProperties['height']
    change?: 'increase' | 'decrease'
}

const variants = {
    hidden: (custom: IMotionVariantsCustom) => ({
        y: 'calc(100% + 20px)',
        height: custom.height,
        scale: 0.8,
    }),
    visible: (custom: IMotionVariantsCustom) => {
        const delay = custom.i * 0.07

        return {
            y: 0,
            scale: 1,
            height: custom.height,
            transition: {
                y: { delay, type: 'spring', duration: 0.7, bounce: 0.25 },
                scale: { delay, type: 'spring', duration: 1, bounce: 0.4 },
                backgroundColor: {
                    duration: 1.5,
                    ontransitionend: {
                        backgroundColor: undefined,
                    },
                },
            },
            backgroundColor: custom.change
                ? [
                      custom.change == 'decrease' ? '#ff3b30' : '#34c759',
                      custom.isOwn
                          ? getCSSVarValue('var(--primary-color)')
                          : getCSSVarValue('var(--bg4)'),
                  ]
                : undefined,
        }
    },
}

export interface Props {
    userRating?: IUserRating
    userProfile: IUserProfile
    isOwn: boolean
    i: number
}

const Column = ({ userRating, userProfile, isOwn, i }: Props) => {
    const avatarRef = useRef<HTMLImageElement>(null)
    const backgroundColor = useImgAverageColor(avatarRef)

    const [userProfileOpen, setUserProfileOpen] = useState(false)

    const prevRating = useRef<number>()

    const averageOfQuarter = userRating?.averageOfQuarter

    const percent =
        averageOfQuarter && !userProfile.isPrivate
            ? (averageOfQuarter / 10) * 100
            : 40

    const motionCustom: IMotionVariantsCustom = {
        i,
        isOwn,
        height: percent + '%',
        change:
            prevRating.current &&
            averageOfQuarter &&
            prevRating.current !== averageOfQuarter
                ? prevRating.current < averageOfQuarter
                    ? 'increase'
                    : 'decrease'
                : undefined,
    }

    if (averageOfQuarter) {
        prevRating.current = averageOfQuarter
    }

    let gpaToDisplay: ReactNode =
        averageOfQuarter && !isNaN(averageOfQuarter) ? (
            averageOfQuarter?.toFixed(2)
        ) : (
            <Icon24HelpOutline fill={'var(--text-secondary-color)'} />
        )

    if (userProfile.isPrivate) {
        gpaToDisplay = <Icon24LockOutline fill={'var(--red)'} />
    }

    return (
        <>
            <motion.div
                onClick={() => setUserProfileOpen(true)}
                variants={variants}
                custom={motionCustom}
                initial="hidden"
                animate="visible"
                layout="position"
                layoutDependency={i}
                whileTap={{ opacity: 0.6 }}
                className={
                    'Marks__Rating__Chart_Column ' + (isOwn ? 'own' : '')
                }
            >
                {i == 0 && averageOfQuarter && !userProfile.isPrivate && (
                    <Icon28CrownOutline
                        className="crown"
                        width={40}
                        height={40}
                    />
                )}
                <div className="content">
                    <div className="average-mark">{gpaToDisplay}</div>
                    {averageOfQuarter && !userProfile.isPrivate && (
                        <div className="place-info">#{i + 1}</div>
                    )}
                    {userProfile.badges?.includes('cheater') && (
                        <div className="badges">
                            <div className="badge cheater">Аферист</div>
                        </div>
                    )}
                    <div className="avatar-container">
                        {userProfile.avatarURL ? (
                            <img
                                crossOrigin="anonymous"
                                ref={avatarRef}
                                className="avatar"
                                src={userProfile.avatarURL}
                                style={{
                                    boxShadow:
                                        '0px 10px 90px 18px' + backgroundColor,
                                }}
                                onError={(e) =>
                                    (e.currentTarget.style.display = 'none')
                                }
                            />
                        ) : (
                            <Icon28UserCircleOutline
                                className="avatar-placeholder"
                                width={40}
                                height={40}
                            />
                        )}
                    </div>
                    <div className="username">{userProfile.firstName}</div>
                </div>
            </motion.div>
            {userProfileOpen && (
                <UserProfile
                    uid={userProfile.uid}
                    handleClose={() => setUserProfileOpen(false)}
                />
            )}
        </>
    )
}

export default Column
