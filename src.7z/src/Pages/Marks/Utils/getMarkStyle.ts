import { CSSProperties } from 'react'

interface IMarkStyle {
    color?: CSSProperties['color']
    backgroundColor?: CSSProperties['backgroundColor']
    boxShadow?: CSSProperties['boxShadow']
}

const getMarkStyle = (value: number, isImportant?: boolean) => {
    const markStyle: IMarkStyle = {}

    if (value >= 7) {
        markStyle.color = 'var(--mark-green)'
        markStyle.backgroundColor = 'var(--mark-green-bg)'
    } else if (value >= 5) {
        markStyle.color = 'var(--mark-yellow)'
        markStyle.backgroundColor = 'var(--mark-yellow-bg)'
    } else if (value >= 1) {
        markStyle.color = 'var(--mark-red)'
        markStyle.backgroundColor = 'var(--mark-red-bg)'
    }

    if (isImportant) {
        markStyle.boxShadow = `inset 0 0 3px 2px ${markStyle.color}`
        //markStyle.boxShadow = `inset 0 0 2px 0px ${markStyle.color}`
    }

    return markStyle
}

export default getMarkStyle
