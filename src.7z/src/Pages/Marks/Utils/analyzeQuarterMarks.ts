import { IQuarterMarks } from 'Types/marks'

import getAverageMark from './getAverageMark'

const analyzeQuarterMarks = (quarterMarks: IQuarterMarks) => {
    let quarterMarksCount = 0

    const averageOfSubjects = Object.values(quarterMarks ?? {})
        .map((subjectMarks) => {
            if (subjectMarks.marksList && subjectMarks.marksList.length > 0) {
                quarterMarksCount += subjectMarks.marksList.length

                return getAverageMark(subjectMarks.marksList, true)
            } else {
                return null
            }
        })
        .filter(Boolean) as number[]

    const averageOfQuarter =
        averageOfSubjects.reduce((a, b) => a + b, 0) / averageOfSubjects.length

    const targetsOfSubjects = Object.values(quarterMarks ?? {})
        .map((subjectMarks) => subjectMarks.averageMarkTarget)
        .filter(Boolean)

    const averageTargetOfQuarter =
        targetsOfSubjects.reduce((a: number, b) => (b ? a + b : a), 0) /
        targetsOfSubjects.length

    return {
        quarterMarksCount,
        averageOfQuarter: isNaN(averageOfQuarter)
            ? undefined
            : averageOfQuarter,
        targetOfQuarter: averageTargetOfQuarter,
    }
}

export default analyzeQuarterMarks
