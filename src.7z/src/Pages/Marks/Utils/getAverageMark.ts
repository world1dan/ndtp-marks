import { IMark } from 'Types/marks'

const getAverageMark = (marks: IMark[], round = false) => {
    const average =
        marks.reduce(
            (a, b) => a + (round ? Number(b.value.toFixed()) : b.value),
            0
        ) / marks.length

    return isNaN(average) ? null : round ? Number(average.toFixed()) : average
}

export default getAverageMark
