import { memo, useState } from 'react'

import { css } from '@linaria/core'

import ScrollView from 'Components/ScrollView'
import SegmentedControlOption from 'Components/SegmentedControl/SegmentedControlOption'
import SegmentedControl from 'Components/SegmentedControl/index'

import usePageThemeColor from 'Hooks/usePageThemeColor'
import useUser from 'Hooks/useUser'

import getCurrentSchoolQuarter from 'Utils/getCurrentSchoolQuarter'

import Header from './Header'
import QuarterMarks from './QuarterMarks'
import Rating from './Rating'
import YearMarks from './YearMarks'

const scrollViewStyles = css`
    max-width: 1300px;
    margin: 0 auto;

    @media (max-width: 600px) {
        padding: 14px;
        padding-top: 4px;
    }

    @media (max-width: 350px) {
        padding: 0;
    }
`

const Marks = () => {
    usePageThemeColor('var(--bg1)')

    const [currentTab, setCurrentTab] = useState('quarter')

    const { uid } = useUser().user

    const [schoolQuarterId, setSchoolQuarterId] = useState(
        () => getCurrentSchoolQuarter()?.num ?? 2
    )

    return (
        <ScrollView className={scrollViewStyles}>
            <Header>
                <SegmentedControl
                    value={currentTab}
                    handleChange={setCurrentTab}
                >
                    <SegmentedControlOption id="quarter">
                        Четверть
                    </SegmentedControlOption>
                    <SegmentedControlOption id="finalGrades">
                        Год
                    </SegmentedControlOption>
                    <SegmentedControlOption id="rating">
                        Рейтинг
                    </SegmentedControlOption>
                </SegmentedControl>
            </Header>
            {currentTab == 'quarter' && (
                <QuarterMarks
                    uid={uid}
                    schoolQuarterId={schoolQuarterId}
                    setSchoolQuarterId={setSchoolQuarterId}
                />
            )}
            {currentTab == 'finalGrades' && <YearMarks uid={uid} />}
            {currentTab == 'rating' && (
                <Rating
                    schoolQuarterId={schoolQuarterId}
                    setSchoolQuarterId={setSchoolQuarterId}
                />
            )}
        </ScrollView>
    )
}

export default memo(Marks)
