import { CSSProperties, useState } from 'react'

import { css } from '@linaria/core'

import BottomSheet from 'Components/BottomSheet'
import Switch from 'Components/Switch'

import MarksNumpad from './MarksNumpad'

const styles = css`
    display: flex;
    flex-direction: column;
    gap: 30px;
    padding: 10px;

    .mark-info {
        display: grid;
        grid-template-columns: 4px 1fr;
        background-color: var(--bg3);
        padding: 8px;
        border-radius: 9px;
        gap: 4px;
        text-align: center;

        .subject-color {
            grid-row: 1 / 4;
            width: 6px;
            border-radius: 7px;
            background-color: rgb(128 177 96);
            box-shadow: rgb(128 177 96) 0 0 4px;
        }

        .title {
            font-size: 15px;
            margin: 4px;
            font-weight: 600;
        }

        .description {
            color: var(--text-secondary-color);
            font-size: 14px;
            font-weight: 600;
        }

        .importance-toggle {
            padding: 6px;
            display: flex;
            justify-content: space-between;
            padding-left: 30px;
            align-items: center;

            --switch-background-color: var(--bg2);

            .importance-toggle-label {
                font-size: 13px;
                font-weight: 600;
            }
        }
    }
`

export interface Props {
    title: string
    description: string
    subjectColor?: CSSProperties['color'] | undefined
    withImportanceToggle?: boolean
    withDatePicker?: boolean
    handleSubmit: (markValue: number, isImportantMark: boolean) => void
    handleClose: () => void
    handleClear?: () => void
}

const MarksPicker = ({
    title,
    description,
    handleSubmit,
    handleClose,
    subjectColor,
    withImportanceToggle = false,
    handleClear,
}: Props) => {
    const [isImportantMark, setIsImportantMark] = useState(false)
    const handleMarkInput = (markValue: number) => {
        handleSubmit(markValue, isImportantMark)
    }

    return (
        <BottomSheet bottomCloseBtn handleClose={handleClose}>
            {(close: () => void) => (
                <div className={styles}>
                    <header className="mark-info">
                        {subjectColor && (
                            <div
                                className="subject-color"
                                style={{
                                    backgroundColor: subjectColor,
                                    boxShadow: `${subjectColor} 0px 0px 4px`,
                                }}
                            />
                        )}
                        <div className="title">{title}</div>
                        <div className="description">{description}</div>
                        {withImportanceToggle && (
                            <div className="importance-toggle">
                                <div className="importance-toggle-label">
                                    Отметить как оценку за к/р
                                </div>
                                <Switch
                                    style={{}}
                                    checked={isImportantMark}
                                    onChange={(e) =>
                                        setIsImportantMark(e.target.checked)
                                    }
                                />
                            </div>
                        )}
                    </header>

                    <MarksNumpad
                        handleClear={
                            handleClear
                                ? () => {
                                      close()
                                      handleClear()
                                  }
                                : undefined
                        }
                        handleMarkInput={(value) => {
                            close()
                            handleMarkInput(value)
                        }}
                    />
                </div>
            )}
        </BottomSheet>
    )
}

export default MarksPicker
