import { css } from '@linaria/core'

import { Icon28ListOutline } from '@vkontakte/icons'

import ContextMenu from 'Components/ContextMenu'
import ContextMenuOption from 'Components/ContextMenu/ContextMenuOption'
import ContextMenuOptions from 'Components/ContextMenu/ContextMenuOptions'

const styles = css`
    width: auto;
    height: auto;
    display: grid;
    place-items: center;
`

export interface Props {
    activeQuarterId: number
    setActiveQuarterId: (quarterId: number) => void
}

const QuarterPicker = ({ activeQuarterId, setActiveQuarterId }: Props) => {
    return (
        <ContextMenu
            className={styles}
            icon={<Icon28ListOutline />}
            offsetTop={28}
            offsetLeft={-24}
        >
            <ContextMenuOptions
                value={activeQuarterId}
                handleChange={(quarterId) =>
                    setActiveQuarterId(Number(quarterId))
                }
            >
                {[1, 2, 3, 4].map((quarterId) => (
                    <ContextMenuOption id={quarterId} key={quarterId}>
                        {quarterId} Четверть
                    </ContextMenuOption>
                ))}
            </ContextMenuOptions>
        </ContextMenu>
    )
}

export default QuarterPicker
