import { css } from '@linaria/core'

const styles = css`
    align-items: center;
    background-color: var(--bg2);
    border-radius: 9px;
    display: grid;
    grid-template-columns: 1fr 70px;
    height: 46px;
    padding-left: 12px;
    border: 1.5px var(--borders) solid;

    .title {
        color: var(--text-secondary-color);
        font-size: 14px;
        font-weight: 600;
    }

    .num {
        font-weight: bold;
        text-align: center;
    }
`

export interface Props {
    marksCount: number
}

const MarksCount = ({ marksCount }: Props) => {
    return (
        <div className={styles}>
            <div className="title">Всего оценок</div>
            <div className="num">{marksCount}</div>
        </div>
    )
}

export default MarksCount
