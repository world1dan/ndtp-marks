import { ReactNode } from 'react'

import { css } from '@linaria/core'

import PageTitle from 'Components/PageTitle'

const headerStyles = css`
    display: grid;
    align-items: center;
    grid-template-columns: 1fr 1fr;
    margin: 0 auto;
    max-width: 740px;
    padding: 30px 12px;

    @media (max-width: 670px) {
        gap: 12px;
        grid-template-columns: 1fr;
        grid-template-rows: 1fr 1fr;
        padding: 10px 0;
        max-width: 500px;
    }

    @media (min-width: 750px) {
        padding: 26px 0;
        padding-left: 90px;
    }

    @media (max-width: 350px) {
        padding: 8px 0;
    }
`

export interface Props {
    children: ReactNode
}

const Header = ({ children }: Props) => {
    return (
        <header className={headerStyles}>
            <PageTitle>Оценки</PageTitle>
            {children}
        </header>
    )
}

export default Header
