import { initializeApp } from 'firebase/app'
import {
    connectAuthEmulator,
    indexedDBLocalPersistence,
    initializeAuth,
} from 'firebase/auth'
import {
    connectFirestoreEmulator,
    enableMultiTabIndexedDbPersistence,
    getFirestore,
} from 'firebase/firestore'
import { connectStorageEmulator, getStorage } from 'firebase/storage'

export const firebaseApp = initializeApp({
    apiKey: process.env.REACT_APP_FIREBASE_API_KEY,
    authDomain: process.env.REACT_APP_FIREBASE_AUTH_DOMAIN,
    projectId: process.env.REACT_APP_FIREBASE_PROJECT_ID,
    databaseURL: process.env.REACT_APP_FIREBASE_DATABASE_URL,
    storageBucket: process.env.REACT_APP_FIREBASE_STORAGE_BUCKET,
    appId: process.env.REACT_APP_FIREBASE_APP_ID,
    messagingSenderId: process.env.REACT_APP_FIREBASE_MESSAGING_SENDER_ID,
})

export const auth = initializeAuth(firebaseApp, {
    persistence: indexedDBLocalPersistence,
})

export const firestore = getFirestore(firebaseApp)
export const storage = getStorage(firebaseApp)

if (process.env.NODE_ENV !== 'development') {
    const isLocalhost = window.location.hostname === 'localhost'

    connectFirestoreEmulator(
        firestore,
        isLocalhost ? '127.0.0.1' : location.hostname,
        8080
    )
    connectStorageEmulator(
        storage,
        isLocalhost ? '127.0.0.1' : location.hostname,
        9199
    )
    connectAuthEmulator(
        auth,
        isLocalhost
            ? 'http://127.0.0.1:9099'
            : `http://${location.hostname}:9099`,
        {
            disableWarnings: true,
        }
    )
}

enableMultiTabIndexedDbPersistence(firestore)
